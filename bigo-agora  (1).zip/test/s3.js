'use strict';
// Testa o fluxo de envio direto ao S3/R2 contra um S3 falso local (verifica a presença da assinatura, não a criptografia — essa foi validada contra o exemplo oficial da AWS).
const { spawn } = require('child_process');
const http = require('http');
const path = require('path');
const PORT = 3223, B = 'http://127.0.0.1:' + PORT;
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : fail++; console.log((c ? '  ok  ' : '  FALHA ') + m); };
const store = new Map();
const fake = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x'); const key = u.pathname;
  if (req.method === 'PUT') {
    if (!u.searchParams.get('X-Amz-Signature')) { res.writeHead(403); return res.end(); }
    const ch = []; req.on('data', (c) => ch.push(c)); req.on('end', () => { store.set(key, Buffer.concat(ch)); res.writeHead(200); res.end(); });
  } else if (req.method === 'HEAD' || req.method === 'GET') {
    if (!/AWS4-HMAC-SHA256/.test(req.headers.authorization || '')) { res.writeHead(403); return res.end(); }
    const b = store.get(key); if (!b) { res.writeHead(404); return res.end(); }
    const m = /bytes=(\d+)-(\d+)/.exec(req.headers.range || '');
    const out = m ? b.subarray(+m[1], +m[2] + 1) : b;
    res.writeHead(m ? 206 : 200, { 'content-length': out.length, 'content-type': 'application/octet-stream' });
    res.end(req.method === 'HEAD' ? undefined : out);
  } else if (req.method === 'DELETE') { store.delete(key); res.writeHead(204); res.end(); }
  else { res.writeHead(405); res.end(); }
});
async function call(method, p, { body, token } = {}) {
  const h = {}; if (token) h.Authorization = 'Bearer ' + token; if (body) h['Content-Type'] = 'application/json';
  const r = await fetch(B + p, { method, headers: h, body: body && JSON.stringify(body), redirect: 'manual' });
  let j = null; try { j = await r.clone().json(); } catch (_) {} return { s: r.status, j, r };
}
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
fake.listen(9333, async () => {
  const srv = spawn('node', [path.join(__dirname, '..', 'src', 'index.js')], { env: { ...process.env, APP_ENV: 'demo', PORT: String(PORT), ADMIN_PASSWORD: 'SenhaAdmin#2026', JWT_SECRET: 'y'.repeat(40),
    STORAGE_DRIVER: 's3', S3_ENDPOINT: 'http://127.0.0.1:9333', S3_BUCKET: 'bigo', S3_ACCESS_KEY: 'AK', S3_SECRET_KEY: 'SK', S3_PUBLIC_URL: 'https://cdn.exemplo.com' }, stdio: ['ignore', 'pipe', 'pipe'] });
  let log = ''; srv.stdout.on('data', (d) => (log += d)); srv.stderr.on('data', (d) => (log += d));
  for (let i = 0; i < 50; i++) { try { if ((await call('GET', '/api/health')).s === 200) break; } catch (_) {} await new Promise((r) => setTimeout(r, 200)); }
  try {
    const e = 's3' + Date.now() + '@teste.com';
    let r = await call('POST', '/api/auth/register', { body: { acceptTerms: true, role: 'WORKER', email: e, password: 'Senha-forte-1', name: 'Teste S3', city: 'Salvador', state: 'BA', phone: '71999990000', profession: 'Pintor' } });
    console.log('     reg', r.s, JSON.stringify(r.j).slice(0,200)); const T = r.j.accessToken;
    ok((await call('GET', '/api/settings')).j.storage === 's3', '/settings informa storage s3');
    ok((await call('POST', '/api/media', { token: T })).s === 400, 'upload direto desativado em modo s3');
    r = await call('POST', '/api/media/presign', { token: T, body: { mime: 'image/png', size: PNG.length } });
    ok(r.s === 201 && /X-Amz-Signature=/.test(r.j.uploadUrl), 'presign devolve URL assinada');
    const id = r.j.id;
    ok((await call('POST', `/api/media/${id}/complete`, { token: T })).s === 400, 'complete antes do envio = 400');
    const put = await fetch(r.j.uploadUrl, { method: 'PUT', headers: r.j.headers, body: PNG });
    ok(put.status === 200, 'navegador envia PUT direto ao bucket');
    r = await call('POST', `/api/media/${id}/complete`, { token: T });
    ok(r.s === 200 && r.j.url, 'complete valida tamanho e conteúdo');
    r = await call('GET', '/media/' + id);
    ok(r.s === 302 && /^https:\/\/cdn\.exemplo\.com\//.test(r.r.headers.get('location')), 'GET /media redireciona para a URL pública');
    // arquivo falso enviado pelo presign
    r = await call('POST', '/api/media/presign', { token: T, body: { mime: 'image/png', size: 40 } });
    await fetch(r.j.uploadUrl, { method: 'PUT', headers: r.j.headers, body: Buffer.from('MZ nao sou imagem'.padEnd(40, 'x')) });
    const bad = await call('POST', `/api/media/${r.j.id}/complete`, { token: T });
    ok(bad.s === 415, 'conteúdo falso rejeitado no complete');
    ok(![...store.keys()].some((k) => k.includes(r.j.id)), 'arquivo falso removido do bucket');
    r = await call('POST', '/api/media/presign', { token: T, body: { mime: 'application/pdf', size: 10 } });
    ok(r.s === 400, 'tipo não permitido no presign');
    r = await call('POST', '/api/media/presign', { token: T, body: { mime: 'video/mp4', size: 500 * 1048576 } });
    ok(r.s === 400, 'vídeo acima do limite recusado');
  } catch (e) { fail++; console.log('EXCEÇÃO', e.stack); }
  srv.kill(); fake.close();
  if (fail) console.log(log.slice(-2000));
  console.log(`\n${pass} ok, ${fail} falhas`); process.exit(fail ? 1 : 0);
});
