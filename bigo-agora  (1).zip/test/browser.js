'use strict';
// Teste no navegador real (Chromium) contra o servidor real. Uso: node test/browser.js <foto.jpg> <video.mp4>
const { spawn } = require('child_process');
const path = require('path');
const { chromium } = require('playwright');
const [IMG, VID] = process.argv.slice(2);
const PORT = 3330, B = 'http://127.0.0.1:' + PORT;
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : fail++; console.log((c ? '  ok  ' : '  FALHA ') + m); };
(async () => {
  const srv = spawn('node', [path.join(__dirname, '..', 'src', 'index.js')], { env: { ...process.env, APP_ENV: 'demo', PORT: String(PORT), UPLOAD_DIR: '/tmp/bigo-bt', ADMIN_PASSWORD: 'SenhaAdmin#2026', JWT_SECRET: 'z'.repeat(40) }, stdio: ['ignore', 'pipe', 'pipe'] });
  let log = ''; srv.stdout.on('data', (d) => (log += d)); srv.stderr.on('data', (d) => (log += d));
  for (let i = 0; i < 50; i++) { try { if ((await fetch(B + '/api/health')).ok) break; } catch (_) {} await new Promise((r) => setTimeout(r, 200)); }
  const br = await chromium.launch();
  const errs = [];
  const newPage = async () => { const ctx = await br.newContext({ viewport: { width: 420, height: 860 } }); const p = await ctx.newPage(); p.on('pageerror', (e) => errs.push(e.message)); p.on('response', (r) => { if (r.url().includes('/api/') && r.status() >= 400) console.log('   HTTP', r.status(), r.url().replace(B, '')); }); p.on('console', (m) => m.type() === 'error' && errs.push('console: ' + m.text())); return p; };
  const toastText = async (p) => (await p.locator('#toast').innerText().catch(() => '')).trim();
  try {
    const w = await newPage();
    await w.goto(B + '/'); await w.waitForSelector('form[data-form=login]');
    ok((await w.locator('body').innerText()).includes('BiGo'), 'tela de login com a marca BiGo');
    ok(!(await w.content()).toLowerCase().includes('painel adm</a>'), 'sem link de admin na tela de login');
    // cadastro trabalhador
    await w.click('text=Criar conta'); await w.click('[data-v=WORKER]');
    await w.fill('[name=name]', 'Zé Pintor'); await w.fill('[name=email]', 'ze@teste.com'); await w.fill('[name=password]', 'Senha-forte-1');
    await w.fill('[name=phone]', '71988887777'); await w.fill('[name=city]', 'Salvador'); await w.selectOption('[name=state]', 'BA'); await w.selectOption('[name=profession]', 'Pintor');
    await w.click('[name=terms]'); await w.click('button[type=submit]');
    await w.waitForSelector('.nav', { timeout: 8000 });
    ok(w.url().includes('#/feed'), 'cadastro leva ao feed');
    // publicar foto + vídeo
    await w.click('a.plus'); await w.waitForSelector('form[data-form=post]');
    await w.setInputFiles('input[type=file]', [IMG, VID]);
    await w.fill('[name=text]', 'Pintura completa de apartamento de 2 quartos'); await w.fill('[name=price]', 'A partir de R$ 30/m²');
    await w.click('button[type=submit]');
    await w.waitForSelector('article.card', { timeout: 60000 });
    ok(true, 'publicação com foto e vídeo aparece no feed');
    ok((await w.locator('article.card img').count()) >= 1 && (await w.locator('article.card video').count()) >= 1, 'foto e vídeo renderizados');
    const imgOk = await w.evaluate(() => { const i = document.querySelector('article.card img'); return i && i.complete && i.naturalWidth > 0; });
    ok(imgOk, 'imagem carregou do servidor');
    // story
    await w.goto(B + '/#/story/new'); await w.waitForSelector('form[data-form=story]');
    await w.setInputFiles('input[type=file]', [IMG]); await w.fill('[name=text]', 'Obra de hoje'); await w.click('button[type=submit]');
    await w.waitForSelector('.stories .st[data-act=story]', { timeout: 30000 });
    ok(true, 'story aparece na barra');
    await w.click('.stories .st[data-act=story]'); await w.waitForSelector('.sv');
    ok((await w.locator('.sv').innerText()).includes('Obra de hoje'), 'visualizador de story');
    await w.click('[data-act=sclose]');
    // cliente
    const c = await newPage();
    await c.goto(B + '/'); await c.click('text=Criar conta'); await c.click('[data-v=CLIENT]');
    await c.fill('[name=name]', 'Ana Cliente'); await c.fill('[name=email]', 'ana@teste.com'); await c.fill('[name=password]', 'Senha-forte-1');
    await c.fill('[name=phone]', '71977776666'); await c.fill('[name=city]', 'Salvador'); await c.selectOption('[name=state]', 'BA');
    await c.click('[name=terms]'); await c.click('button[type=submit]');
    await c.waitForSelector('article.card', { timeout: 15000 });
    ok(true, 'cliente vê o post do trabalhador');
    ok((await c.locator('article.card').first().innerText()).includes('WhatsApp'), 'contato do trabalhador aparece porque ele escolheu divulgar');
    await c.click('[data-act=like]'); await c.waitForSelector('[data-act=like].on');
    ok(true, 'curtir');
    await c.click('[data-act=cm]'); await c.fill('form[data-form=comment] input', 'Ficou ótimo!'); await c.click('form[data-form=comment] button');
    await c.waitForSelector('.cm .c', { timeout: 6000 }).catch(async (e) => { console.log('   DOM:', (await c.locator('article.card').first().innerText()).slice(-300), '| url', c.url()); await c.screenshot({ path: '/tmp/bigo-fail.png' }); throw e; });
    ok((await c.locator('.cm').innerText()).includes('Ficou ótimo!'), 'comentar');
    await c.click('.stories .st[data-act=story]'); await c.waitForSelector('.sv'); await c.click('[data-act=report][data-t=story]');
    await c.selectOption('[name=reason]', 'Spam'); await c.click('form[data-form=report] button'); await c.waitForTimeout(700);
    ok((await toastText(c)).includes('Denúncia enviada'), 'denunciar story');
    await c.goto(B + '/#/feed'); await c.waitForSelector('article.card');
    await c.click('[data-act=report][data-t=post]'); await c.selectOption('[name=reason]', 'Golpe ou fraude'); await c.click('form[data-form=report] button'); await c.waitForTimeout(700);
    // trabalhador vê notificações
    await w.goto(B + '/#/notifications'); await w.waitForSelector('.notif');
    ok((await w.locator('.notif').count()) >= 2, 'trabalhador recebe notificações (curtida/comentário)');
    // admin entra pela MESMA tela de login
    const a = await newPage();
    await a.goto(B + '/'); await a.fill('[name=login]', 'admin'); await a.fill('[name=password]', 'SenhaAdmin#2026'); await a.click('button[type=submit]');
    await a.waitForSelector('text=Painel ADM', { timeout: 8000 });
    ok(a.url().includes('#/admin'), 'admin entra pela tela de login comum e vai ao painel');
    ok((await a.locator('body').innerText()).includes('senha inicial'), 'aviso de troca da senha inicial');
    ok((await a.locator('.grid2').innerText()).includes('Total de usuários'), 'visão geral carrega');
    await a.click('[data-act=atab][data-v=reps]'); await a.waitForSelector('text=Golpe ou fraude');
    ok((await a.locator('body').innerText()).includes('Spam'), 'denúncias listadas');
    await a.click('[data-act=arep][data-v=hide] >> nth=0'); await a.waitForTimeout(800);
    await a.click('[data-act=atab][data-v=users]'); await a.waitForSelector('text=Ana Cliente');
    await a.click('[data-act=ablock][data-id] >> nth=0'); await a.waitForTimeout(600);
    // troca de senha do admin
    await a.click('[data-act=atab][data-v=admins]'); await a.waitForSelector('form[data-form=aaccess]');
    await a.fill('form[data-form=aaccess] [name=old]', 'SenhaAdmin#2026'); await a.fill('form[data-form=aaccess] [name=pw]', 'NovaSenha#9999'); await a.click('form[data-form=aaccess] button[type=submit]');
    await a.waitForTimeout(900);
    ok((await toastText(a)).includes('atualizados'), 'admin edita a própria senha');
    await a.reload(); await a.waitForSelector('text=Painel ADM');
    ok(!(await a.locator('body').innerText()).includes('senha inicial'), 'aviso some após trocar a senha');
    await a.click('[data-act=alogout]'); await a.waitForSelector('form[data-form=login]');
    await a.fill('[name=login]', 'admin'); await a.fill('[name=password]', 'NovaSenha#9999'); await a.click('button[type=submit]');
    await a.waitForSelector('text=Painel ADM');
    ok(true, 'login com a senha nova');
    // usuário não entra em #/admin
    await w.goto(B + '/#/admin'); await w.waitForTimeout(800);
    ok(!(await w.locator('body').innerText()).includes('Painel ADM'), 'usuário comum não acessa o painel');
    // conteúdo oculto some do feed do cliente
    await c.goto(B + '/#/feed'); await c.waitForTimeout(1200);
    // sessão persiste ao recarregar e logout
    await w.goto(B + '/#/feed'); await w.reload(); await w.waitForSelector('.nav');
    ok(true, 'sessão persiste ao recarregar');
    await w.goto(B + '/#/settings'); await w.click('[data-act=logout]'); await w.waitForSelector('form[data-form=login]');
    ok(true, 'sair');
    await w.goto(B + '/#/feed'); await w.waitForSelector('form[data-form=login]');
    ok(true, 'depois de sair, rota protegida volta ao login');
    await w.screenshot({ path: '/tmp/bigo-login.png' });
  } catch (e) { fail++; console.log('  EXCEÇÃO', e.message.split('\n')[0]); }
  ok(errs.length === 0, 'sem erros de JavaScript no console' + (errs.length ? ': ' + errs.slice(0, 3).join(' | ') : ''));
  await br.close(); srv.kill();
  if (fail) console.log('\n' + log.slice(-2500));
  console.log(`\n${pass} ok, ${fail} falhas`); process.exit(fail ? 1 : 0);
})();
