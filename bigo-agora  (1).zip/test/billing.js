'use strict';
// Pagamentos: testa a integração contra um Mercado Pago FALSO local (nenhum dinheiro, nenhuma chamada real).
const { spawn } = require('child_process');
const http = require('http');
const crypto = require('crypto');
const path = require('path');
const PORT = 3224, B = 'http://127.0.0.1:' + PORT, SECRET = 'segredo-webhook-teste';
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : fail++; console.log((c ? '  ok  ' : '  FALHA ') + m); };
const prefs = []; const mpPay = new Map(); // id -> pagamento "no Mercado Pago"
let seq = 9000;
const fake = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x'); const ch = []; req.on('data', (c) => ch.push(c));
  req.on('end', () => {
    const send = (s, o) => { res.writeHead(s, { 'content-type': 'application/json' }); res.end(JSON.stringify(o)); };
    if (req.headers.authorization !== 'Bearer TEST-token-falso') return send(401, { message: 'unauthorized' });
    if (req.method === 'POST' && u.pathname === '/checkout/preferences') { const b = JSON.parse(Buffer.concat(ch)); prefs.push(b); return send(201, { id: 'pref-' + prefs.length, init_point: 'https://mp.exemplo/checkout/' + prefs.length }); }
    if (u.pathname === '/v1/payments/search') return send(200, { results: [...mpPay.values()].filter((p) => p.external_reference === u.searchParams.get('external_reference')) });
    const m = u.pathname.match(/^\/v1\/payments\/(\d+)$/); if (m && mpPay.has(m[1])) return send(200, mpPay.get(m[1]));
    send(404, { message: 'not found' });
  });
});
async function call(method, p, { body, token, headers } = {}) {
  const h = { ...(headers || {}) }; if (token) h.Authorization = 'Bearer ' + token; if (body !== undefined) h['Content-Type'] = 'application/json';
  const r = await fetch(B + p, { method, headers: h, body: body !== undefined ? JSON.stringify(body) : undefined, redirect: 'manual' });
  let j = null; try { j = await r.clone().json(); } catch (_) {} return { s: r.status, j, r };
}
const sign = (dataId, reqId = 'req-1') => { const ts = String(Date.now()); const v1 = crypto.createHmac('sha256', SECRET).update(`id:${dataId};request-id:${reqId};ts:${ts};`).digest('hex'); return { 'x-signature': `ts=${ts},v1=${v1}`, 'x-request-id': reqId }; };
const hook = (id, headers) => call('POST', `/api/billing/webhook?data.id=${id}&type=payment`, { body: { type: 'payment', data: { id: String(id) } }, headers: headers || sign(id) });
const setMp = (ref, over) => { const id = String(++seq); mpPay.set(id, { id: Number(id), external_reference: ref, status: 'approved', transaction_amount: 29.9, currency_id: 'BRL', payment_type_id: 'bank_transfer', payment_method_id: 'pix', ...over }); return id; };

fake.listen(9444, async () => {
  const srv = spawn('node', [path.join(__dirname, '..', 'src', 'index.js')], { env: { ...process.env, APP_ENV: 'demo', PORT: String(PORT), UPLOAD_DIR: '/tmp/bigo-bill', ADMIN_PASSWORD: 'SenhaAdmin#2026', JWT_SECRET: 'w'.repeat(40), MP_ACCESS_TOKEN: 'TEST-token-falso', MP_API_URL: 'http://127.0.0.1:9444', APP_URL: B, MP_WEBHOOK_SECRET: SECRET }, stdio: ['ignore', 'pipe', 'pipe'] });
  let log = ''; srv.stdout.on('data', (d) => (log += d)); srv.stderr.on('data', (d) => (log += d));
  for (let i = 0; i < 50; i++) { try { if ((await call('GET', '/api/health')).s === 200) break; } catch (_) {} await new Promise((r) => setTimeout(r, 200)); }
  try {
    const AT = (await call('POST', '/api/auth/login', { body: { login: 'admin', password: 'SenhaAdmin#2026' } })).j.accessToken;
    const reg = async (role, email, extra) => (await call('POST', '/api/auth/register', { body: { acceptTerms: true, role, email, password: 'Senha-forte-1', name: 'Fulano ' + role, city: 'Salvador', state: 'BA', phone: '71999990000', ...extra } })).j;
    const W = await reg('WORKER', 'w@t.com', { profession: 'Pintor' }), C = await reg('CLIENT', 'c@t.com');

    console.log('Planos');
    let r = await call('GET', '/api/billing/plans', { token: W.accessToken });
    ok(r.s === 200 && r.j.enabled === true && r.j.items.length === 0, 'sem planos cadastrados: lista vazia (nada de plano inventado)');
    ok((await call('POST', '/api/admin/plans', { token: W.accessToken, body: {} })).s === 401, 'usuário comum não cria plano');
    r = await call('POST', '/api/admin/plans', { token: AT, body: { name: 'VIP', description: 'Mais destaque', audience: 'WORKER', priceCents: 2990, durationDays: 30, benefits: { destaque: true } } });
    ok(r.s === 201, 'admin cria plano VIP'); const planId = r.j.id;
    r = await call('POST', '/api/admin/plans', { token: AT, body: { name: 'Antigo', audience: 'WORKER', priceCents: 100, durationDays: 30 } });
    await call('PATCH', '/api/admin/plans/' + r.j.id, { token: AT, body: { active: false } });
    ok((await call('POST', '/api/admin/plans', { token: AT, body: { name: 'X', audience: 'WORKER', priceCents: -5, durationDays: 30 } })).s === 400, 'preço negativo recusado');
    r = await call('GET', '/api/billing/plans', { token: W.accessToken });
    ok(r.j.items.length === 1 && r.j.items[0].name === 'VIP', 'trabalhador vê só o plano ativo');
    ok((await call('GET', '/api/billing/plans', { token: C.accessToken })).j.items.length === 0, 'cliente não vê plano de trabalhador');
    ok((await call('POST', '/api/billing/checkout', { token: C.accessToken, body: { planId } })).s === 404, 'cliente não compra plano de trabalhador');

    console.log('Checkout');
    r = await call('POST', '/api/billing/checkout', { token: W.accessToken, body: { planId } });
    ok(r.s === 201 && /^https:\/\/mp\.exemplo\/checkout\//.test(r.j.checkoutUrl), 'checkout devolve a URL do Mercado Pago');
    const pid = r.j.paymentId, pr = prefs[0];
    ok(pr.items[0].unit_price === 29.9 && pr.external_reference === pid && pr.items[0].currency_id === 'BRL', 'preço vem do plano no servidor (29,90) e referência = id do pagamento');
    ok(pr.payment_methods.excluded_payment_types.some((t) => t.id === 'ticket'), 'boleto excluído (Pix e cartão)');
    ok(pr.notification_url === B + '/api/billing/webhook', 'URL do webhook enviada');
    r = await call('POST', '/api/billing/checkout', { token: W.accessToken, body: { planId, price: 1 } });
    ok(prefs[1].items[0].unit_price === 29.9, 'preço enviado pelo cliente é ignorado');
    const pid2 = r.j.paymentId;
    r = await call('GET', '/api/billing/return?ref=' + pid);
    ok(r.s === 302 && r.r.headers.get('location') === '/#/plano?ref=' + pid, 'retorno do Mercado Pago leva ao app');
    r = await call('GET', '/api/billing/payments/' + pid, { token: W.accessToken });
    ok(r.s === 200 && r.j.status === 'PENDING', 'pagamento nasce PENDENTE');
    ok((await call('GET', '/api/billing/payments/' + pid, { token: C.accessToken })).s === 404, 'outro usuário não vê o pagamento');

    console.log('Webhook');
    const mid = setMp(pid, { status: 'approved' });
    ok((await hook(mid, { 'x-signature': 'ts=1,v1=00', 'x-request-id': 'r' })).s === 401, 'assinatura inválida = 401');
    ok((await call('GET', '/api/billing/me', { token: W.accessToken })).j.subscription === null, 'nada liberado sem confirmação');
    const pend = setMp(pid, { status: 'pending' });
    ok((await hook(pend)).s === 200 && (await call('GET', '/api/billing/me', { token: W.accessToken })).j.subscription === null, 'pagamento pendente não libera o plano');
    ok((await hook(mid)).s === 200, 'webhook válido aceito');
    r = await call('GET', '/api/billing/me', { token: W.accessToken });
    ok(r.j.subscription && r.j.subscription.planName === 'VIP' && r.j.subscription.benefits.destaque === true, 'plano VIP ativado após confirmação');
    const ends1 = r.j.subscription.endsAt;
    ok(r.j.payments.some((p) => p.status === 'PAID' && p.method === 'bank_transfer:pix'), 'pagamento PAID via Pix registrado');
    await hook(mid); await hook(mid);
    r = await call('GET', '/api/billing/me', { token: W.accessToken });
    ok(r.j.subscription.endsAt === ends1, 'webhook repetido não estende o plano duas vezes');
    r = await call('GET', '/api/notifications', { token: W.accessToken });
    ok(JSON.stringify(r.j).includes('Pagamento confirmado'), 'usuário é notificado');
    ok((await call('POST', '/api/billing/webhook', { body: { type: 'payment', data: { id: '1' } }, headers: {} })).s === 401, 'webhook sem assinatura = 401 (segredo configurado)');
    ok((await call('POST', '/api/billing/webhook', { body: { type: 'merchant_order', data: { id: '1' } } })).s === 200, 'outros tipos de evento são ignorados');

    console.log('Fraude e conferência');
    const bad = setMp(pid2, { status: 'approved', transaction_amount: 1.0 });
    await hook(bad);
    r = await call('GET', '/api/billing/payments/' + pid2, { token: W.accessToken });
    ok(r.j.status !== 'PAID', 'valor diferente do plano NÃO libera');
    const good = setMp(pid2, { status: 'approved' }); mpPay.delete(bad);
    r = await call('GET', '/api/billing/payments/' + pid2, { token: W.accessToken });
    ok(r.j.status === 'PAID', 'sem webhook, a conferência direta no Mercado Pago confirma');
    r = await call('GET', '/api/billing/me', { token: W.accessToken });
    ok(new Date(r.j.subscription.endsAt) - new Date(ends1) > 29 * 86400e3, 'renovação soma 30 dias ao plano em vigor');

    console.log('Estorno e administração');
    mpPay.get(good).status = 'refunded'; await hook(good);
    r = await call('GET', '/api/billing/me', { token: W.accessToken });
    ok(r.j.payments.some((p) => p.status === 'REFUNDED'), 'estorno registrado');
    r = await call('GET', '/api/admin/payments', { token: AT });
    ok(r.s === 200 && r.j.items.length === 2 && r.j.paidCount >= 1, 'admin lista pagamentos');
    console.log('     total pago (centavos):', r.j.totalPaidCents);
    ok(!JSON.stringify(r.j).includes('TEST-token'), 'token do Mercado Pago nunca aparece nas respostas');
    ok(!(await (await fetch(B + '/')).text()).includes('TEST-token'), 'nem no HTML');
  } catch (e) { fail++; console.log('EXCEÇÃO', e.stack); }
  srv.kill(); fake.close();
  if (fail) console.log(log.slice(-2500));
  console.log(`\n${pass} ok, ${fail} falhas`); process.exit(fail ? 1 : 0);
});
