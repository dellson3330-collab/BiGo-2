'use strict';
// Funções novas (ordens de serviço, VIP, busca, rede, anúncios): testa a integração contra um Mercado Pago FALSO local (nenhum dinheiro, nenhuma chamada real).
const { spawn } = require('child_process');
const http = require('http');
const crypto = require('crypto');
const path = require('path');
const PORT = 3225, B = 'http://127.0.0.1:' + PORT, SECRET = 'segredo-webhook-teste';
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : fail++; console.log((c ? '  ok  ' : '  FALHA ') + m); };
const prefs = []; const mpPay = new Map(); // id -> pagamento "no Mercado Pago"
let seq = 9000;
const fake = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x'); const ch = []; req.on('data', (c) => ch.push(c));
  req.on('end', () => {
    const send = (s, o) => { res.writeHead(s, { 'content-type': 'application/json' }); res.end(JSON.stringify(o)); };
    if (req.headers.authorization !== 'Bearer TEST-token-falso') return send(401, { message: 'unauthorized' });
    if (req.method === 'POST' && u.pathname === '/checkout/preferences') { const b = JSON.parse(Buffer.concat(ch)); prefs.push(b); return send(201, { id: 'pref-' + prefs.length, init_point: 'https://mp.exemplo/checkout/' + prefs.length }); }
    if (u.pathname === '/v1/payments/search') return send(200, { results: [...mpPay.values()].filter((p) => p.external_reference === u.searchParams.get('external_reference')) });
    const m = u.pathname.match(/^\/v1\/payments\/(\d+)$/); if (m && mpPay.has(m[1])) return send(200, mpPay.get(m[1]));
    send(404, { message: 'not found' });
  });
});
async function call(method, p, { body, token, headers, raw } = {}) {
  const h = { ...(headers || {}) }; if (token) h.Authorization = 'Bearer ' + token; if (body !== undefined) h['Content-Type'] = 'application/json';
  const r = await fetch(B + p, { method, headers: h, body: raw || (body !== undefined ? JSON.stringify(body) : undefined), redirect: 'manual' });
  let j = null; try { j = await r.clone().json(); } catch (_) {} return { s: r.status, j, r };
}
const sign = (dataId, reqId = 'req-1') => { const ts = String(Date.now()); const v1 = crypto.createHmac('sha256', SECRET).update(`id:${dataId};request-id:${reqId};ts:${ts};`).digest('hex'); return { 'x-signature': `ts=${ts},v1=${v1}`, 'x-request-id': reqId }; };
const hook = (id, headers) => call('POST', `/api/billing/webhook?data.id=${id}&type=payment`, { body: { type: 'payment', data: { id: String(id) } }, headers: headers || sign(id) });
const setMp = (ref, over) => { const id = String(++seq); mpPay.set(id, { id: Number(id), external_reference: ref, status: 'approved', transaction_amount: 29.9, currency_id: 'BRL', payment_type_id: 'bank_transfer', payment_method_id: 'pix', ...over }); return id; };

fake.listen(9444, async () => {
  const srv = spawn('node', [path.join(__dirname, '..', 'src', 'index.js')], { env: { ...process.env, APP_ENV: 'demo', PORT: String(PORT), UPLOAD_DIR: '/tmp/bigo-feat', ADMIN_PASSWORD: 'SenhaAdmin#2026', JWT_SECRET: 'v'.repeat(40), APP_URL: B, MP_ACCESS_TOKEN: 'TEST-token-falso', MP_WEBHOOK_SECRET: SECRET, MP_API_URL: 'http://127.0.0.1:9444' }, stdio: ['ignore', 'pipe', 'pipe'] });
  let log = ''; srv.stdout.on('data', (d) => (log += d)); srv.stderr.on('data', (d) => (log += d));
  for (let i = 0; i < 50; i++) { try { if ((await call('GET', '/api/health')).s === 200) break; } catch (_) {} await new Promise((r) => setTimeout(r, 200)); }
  const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
  try {
    const AT = (await call('POST', '/api/auth/login', { body: { login: 'admin', password: 'SenhaAdmin#2026' } })).j.accessToken;
    let n = 0;
    const reg = async (role, name, city, extra) => (await call('POST', '/api/auth/register', { body: { acceptTerms: true, role, email: 'u' + (++n) + '@t.com', password: 'Senha-forte-1', name, city, state: 'BA', phone: '7199999' + String(1000 + n), ...extra } })).j;
    const W1 = await reg('WORKER', 'Pedro Pintor', 'Salvador', { profession: 'Pintor', showContact: true });   // Salvador, pintor
    const W2 = await reg('WORKER', 'Eli Eletricista', 'Salvador', { profession: 'Eletricista' });             // Salvador, eletricista
    const W3 = await reg('WORKER', 'Paulo Pintor', 'Feira de Santana', { profession: 'Pintor' });             // outra cidade
    const C = await reg('CLIENT', 'Ana Cliente', 'Salvador');

    console.log('Ordem de serviço');
    let r = await call('POST', '/api/orders', { token: W1.accessToken, body: { title: 'x' } });
    ok(r.s === 403, 'prestador não cria ordem');
    r = await call('POST', '/api/orders', { token: C.accessToken, body: { title: 'Pintar sala e quarto', description: '2 cômodos', profession: 'Pintor', bairro: 'Pituba', address: 'Rua das Flores, 123', whatsapp: '71988887777' } });
    ok(r.s === 201 && r.j.notified === 1, 'cliente cria ordem; só 1 prestador (pintor da mesma cidade) é avisado');
    const oid = r.j.id;
    const cnt = async (t) => (await call('GET', '/api/notifications/count', { token: t })).j.unread;
    ok((await cnt(W1.accessToken)) >= 1 && (await cnt(W2.accessToken)) === 0 && (await cnt(W3.accessToken)) === 0, 'notificação só para pintor de Salvador (ícone do sino)');
    r = await call('GET', '/api/notifications', { token: W1.accessToken });
    ok(r.j.items[0].text.includes('Nova ordem de serviço em Salvador') && r.j.items[0].link === '/orders', 'texto e link da notificação');
    r = await call('GET', '/api/orders', { token: W1.accessToken });
    ok(r.s === 200 && r.j.vip === false && r.j.items.length === 1, 'prestador vê a ordem da cidade');
    ok(r.j.items[0].contact === null && !JSON.stringify(r.j).includes('Rua das Flores') && !JSON.stringify(r.j).includes('71988887777'), 'NÃO-VIP não recebe endereço nem WhatsApp (nem escondido no JSON)');
    ok(r.j.items[0].client.name === 'Ana' && r.j.items[0].bairro === 'Pituba', 'vê informações gerais (bairro, primeiro nome)');
    ok((await call('GET', '/api/orders', { token: W2.accessToken })).j.items.length === 0, 'eletricista não vê ordem de pintor');
    ok((await call('GET', '/api/orders', { token: W3.accessToken })).j.items.length === 0, 'prestador de outra cidade não vê');
    r = await call('GET', '/api/orders', { token: C.accessToken });
    ok(r.j.items.length === 1 && r.j.items[0].address === 'Rua das Flores, 123', 'cliente vê as próprias ordens com todos os dados');

    console.log('VIP libera o contato');
    r = await call('POST', '/api/admin/plans', { token: AT, body: { name: 'VIP', audience: 'WORKER', priceCents: 2990, durationDays: 30 } });
    const planId = r.j.id;
    r = await call('POST', '/api/billing/checkout', { token: W1.accessToken, body: { planId } });
    const pid = r.j.paymentId; const mid = setMp(pid, { status: 'approved' });
    ok((await hook(mid)).s === 200, 'pagamento do VIP confirmado');
    r = await call('GET', '/api/orders', { token: W1.accessToken });
    ok(r.j.vip === true && r.j.items[0].contact.address === 'Rua das Flores, 123' && r.j.items[0].contact.whatsapp === '71988887777', 'VIP vê endereço e WhatsApp');
    ok((await call('GET', '/api/billing/me', { token: W1.accessToken })).j.vip === true, '/billing/me informa vip');
    ok((await call('POST', `/api/orders/${oid}/close`, { token: W1.accessToken })).s === 404, 'prestador não fecha ordem alheia');
    ok((await call('POST', `/api/orders/${oid}/close`, { token: C.accessToken })).s === 200, 'cliente fecha a ordem');
    ok((await call('GET', '/api/orders', { token: W1.accessToken })).j.items.length === 0, 'ordem fechada some para prestadores');

    console.log('Busca, rede e seguir');
    r = await call('GET', '/api/search?q=pint', { token: C.accessToken });
    ok(r.s === 200 && r.j.items.length === 2 && r.j.items.every((x) => x.profession === 'Pintor'), 'lupa acha profissionais por profissão');
    ok(!JSON.stringify(r.j).includes('@t.com') && !JSON.stringify(r.j).includes('7199999'), 'busca não vaza e-mail nem telefone');
    ok((await call('GET', '/api/search?q=ana', { token: W1.accessToken })).j.items.some((x) => x.name === 'Ana Cliente'), 'lupa acha contas por nome');
    ok((await call('GET', '/api/search?q=a', { token: C.accessToken })).j.items.length === 0, 'termo curto não pesquisa');
    ok((await call('GET', '/api/search?q=%25', { token: C.accessToken })).j.items.length === 0, 'curinga % tratado como texto');
    r = await call('GET', '/api/network', { token: C.accessToken });
    ok(r.j.items.length === 3 && r.j.items[0].city === 'Salvador', 'rede de profissionais: mesma cidade primeiro');
    await call('POST', `/api/users/${W1.user.id}/follow`, { token: C.accessToken });
    ok((await call('GET', '/api/network', { token: C.accessToken })).j.items.length === 2, 'quem já sigo sai das sugestões');
    r = await call('POST', '/api/media', { token: W2.accessToken, raw: PNG });
    r = await call('POST', '/api/posts', { token: W2.accessToken, body: { text: 'Instalação elétrica', mediaIds: [r.j.id] } });
    const feed = await call('GET', '/api/feed', { token: C.accessToken });
    ok(feed.j.items[0].author.following === false, 'post informa se já sigo o autor (botão Seguir no feed)');
    await call('POST', `/api/users/${W2.user.id}/follow`, { token: C.accessToken });
    ok((await call('GET', '/api/feed', { token: C.accessToken })).j.items[0].author.following === true, 'depois de seguir, vira Seguindo');

    console.log('Anúncios pagos');
    ok((await call('GET', '/api/ads/feed', { token: C.accessToken })).j.items.length === 0, 'sem anúncio pago, nada no feed');
    r = await call('POST', '/api/admin/ad-packages', { token: AT, body: { name: 'Semana', priceCents: 1990, durationDays: 7 } });
    ok(r.s === 201, 'ADM cria pacote de anúncio'); const pkg = r.j.id;
    ok((await call('POST', '/api/admin/ad-packages', { token: W1.accessToken, body: { name: 'x', priceCents: 1000, durationDays: 7 } })).s === 401, 'usuário comum não cria pacote');
    ok((await call('GET', '/api/ads/packages', { token: W1.accessToken })).j.items.length === 1, 'prestador vê pacotes');
    ok((await call('POST', '/api/ads', { token: C.accessToken, body: { packageId: pkg, title: 'Anúncio', whatsapp: '71988887777' } })).s === 403, 'cliente não anuncia');
    ok((await call('POST', '/api/ads', { token: W1.accessToken, body: { packageId: pkg, title: 'Sem contato' } })).s === 400, 'anúncio exige WhatsApp ou link');
    ok((await call('POST', '/api/ads', { token: W1.accessToken, body: { packageId: pkg, title: 'Golpe', targetUrl: 'javascript:alert(1)' } })).s === 400, 'link inseguro recusado');
    const up = await call('POST', '/api/media', { token: W1.accessToken, raw: PNG });
    r = await call('POST', '/api/ads', { token: W1.accessToken, body: { packageId: pkg, title: 'Pinturas Pedro', body: '10% off', whatsapp: '71988887777', mediaId: up.j.id, city: 'Salvador' } });
    ok(r.s === 201 && /^https:\/\/mp\.exemplo\//.test(r.j.checkoutUrl), 'anúncio criado e checkout gerado'); const adId = r.j.adId, apid = r.j.paymentId;
    ok(prefs[prefs.length - 1].items[0].unit_price === 19.9, 'preço do anúncio vem do pacote');
    ok((await call('GET', '/api/ads/feed', { token: C.accessToken })).j.items.length === 0, 'NÃO aparece antes de pagar');
    r = await call('GET', '/api/billing/return?k=ad&ref=' + apid);
    ok(r.r.headers.get('location') === '/#/ads?ref=' + apid, 'retorno do anúncio volta para /ads');
    const amid = setMp(apid, { status: 'approved', transaction_amount: 19.9 });
    ok((await hook(amid)).s === 200, 'pagamento do anúncio confirmado');
    r = await call('GET', '/api/ads/feed', { token: C.accessToken });
    ok(r.j.items.length === 1 && r.j.items[0].title === 'Pinturas Pedro' && r.j.items[0].imageUrl, 'anúncio pago aparece no feed');
    ok((await call('GET', '/api/ads/feed', { token: W3.accessToken })).j.items.length === 0, 'anúncio de Salvador não aparece em outra cidade');
    await call('POST', '/api/ads/views', { token: C.accessToken, body: { ids: [adId] } }); await call('POST', `/api/ads/${adId}/click`, { token: C.accessToken });
    r = await call('GET', '/api/ads/mine', { token: W1.accessToken });
    ok(r.j.items[0].status === 'ACTIVE' && r.j.items[0].impressions === 1 && r.j.items[0].clicks === 1, 'anunciante vê status, impressões e cliques');
    ok((await hook(amid)).s === 200 && (await call('GET', '/api/ads/mine', { token: W1.accessToken })).j.items[0].endsAt === r.j.items[0].endsAt, 'webhook repetido não estende o anúncio');
    r = await call('PATCH', `/api/admin/ads/${adId}`, { token: AT, body: { action: 'pause' } });
    ok(r.s === 200 && (await call('GET', '/api/ads/feed', { token: C.accessToken })).j.items.length === 0, 'ADM pausa e o anúncio sai do ar');
    r = await call('GET', '/api/admin/ads', { token: AT });
    ok(r.j.items[0].owner === 'Pedro Pintor' && r.j.packages.length === 1, 'ADM lista anúncios e pacotes');
    ok((await call('DELETE', `/api/ads/${adId}`, { token: W1.accessToken })).s === 200, 'anunciante exclui anúncio pausado');
  } catch (e) { fail++; console.log('EXCEÇÃO', e.stack); }
  srv.kill(); fake.close();
  if (fail) console.log(log.slice(-2500));
  console.log(`\n${pass} ok, ${fail} falhas`); process.exit(fail ? 1 : 0);
});
