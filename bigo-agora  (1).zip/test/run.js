'use strict';
// Teste ponta a ponta: sobe o servidor contra um PostgreSQL de teste e exercita a API.
// Uso: DATABASE_URL=... node test/run.js   (com NODE_PATH apontando para test/shim se o pacote pg não estiver instalado)
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const PORT = 3222, B = 'http://127.0.0.1:' + PORT;
const ADMINPW = 'SenhaAdmin#2026';
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log('  ok  ' + m); } else { fail++; console.log('  FALHA ' + m); } };
async function call(method, p, { body, token, raw, headers } = {}) {
  const h = { ...(headers || {}) };
  if (token) h.Authorization = 'Bearer ' + token;
  let b = raw;
  if (body !== undefined) { h['Content-Type'] = 'application/json'; b = JSON.stringify(body); }
  const r = await fetch(B + p, { method, headers: h, body: b, redirect: 'manual' });
  let j = null; try { j = await r.clone().json(); } catch (_) {}
  return { s: r.status, j, r };
}
// imagens mínimas válidas
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
const MP4 = Buffer.concat([Buffer.from([0, 0, 0, 24]), Buffer.from('ftypisom'), Buffer.alloc(40)]);

async function main() {
  fs.rmSync('/tmp/bigo-test-up', { recursive: true, force: true });
  const srv = spawn('node', [path.join(__dirname, '..', 'src', 'index.js')], {
    env: { ...process.env, APP_ENV: 'demo', PORT: String(PORT), UPLOAD_DIR: '/tmp/bigo-test-up', ADMIN_PASSWORD: ADMINPW, JWT_SECRET: 'x'.repeat(40) },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let log = ''; srv.stdout.on('data', (d) => (log += d)); srv.stderr.on('data', (d) => (log += d));
  for (let i = 0; i < 50; i++) { try { if ((await call('GET', '/api/health')).s === 200) break; } catch (_) {} await new Promise((r) => setTimeout(r, 200)); }
  try { await suite(); } catch (e) { fail++; console.log('  EXCEÇÃO', e.stack); }
  srv.kill();
  if (fail) console.log('\n--- log do servidor ---\n' + log.slice(-3000));
  console.log(`\n${pass} ok, ${fail} falhas`);
  process.exit(fail ? 1 : 0);
}

async function suite() {
  console.log('Básico');
  ok((await call('GET', '/api/health')).s === 200, 'health');
  const cats = (await call('GET', '/api/categories')).j;
  ok(Array.isArray(cats) && cats.length === 5, 'categorias padrão');
  ok((await call('GET', '/api/me')).s === 401, '/me sem token = 401');
  ok((await call('GET', '/api/admin/overview')).s === 401, 'admin sem token = 401');

  console.log('Cadastro e login');
  const reg = (o) => call('POST', '/api/auth/register', { body: { acceptTerms: true, password: 'Senha-forte-1', city: 'Salvador', state: 'BA', phone: '71999990000', ...o } });
  let r = await reg({ role: 'WORKER', email: 'ze@teste.com', name: 'Zé Pintor', profession: 'Pintor' });
  ok(r.s === 201 && r.j.accessToken && r.j.refreshToken, 'cadastro trabalhador');
  const W = r.j; const wid = r.j.user.id;
  r = await reg({ role: 'CLIENT', email: 'ana@teste.com', name: 'Ana Cliente' });
  ok(r.s === 201, 'cadastro cliente'); const C = r.j;
  ok((await reg({ role: 'CLIENT', email: 'ana@teste.com', name: 'Outra' })).s === 409, 'e-mail duplicado = 409');
  ok((await call('POST', '/api/auth/register', { body: { role: 'CLIENT', email: 'x@y.com', password: 'Senha-forte-1', name: 'X', city: 'A', state: 'BA' } })).s === 400, 'sem aceite de termos = 400');
  ok((await reg({ role: 'CLIENT', email: 'fraca@teste.com', name: 'Fraca', password: '123' })).s === 400, 'senha fraca = 400');
  ok((await reg({ role: 'WORKER', email: 'p@teste.com', name: 'Prof', profession: 'Astronauta' })).s === 400, 'profissão fora da lista = 400');
  r = await call('POST', '/api/auth/login', { body: { login: 'ze@teste.com', password: 'errada' } });
  ok(r.s === 401, 'senha errada = 401');
  r = await call('POST', '/api/auth/login', { body: { login: 'ze@teste.com', password: 'Senha-forte-1' } });
  ok(r.s === 200 && r.j.kind === 'user', 'login usuário');
  r = await call('GET', '/api/me', { token: W.accessToken });
  ok(r.s === 200 && r.j.email === 'ze@teste.com' && !('passwordHash' in r.j) && !('password_hash' in r.j), '/me sem hash de senha');

  console.log('Refresh com rotação');
  r = await call('POST', '/api/auth/refresh', { body: { refreshToken: W.refreshToken } });
  ok(r.s === 200 && r.j.refreshToken && r.j.refreshToken !== W.refreshToken, 'refresh rotaciona');
  const newRt = r.j.refreshToken;
  r = await call('POST', '/api/auth/refresh', { body: { refreshToken: W.refreshToken } });
  ok(r.s === 401, 'token antigo reutilizado = 401');
  r = await call('POST', '/api/auth/refresh', { body: { refreshToken: newRt } });
  ok(r.s === 401, 'reuso derruba a família inteira');
  r = await call('POST', '/api/auth/login', { body: { login: 'ze@teste.com', password: 'Senha-forte-1' } });
  const WT = r.j.accessToken;

  console.log('Mídia (disco local)');
  r = await call('POST', '/api/media', { token: WT, raw: PNG, headers: { 'Content-Type': 'image/png' } });
  ok(r.s === 201 && r.j.id && r.j.kind === 'image', 'upload PNG');
  const img1 = r.j.id;
  r = await call('POST', '/api/media', { token: WT, raw: PNG });
  const img2 = r.j.id;
  r = await call('POST', '/api/media', { token: WT, raw: MP4 });
  ok(r.s === 201 && r.j.kind === 'video', 'upload MP4 (por conteúdo)'); const vid = r.j.id;
  r = await call('POST', '/api/media', { token: WT, raw: Buffer.from('MZ este nao e uma imagem de verdade, e um executavel') });
  ok(r.s === 415, 'arquivo falso rejeitado (415)');
  r = await call('POST', '/api/media', { token: WT, raw: Buffer.concat([Buffer.from([0, 0, 0, 24]), Buffer.from('ftypheic'), Buffer.alloc(40)]) });
  ok(r.s === 415, 'HEIC rejeitado com mensagem');
  r = await fetch(B + '/media/' + img1);
  ok(r.status === 200 && r.headers.get('content-type') === 'image/png', 'GET /media/:id');
  r = await fetch(B + '/media/' + vid, { headers: { Range: 'bytes=0-9' } });
  ok(r.status === 206 && (await r.arrayBuffer()).byteLength === 10, 'Range 206');

  console.log('Publicações');
  r = await call('POST', '/api/posts', { token: C.accessToken, body: { text: 'oi tudo bem', mediaIds: [img1] } });
  ok(r.s === 403, 'cliente não publica');
  r = await call('POST', '/api/posts', { token: WT, body: { text: 'Pintura completa de apartamento', mediaIds: [img1, img2], beforeAfter: true, priceText: 'A partir de R$ 30/m²' } });
  ok(r.s === 201 && r.j.media && r.j.media.length === 2, 'publicar antes/depois');
  const post = r.j;
  r = await call('POST', '/api/posts', { token: WT, body: { text: 'reuso de midia', mediaIds: [img1] } });
  ok(r.s === 400, 'mídia já usada = 400');
  r = await call('POST', '/api/posts', { token: C.accessToken, body: { text: 'x', mediaIds: [] } });
  r = await call('GET', '/api/feed', { token: C.accessToken });
  ok(r.s === 200 && (r.j.items || r.j.posts || r.j).length >= 1, 'feed lista o post');
  r = await call('GET', '/api/feed?filter=ba', { token: C.accessToken });
  ok(r.s === 200, 'feed filtro ba');
  r = await call('POST', `/api/posts/${post.id}/like`, { token: C.accessToken });
  ok(r.s === 200, 'curtir');
  r = await call('POST', `/api/posts/${post.id}/comments`, { token: C.accessToken, body: { text: 'Ficou ótimo!' } });
  ok(r.s === 201, 'comentar'); const cm = r.j;
  r = await call('GET', `/api/posts/${post.id}/comments`, { token: C.accessToken });
  ok(r.s === 200 && JSON.stringify(r.j).includes('ótimo'), 'listar comentários');
  r = await call('POST', `/api/users/${wid}/follow`, { token: C.accessToken });
  ok(r.s === 200, 'seguir');
  r = await call('GET', '/api/notifications', { token: WT });
  ok(r.s === 200 && JSON.stringify(r.j).length > 20, 'notificações do trabalhador');
  r = await call('GET', `/api/users/${wid}`, { token: C.accessToken });
  console.log('     ', JSON.stringify(r.j).slice(0,300)); ok(r.s === 200 && r.j.worker && r.j.worker.profession === 'Pintor', 'perfil público');
  r = await call('GET', `/api/users/${wid}`, { token: C.accessToken });
  ok(!JSON.stringify(r.j).includes('password'), 'perfil sem dados de senha');

  console.log('Stories');
  r = await call('POST', '/api/stories', { token: WT, body: { mediaId: vid, text: 'Obra de hoje' } });
  ok(r.s === 201, 'publicar story');
  r = await call('GET', '/api/stories', { token: C.accessToken });
  ok(r.s === 200 && JSON.stringify(r.j).includes('Obra de hoje'), 'story aparece para outros');
  const sid = (JSON.stringify(r.j).match(/"id":"([0-9a-f-]{36})"[^}]*"text":"Obra de hoje"/) || [])[1];

  console.log('Denúncia');
  r = await call('POST', '/api/reports', { token: C.accessToken, body: { targetType: 'post', targetId: post.id, reason: 'Conteúdo impróprio', details: 'teste' } });
  ok(r.s === 201 || r.s === 200, 'denunciar post');

  console.log('Admin');
  r = await call('POST', '/api/auth/login', { body: { login: 'admin', password: 'errada' } });
  ok(r.s === 401, 'admin senha errada');
  r = await call('POST', '/api/auth/login', { body: { login: 'admin', password: ADMINPW } });
  ok(r.s === 200 && r.j.kind === 'admin', 'login admin pela tela comum');
  const AT = r.j.accessToken;
  ok((await call('GET', '/api/admin/overview', { token: WT })).s === 401 || true, 'token de usuário no admin');
  ok([401, 403].includes((await call('GET', '/api/admin/overview', { token: WT })).s), 'token de usuário não acessa admin');
  r = await call('GET', '/api/admin/overview', { token: AT });
  ok(r.s === 200, 'overview'); console.log('     ', JSON.stringify(r.j).slice(0, 200));
  r = await call('GET', '/api/admin/users', { token: AT });
  ok(r.s === 200 && JSON.stringify(r.j).includes('ze@teste.com'), 'admin lista usuários');
  r = await call('GET', '/api/admin/reports', { token: AT });
  ok(r.s === 200, 'admin lista denúncias');
  const repId = (JSON.stringify(r.j).match(/"id":"([0-9a-f-]{36})"/) || [])[1];
  r = await call('POST', `/api/admin/reports/${repId}/action`, { token: AT, body: { action: 'hide' } });
  ok(r.s === 200, 'ocultar via denúncia');
  r = await call('GET', '/api/feed', { token: C.accessToken });
  ok(!JSON.stringify(r.j).includes(post.id), 'post oculto some do feed');
  r = await call('POST', `/api/admin/users/${C.user.id}/block`, { token: AT, body: { reason: 'teste' } });
  ok(r.s === 200, 'bloquear usuário');
  r = await call('GET', '/api/me', { token: C.accessToken });
  ok(r.s === 401 || r.s === 403, 'usuário bloqueado perde acesso');
  r = await call('POST', '/api/auth/login', { body: { login: 'ana@teste.com', password: 'Senha-forte-1' } });
  ok(r.s === 403 || r.s === 401, 'bloqueado não entra');
  r = await call('PATCH', '/api/admin/me', { token: AT, body: { oldPassword: ADMINPW, newPassword: 'NovaSenha#9999' } });
  ok(r.s === 200, 'admin troca a própria senha');
  r = await call('POST', '/api/auth/login', { body: { login: 'admin', password: 'NovaSenha#9999' } });
  ok(r.s === 200 && r.j.kind === 'admin', 'login com a senha nova');
  r = await call('GET', '/api/admin/logs', { token: AT });
  ok(r.s === 200 && JSON.stringify(r.j).length > 50, 'log de auditoria');

  console.log('Conta / LGPD');
  r = await call('GET', '/api/me/export', { token: WT });
  ok(r.s === 200 && !JSON.stringify(r.j).includes('password_hash'), 'exportar meus dados');
  r = await call('DELETE', '/api/me', { token: WT, body: { password: 'Senha-forte-1' } });
  ok(r.s === 200, 'excluir conta');
  r = await call('POST', '/api/auth/login', { body: { login: 'ze@teste.com', password: 'Senha-forte-1' } });
  ok(r.s === 401, 'conta excluída não entra');
  r = await fetch(B + '/media/' + img1);
  ok(r.status === 404, 'mídia removida junto com a conta');

  console.log('Segurança');
  r = await fetch(B + '/api/health', { headers: { Origin: 'https://qualquer.com' } });
  ok(r.headers.get('x-content-type-options') === 'nosniff', 'cabeçalhos de segurança');
  r = await call('POST', '/api/auth/login', { body: '{' });
  ok(r.s === 400 || r.s === 401, 'JSON inválido não derruba');
  let last = 0; for (let i = 0; i < 8; i++) last = (await call('POST', '/api/auth/login', { body: { login: 'lock@teste.com', password: 'x' } })).s;
  ok(last === 401 || last === 429, 'tentativas repetidas limitadas');
}
main();
