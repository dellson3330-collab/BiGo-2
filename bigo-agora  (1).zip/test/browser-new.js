'use strict';
// Telas novas: ordem de serviço (VIP), lupa, rede de profissionais, olho da senha, seguir, anúncios.
const { spawn } = require('child_process');
const path = require('path');
const { chromium } = require('playwright');
const PORT = 3350, B = 'http://127.0.0.1:' + PORT;
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : fail++; console.log((c ? '  ok  ' : '  FALHA ') + m); };
(async () => {
  const srv = spawn('node', [path.join(__dirname, '..', 'src', 'index.js')], { env: { ...process.env, APP_ENV: 'demo', PORT: String(PORT), UPLOAD_DIR: '/tmp/bigo-bn', ADMIN_PASSWORD: 'SenhaAdmin#2026', JWT_SECRET: 'k'.repeat(40), APP_URL: B }, stdio: ['ignore', 'pipe', 'pipe'] });
  let log = ''; srv.stdout.on('data', (d) => (log += d)); srv.stderr.on('data', (d) => (log += d));
  for (let i = 0; i < 50; i++) { try { if ((await fetch(B + '/api/health')).ok) break; } catch (_) {} await new Promise((r) => setTimeout(r, 200)); }
  const br = await chromium.launch(); const errs = [];
  const np = async () => { const c = await br.newContext({ viewport: { width: 420, height: 860 } }); const p = await c.newPage(); p.on('pageerror', (e) => errs.push(e.message)); p.on('console', (m) => m.type() === 'error' && !/Failed to load resource/.test(m.text()) && errs.push(m.text())); return p; };
  const signup = async (p, role, name, email, extra) => {
    await p.goto(B + '/'); await p.click('text=Criar conta'); await p.click('[data-v=' + role + ']');
    await p.fill('[name=name]', name); await p.fill('[name=email]', email); await p.fill('[name=password]', 'Senha-forte-1'); await p.fill('[name=phone]', '71988880000');
    await p.fill('[name=city]', 'Salvador'); await p.selectOption('[name=state]', 'BA'); if (extra) await extra(p);
    await p.click('[name=terms]'); await p.click('button[type=submit]'); await p.waitForSelector('.nav');
  };
  try {
    const w = await np(); await signup(w, 'WORKER', 'Zé Pintor', 'ze@t.com', (p) => p.selectOption('[name=profession]', 'Pintor'));
    const c = await np(); await signup(c, 'CLIENT', 'Ana Cliente', 'ana@t.com');
    // olho da senha
    const l = await np(); await l.goto(B + '/');
    const pw = l.locator('[name=password]').first();
    ok((await pw.getAttribute('type')) === 'password', 'senha começa oculta');
    await l.click('[data-act=eye]'); ok((await pw.getAttribute('type')) === 'text', 'olho mostra a senha');
    await l.click('[data-act=eye]'); ok((await pw.getAttribute('type')) === 'password', 'olho oculta de novo');
    // cliente cria ordem
    await c.goto(B + '/#/orders/new'); await c.waitForSelector('form[data-form=ordernew]');
    await c.fill('[name=title]', 'Pintar sala'); await c.selectOption('[name=profession]', 'Pintor'); await c.fill('[name=address]', 'Rua das Flores 10'); await c.fill('[name=whatsapp]', '71911112222');
    await c.click('form[data-form=ordernew] button[type=submit]'); await c.waitForSelector('text=Pintar sala');
    ok(true, 'cliente envia ordem de serviço e a vê no feed');
    // prestador: aviso e bloqueio
    await w.goto(B + '/#/feed'); await w.reload(); await w.waitForSelector('.nav');
    await w.click('text=Ordens de serviço'); await w.waitForSelector('text=Pintar sala');
    const t = await w.locator('body').innerText();
    ok(t.includes('só para prestador VIP') || t.includes('somente no plano VIP'), 'prestador sem VIP vê aviso de bloqueio');
    ok(!t.includes('Rua das Flores') && !t.includes('71911112222'), 'endereço e WhatsApp não chegam ao prestador sem VIP');
    // lupa
    await w.goto(B + '/#/search'); await w.fill('[name=q]', 'Ana'); await w.click('form[data-form=search] button[type=submit], form[data-form=search] button');
    await w.waitForSelector('text=Ana Cliente'); ok(true, 'lupa encontra conta');
    // seguir no perfil
    await w.click('a[href^="#/profile/"] >> nth=0'); await w.waitForSelector('[data-act=follow]');
    ok(true, 'botão Seguir aparece no perfil');
    await w.click('[data-act=follow]'); await w.waitForTimeout(700);
    ok(await w.locator('[data-act=follow]').count() === 0 || (await w.locator('body').innerText()).includes('Seguindo'), 'seguir funciona');
    // anunciante vê que precisa pagar
    await w.goto(B + '/#/ads'); await w.waitForTimeout(800);
    ok((await w.locator('body').innerText()).toLowerCase().includes('anún'), 'tela de anúncios abre');
    // admin: aba Anúncios
    const a = await np(); await a.goto(B + '/'); await a.fill('[name=login]', 'admin'); await a.fill('[name=password]', 'SenhaAdmin#2026'); await a.click('button[type=submit]');
    await a.waitForSelector('text=Painel ADM'); await a.click('[data-act=atab][data-v=ads]'); await a.waitForSelector('text=Pacotes de anúncio');
    await a.click('[data-act=apknew]'); await a.fill('form[data-form=apkg] [name=name]', 'Semana'); await a.fill('[name=price]', '19,90'); await a.fill('[name=days]', '7');
    await a.click('form[data-form=apkg] button[type=submit]'); await a.waitForSelector('.card:has-text("Semana"):has-text("19,90")');
    ok(true, 'admin cria pacote de anúncio');
    await w.goto(B + '/#/ads'); await w.reload(); await w.waitForSelector('form[data-form=adnew]');
    ok(true, 'prestador vê o formulário com o pacote criado');
  } catch (e) { fail++; console.log('  EXCEÇÃO', e.message.split('\n')[0]); }
  ok(errs.length === 0, 'sem erros de JavaScript' + (errs.length ? ': ' + errs.slice(0, 3).join(' | ') : ''));
  await br.close(); srv.kill();
  if (fail) console.log(log.slice(-1500));
  console.log(`\n${pass} ok, ${fail} falhas`); process.exit(fail ? 1 : 0);
})();
