'use strict';
// Fluxo de pagamento na interface (Chromium real) contra um Mercado Pago FALSO.
const { spawn } = require('child_process');
const http = require('http');
const crypto = require('crypto');
const path = require('path');
const { chromium } = require('playwright');
const PORT = 3340, B = 'http://127.0.0.1:' + PORT, SECRET = 'seg';
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : fail++; console.log((c ? '  ok  ' : '  FALHA ') + m); };
const prefs = [], mpPay = new Map();
const fake = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x'); const ch = []; req.on('data', (c) => ch.push(c));
  req.on('end', () => {
    const j = (s, o) => { res.writeHead(s, { 'content-type': 'application/json' }); res.end(JSON.stringify(o)); };
    if (u.pathname.startsWith('/pay/')) { res.writeHead(200, { 'content-type': 'text/html' }); return res.end('<h1>Checkout falso do Mercado Pago</h1>'); }
    if (req.headers.authorization !== 'Bearer TEST-x') return j(401, {});
    if (req.method === 'POST' && u.pathname === '/checkout/preferences') { prefs.push(JSON.parse(Buffer.concat(ch))); return j(201, { id: 'p' + prefs.length, init_point: 'http://127.0.0.1:9455/pay/' + prefs.length }); }
    if (u.pathname === '/v1/payments/search') return j(200, { results: [...mpPay.values()].filter((p) => p.external_reference === u.searchParams.get('external_reference')) });
    const m = u.pathname.match(/^\/v1\/payments\/(\d+)$/); if (m && mpPay.has(m[1])) return j(200, mpPay.get(m[1]));
    j(404, {});
  });
});
fake.listen(9455, async () => {
  const srv = spawn('node', [path.join(__dirname, '..', 'src', 'index.js')], { env: { ...process.env, APP_ENV: 'demo', PORT: String(PORT), UPLOAD_DIR: '/tmp/bigo-bb', ADMIN_PASSWORD: 'SenhaAdmin#2026', JWT_SECRET: 'k'.repeat(40), MP_ACCESS_TOKEN: 'TEST-x', MP_API_URL: 'http://127.0.0.1:9455', APP_URL: B, MP_WEBHOOK_SECRET: SECRET }, stdio: ['ignore', 'pipe', 'pipe'] });
  let log = ''; srv.stdout.on('data', (d) => (log += d)); srv.stderr.on('data', (d) => (log += d));
  for (let i = 0; i < 50; i++) { try { if ((await fetch(B + '/api/health')).ok) break; } catch (_) {} await new Promise((r) => setTimeout(r, 200)); }
  const br = await chromium.launch(); const errs = [];
  const np = async () => { const c = await br.newContext({ viewport: { width: 420, height: 860 } }); const p = await c.newPage(); p.on('pageerror', (e) => errs.push(e.message)); p.on('console', (m) => m.type() === 'error' && !/Failed to load resource/.test(m.text()) && errs.push(m.text())); return p; };
  try {
    const a = await np(); await a.goto(B + '/');
    await a.fill('[name=login]', 'admin'); await a.fill('[name=password]', 'SenhaAdmin#2026'); await a.click('button[type=submit]');
    await a.waitForSelector('text=Painel ADM'); await a.click('[data-act=atab][data-v=plans]');
    await a.waitForSelector('text=Nenhum plano cadastrado');
    ok(true, 'aba Planos começa vazia (sem plano inventado)');
    await a.click('[data-act=aplannew]'); await a.fill('form[data-form=aplan] [name=name]', 'VIP'); await a.fill('[name=description]', 'Mais destaque no feed');
    await a.fill('[name=price]', '29,90'); await a.fill('[name=benefits]', 'Perfil em destaque\nSelo VIP'); await a.click('form[data-form=aplan] button[type=submit]');
    await a.waitForSelector('.card:has-text("VIP"):has-text("R$"):has-text("29,90")');
    ok(true, 'admin cria o plano VIP por R$ 29,90 pela interface');
    const w = await np(); await w.goto(B + '/'); await w.click('text=Criar conta'); await w.click('[data-v=WORKER]');
    await w.fill('[name=name]', 'Zé Pintor'); await w.fill('[name=email]', 'ze@t.com'); await w.fill('[name=password]', 'Senha-forte-1'); await w.fill('[name=phone]', '71988887777');
    await w.fill('[name=city]', 'Salvador'); await w.selectOption('[name=state]', 'BA'); await w.selectOption('[name=profession]', 'Pintor'); await w.click('[name=terms]'); await w.click('button[type=submit]');
    await w.waitForSelector('.nav'); await w.goto(B + '/#/settings'); await w.click('text=Meu plano e pagamentos');
    await w.waitForSelector('text=Assinar');
    const txt = await w.locator('body').innerText();
    ok(txt.includes('VIP') && txt.includes('29,90') && txt.includes('Selo VIP') && txt.includes('plano gratuito'), 'trabalhador vê plano, preço e vantagens');
    await Promise.all([w.waitForURL(/127\.0\.0\.1:9455\/pay\//, { timeout: 10000 }), w.click('[data-act=buy]')]);
    ok(true, 'botão Assinar leva ao checkout do Mercado Pago');
    const ref = prefs[0].external_reference;
    const id = '9001'; mpPay.set(id, { id: 9001, external_reference: ref, status: 'approved', transaction_amount: 29.9, currency_id: 'BRL', payment_type_id: 'bank_transfer', payment_method_id: 'pix' });
    const ts = String(Date.now()), v1 = crypto.createHmac('sha256', SECRET).update(`id:${id};request-id:r1;ts:${ts};`).digest('hex');
    const wh = await fetch(`${B}/api/billing/webhook?data.id=${id}&type=payment`, { method: 'POST', headers: { 'content-type': 'application/json', 'x-signature': `ts=${ts},v1=${v1}`, 'x-request-id': 'r1' }, body: JSON.stringify({ type: 'payment', data: { id } }) });
    ok(wh.status === 200, 'webhook assinado aceito');
    await w.goto(`${B}/api/billing/return?ref=${ref}&status=approved`); await w.waitForSelector('text=Pagamento confirmado', { timeout: 15000 });
    ok((await w.locator('body').innerText()).includes('Ativo até'), 'ao voltar, o app mostra o plano ativo');
    await a.click('[data-act=atab][data-v=pays]'); await a.waitForSelector('text=Total recebido');
    ok((await a.locator('body').innerText()).includes('R$') && (await a.locator('body').innerText()).includes('Zé Pintor'), 'painel ADM mostra o pagamento recebido');
    // cliente não vê o cartão de plano de trabalhador
    const c = await np(); await c.goto(B + '/'); await c.click('text=Criar conta'); await c.click('[data-v=CLIENT]');
    await c.fill('[name=name]', 'Ana'); await c.fill('[name=email]', 'ana@t.com'); await c.fill('[name=password]', 'Senha-forte-1'); await c.fill('[name=phone]', '71977776666');
    await c.fill('[name=city]', 'Salvador'); await c.selectOption('[name=state]', 'BA'); await c.click('[name=terms]'); await c.click('button[type=submit]');
    await c.waitForSelector('.nav'); await c.goto(B + '/#/plano'); await c.waitForSelector('text=Meu plano');
    ok((await c.locator('body').innerText()).includes('Ainda não há planos pagos'), 'cliente não vê plano de trabalhador');
    await w.screenshot({ path: '/tmp/bigo-plano.png' });
  } catch (e) { fail++; console.log('  EXCEÇÃO', e.message.split('\n')[0]); }
  ok(errs.length === 0, 'sem erros de JavaScript' + (errs.length ? ': ' + errs.slice(0, 3).join(' | ') : ''));
  await br.close(); srv.kill(); fake.close();
  if (fail) console.log(log.slice(-2000));
  console.log(`\n${pass} ok, ${fail} falhas`); process.exit(fail ? 1 : 0);
});
