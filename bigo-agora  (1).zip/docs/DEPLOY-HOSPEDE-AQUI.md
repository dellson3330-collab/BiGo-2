# Publicar o BiGo na Hospede Aqui (passo a passo)

O BiGo é **um único serviço** (Node.js) que entrega o app (HTML) e a API, mais **um banco PostgreSQL**. Fotos e vídeos ficam num **armazenamento S3 (Cloudflare R2)**, porque o plano Go não tem disco persistente na API.

## 0. Antes de começar
- Plano: comece no **Go** (teste de 30 dias da Black Week, cadastro até 30/11, cartão validado) e, se quiser guardar mídia no disco da própria API, suba para o **Hobby** (disco persistente opcional).
- ⚠️ Se o teste terminar sem você escolher um plano e ainda houver app/banco, a conta passa para **Pago por Uso**. Escolha o plano ou apague os recursos antes do fim.
- Aguardando resposta do suporte: tamanho máximo de upload, tempo limite por requisição e Docker Compose. **Você não precisa de nenhum dos três** neste desenho (vídeos vão direto ao R2; um serviço só + banco).

## 1. Criar o bucket de mídia (Cloudflare R2 – tem camada gratuita)
1. Conta Cloudflare → R2 → *Create bucket* (ex.: `bigo-midia`).
2. Em *Settings* do bucket ative **Public access** (domínio `r2.dev` ou domínio próprio) → copie a URL pública → `S3_PUBLIC_URL`.
3. *R2 → Manage API tokens → Create API token* com permissão **Object Read & Write** neste bucket → copie *Access Key ID* e *Secret Access Key*. O endpoint é `https://<ID_DA_CONTA>.r2.cloudflarestorage.com`.
4. **CORS** do bucket (para o navegador enviar o arquivo direto). Cole em *Settings → CORS policy*, trocando o domínio pelo do seu app:
```json
[{
  "AllowedOrigins": ["https://SEU-APP.hospedeaqui.cloud"],
  "AllowedMethods": ["PUT", "GET", "HEAD"],
  "AllowedHeaders": ["content-type"],
  "MaxAgeSeconds": 3600
}]
```

## 2. Criar o banco
No painel da Hospede Aqui: *Novo → PostgreSQL* (gerenciado). Anote o endereço interno (host), porta, usuário, senha e nome do banco → monte a `DATABASE_URL`:
`postgresql://USUARIO:SENHA@HOST_INTERNO:5432/BANCO`
As tabelas são criadas sozinhas no primeiro start (o servidor roda a migração, que é idempotente).

## 3. Criar o app (API + site)
Escolha **uma** das formas:
- **GitHub (recomendado):** suba esta pasta para um repositório privado e conecte-o. A plataforma detecta o `Dockerfile`.
- **.zip / Docker:** envie o `.zip` desta pasta ou a imagem construída a partir do `Dockerfile`.

Porta: **3000** (ou a que a plataforma informar na variável `PORT`; o servidor já lê `PORT`).

### Variáveis de ambiente
Copie de `.env.example`. As obrigatórias:

| Variável | Valor |
|---|---|
| `APP_ENV` | `production` |
| `DATABASE_URL` | do passo 2 |
| `JWT_SECRET` | gere com `openssl rand -base64 48` (guarde; trocar derruba as sessões) |
| `ADMIN_PASSWORD` | senha **inicial** do administrador (troque no primeiro acesso) |
| `STORAGE_DRIVER` | `s3` |
| `S3_ENDPOINT`, `S3_BUCKET`, `S3_ACCESS_KEY`, `S3_SECRET_KEY`, `S3_PUBLIC_URL` | do passo 1 |
| `S3_REGION` | `auto` |

Opcional: `RESEND_API_KEY` + `MAIL_FROM` (e-mail de “Esqueci minha senha”; sem isso, a recuperação por e-mail fica indisponível em produção e só o ADM redefine senhas), `CORS_ORIGINS`, `MAX_VIDEO_MB`.

> Se `ADMIN_PASSWORD` ficar vazio, uma senha aleatória aparece **uma única vez** no log do primeiro start.

## 4. Primeiro acesso
1. Abra o endereço do app. Confira `https://SEU-APP/api/health` → `{"ok":true,"env":"production"}`.
2. Na **tela de login comum**, entre com usuário `admin` e a senha definida em `ADMIN_PASSWORD`. Você cai direto no Painel ADM (não existe link de admin na tela de login).
3. Vá em **Admins → Meus dados de acesso** e troque a senha (e o login, se quiser).
4. Em **Configurações**, ajuste nome/cor e **substitua os Termos e a Política de Privacidade por textos revisados por advogado** (os padrões são só modelos).
5. Crie sua conta de trabalhador de teste pelo app e publique uma foto e um vídeo para validar o envio ao R2.

## 5. Segurança e operação
- Use HTTPS (a plataforma fornece). `TRUST_PROXY=true` (padrão) faz o limite de tentativas olhar o IP real.
- Ative backup do banco no painel. As mídias ficam no R2.
- Para o limite de tentativas funcionar corretamente, rode **1 instância** (o limitador é em memória). Para várias instâncias, será preciso um limitador compartilhado (Redis) — próxima etapa.
- Nunca ponha `APP_ENV=demo` em produção. Em `demo`, o código de recuperação de senha é devolvido na resposta da API.
- Documentos pessoais (RG, CPF, CNH) **não são solicitados nem armazenados** nesta versão; os selos de verificação são marcados manualmente pelo ADM.

## 6. Disco persistente (Hobby ou superior), em vez de R2
`STORAGE_DRIVER=local`, `UPLOAD_DIR=/app/data/uploads`, monte o disco persistente da API nesse caminho. O envio passa pela API, então o tamanho máximo/tempo limite da plataforma importam (aguardar o suporte). Para vídeos grandes, o R2 continua sendo a melhor opção.

## 7. Problemas comuns
| Sintoma | Causa provável |
|---|---|
| Servidor não sobe: “Configuração inválida” | variável obrigatória ausente (o log diz qual) |
| Foto envia, vídeo falha no navegador | CORS do bucket sem `PUT` / origem errada |
| Imagem não aparece | `S3_PUBLIC_URL` errada ou acesso público do bucket desligado |
| “Muitas tentativas” | limite por IP/conta; aguarde 15 min |
| Todos saíram da conta | `JWT_SECRET` foi trocado |

## 8. Pagamentos com Mercado Pago (planos VIP)
Os planos **não vêm prontos**: o ADM cria no painel (**Planos**: nome, público, preço, duração, vantagens), então você define os VIP quando quiser. Cobrança por **Checkout Pro** (Pix e cartão; o app nunca vê dados de cartão). Pagamento único por período (ex.: 30 dias); para continuar, o usuário paga de novo e o tempo é somado ao plano em vigor.

1. No painel do Mercado Pago → *Suas integrações* → crie a aplicação (Checkout Pro). Copie o **Access Token de teste**.
2. Na Hospede Aqui, defina `APP_URL`, `MP_ACCESS_TOKEN` e `MP_WEBHOOK_SECRET`.
3. No Mercado Pago, configure o **Webhook** (evento *Pagamentos*) para `https://SEU-APP/api/billing/webhook` e copie a *assinatura secreta* para `MP_WEBHOOK_SECRET`.
4. No painel ADM crie um plano, entre como trabalhador e pague com as **contas e cartões de teste** do Mercado Pago. Confirme que o plano ativa só depois da aprovação.
5. Só depois troque para o Access Token de **produção**.

Segurança: o preço vem sempre do servidor; o plano só é liberado depois que o servidor consulta o pagamento na API do Mercado Pago (o corpo do webhook não é confiado); webhook repetido não soma tempo duas vezes; o token nunca aparece em respostas nem no HTML.

## 9. Recuperação de senha por e-mail, ordens VIP e anúncios
- **E-mail:** crie conta em resend.com, verifique seu domínio e defina `RESEND_API_KEY` e `MAIL_FROM` no app. Sem isso o “Esqueci minha senha” fica indisponível em produção.
- **VIP:** crie o plano em Admin → Planos (público: Trabalhadores). Só quem tem assinatura ativa nele vê endereço/WhatsApp das ordens de serviço.
- **Anúncios:** em Admin → Anúncios crie ao menos um pacote (nome, preço, dias). Sem pacote ou sem `MP_ACCESS_TOKEN` ninguém consegue anunciar. Se retirar um anúncio por violar regras, o estorno é manual no painel do Mercado Pago.
