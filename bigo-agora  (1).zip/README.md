# BiGo — servidor (API + app web)

Node.js 20+ sem framework; única dependência: `pg`. Serve o app (`public/index.html`) e a API (`/api/*`, `/media/*`).

```
npm install
cp .env.example .env     # preencha (veja docs/DEPLOY-HOSPEDE-AQUI.md)
export $(grep -v '^#' .env | xargs) && npm start
```

Local rápido (disco, ambiente de demonstração):
```
APP_ENV=demo DATABASE_URL=postgresql://usuario@localhost:5432/bigo JWT_SECRET=$(openssl rand -base64 48) ADMIN_PASSWORD='TroqueEsta#123' npm start
```

## O que existe (Etapas 1–2)
Cadastro/login (cliente, trabalhador, empresa), sessões com renovação rotativa e detecção de reuso, recuperação de senha por e-mail, perfil profissional, feed com filtros e ranking, fotos e vídeos (disco ou S3/R2), Stories de 24 h, curtidas, comentários, seguir, notificações, denúncias, LGPD (exportar/excluir), Painel ADM (usuários, publicações, stories, comentários, denúncias, categorias, configurações, administradores, auditoria). O ADM entra pela mesma tela de login (usuário `admin`).

Pagamentos: planos criados pelo ADM, cobrança por Mercado Pago (Checkout Pro, Pix e cartão), webhook assinado. Testado só contra um Mercado Pago **falso**; falta validar com as credenciais de teste reais (docs/DEPLOY, seção 8).

**Ordens de serviço:** o cliente publica uma ordem; prestadores da mesma cidade (e profissão) recebem notificação e um alerta no feed. Endereço e WhatsApp do cliente só são enviados pelo servidor a prestadores **VIP** (assinatura ativa em plano criado pelo ADM). **Anúncios:** só entram no ar depois de pagos (pacotes criados pelo ADM na aba Anúncios; o ADM pode pausar/excluir). **Busca (lupa), rede de profissionais, botão Seguir no perfil, olho de mostrar/ocultar senha** e recuperação de senha por e-mail (precisa de `RESEND_API_KEY`) também estão incluídos.

O esquema do banco já contém tabelas das próximas etapas (vagas, candidaturas, avaliações, mensagens, verificações, planos, assinaturas, pagamentos, anúncios), **mas sem telas nem rotas ainda**.

## Testes
`npm test` (API ponta a ponta), `node test/s3.js`, `node test/billing.js` (pagamentos), `node test/features.js` (ordens/VIP/anúncios/busca), `node test/browser-billing.js` e `node test/browser-new.js` (telas) (envio direto S3 contra um S3 falso local), `node test/browser.js foto.jpg video.mp4` (Chromium real; requer `playwright`). Precisam de um PostgreSQL acessível em `DATABASE_URL`.

**Transparência:** na máquina onde foram escritos não havia acesso à internet, então os testes rodaram contra um PostgreSQL 16 real, mas com um cliente `pg` de teste (`test/shim`) no lugar do pacote oficial `pg`. O pacote oficial nunca foi executado aqui — rode `npm install && npm test` no seu ambiente para confirmar. O deploy na Hospede Aqui também não foi testado.

## Segurança resumida
Senhas com scrypt; JWT HS256 (usuário 15 min, ADM 2 h); refresh tokens com hash e rotação; bloqueio por tentativas; limites de requisição; cabeçalhos de segurança/CSP; validação do conteúdo real dos arquivos (não só da extensão); contatos só são devolvidos quando o trabalhador escolheu divulgá-los; sem documentos pessoais armazenados.

## Editar o app web
O HTML é gerado: `web-src/app.js` + `head.html` (CSS) → `web-src/build.sh`. O `public/index.html` já gerado funciona sem build.
