#!/bin/bash
# Gera public/index.html = head.html (CSS) + assets.js (ícone/ícones) + app.js
set -e
cd "$(dirname "$0")"
python3 - <<'PY'
a=open('assets.js',encoding='utf-8').read().split('\n')
js=open('app.js',encoding='utf-8').read().replace('//@@BRAND_ICON',a[0]).replace('//@@ICONS',a[1])
head=open('head.html',encoding='utf-8').read()
open('../public/index.html','w',encoding='utf-8').write(head+('' if head.endswith('\n') else '\n')+js+'\n</script>\n</body>\n</html>\n')
PY
wc -c ../public/index.html
