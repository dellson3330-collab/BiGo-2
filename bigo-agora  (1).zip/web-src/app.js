(()=>{
'use strict';
/* BiGo — cliente web (modo API). Fala com o servidor em /api e /media (mesma origem por padrão). */
const $=(s,r=document)=>r.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const digits=s=>String(s||'').replace(/\D/g,'');
const ts=v=>v?new Date(v).getTime():0;
const ago=v=>{const s=(Date.now()-ts(v))/1e3;if(s<60)return'agora';if(s<3600)return Math.floor(s/60)+' min';if(s<86400)return Math.floor(s/3600)+' h';if(s<604800)return Math.floor(s/86400)+' d';return new Date(v).toLocaleDateString('pt-BR')};
const waLink=(n,t)=>{let d=digits(n);if(d.length<=11)d='55'+d;return'https://wa.me/'+d+(t?'?text='+encodeURIComponent(t):'')};
const UFS='AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO'.split(' ');
const BRAND='BiGo';
//@@BRAND_ICON
//@@ICONS
const ic=(n,s=20)=>`<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${I[n]||''}</svg>`;
const BASE=String(window.BIGO_API||'').replace(/\/+$/,'');
const mu=u=>u?(/^https?:/.test(u)?u:BASE+u):'';
const LS_OK=(()=>{try{localStorage.setItem('_t','1');localStorage.removeItem('_t');return true}catch(e){return false}})();
const MEM={};const ST=LS_OK?localStorage:{getItem:k=>(k in MEM?MEM[k]:null),setItem:(k,v)=>{MEM[k]=String(v)},removeItem:k=>{delete MEM[k]}};
const TERMS='MODELO de Termos de Uso. Este texto é um exemplo e deve ser revisado por assessoria jurídica antes da operação comercial. Ao usar a plataforma você concorda em fornecer informações verdadeiras, respeitar outros usuários, não publicar conteúdo ilegal, ofensivo ou enganoso e não usar a plataforma para spam. A plataforma conecta pessoas e não é parte dos contratos firmados entre clientes e profissionais. Conteúdos denunciados poderão ser removidos e contas poderão ser bloqueadas.';
const PRIV='MODELO de Política de Privacidade (LGPD). Este texto é um exemplo e deve ser revisado por assessoria jurídica. Coletamos nome, e-mail, telefone, cidade e o conteúdo que você publica para operar a plataforma. Telefone e WhatsApp só aparecem publicamente se você escolher divulgá-los. Você pode, a qualquer momento, exportar seus dados e excluir sua conta nas Configurações.';

/* ───────── estado ───────── */
let CFG={name:BRAND,color:null,logoUrl:null,storage:'local',maxImageMb:15,maxVideoMb:100,terms:null,privacy:null};
let CATS=[];
let AUTH=null;                       // {kind:'user'|'admin', access, refresh, user|admin}
const S={q:'',stype:'all',seenAds:new Set(),mode:'login',role:null,filter:'all',tab:'port',unread:0,seen:new Set(),openC:new Set(),cm:{}};
const D={plans:{items:[]},bill:{subscription:null,payments:[]},feed:{items:[],page:0,hasMore:false},net:[],ads:[],orders:null,sres:null,adpk:null,admine:[],stories:[],post:null,profile:null,pposts:[],notifs:[]};
const PM=new Map();                  // id -> publicação (objeto compartilhado entre telas)
let RT=0;                            // controle de renderizações concorrentes
const logo=(s=34)=>`<img src="${CFG.logoUrl?esc(mu(CFG.logoUrl)):BRAND_ICON}" width="${s}" height="${s}" style="width:${s}px;height:${s}px;border-radius:22%;object-fit:cover;flex:none" alt="${esc(CFG.name)}">`;
const avatar=(u,s=44)=>u&&u.avatarUrl?`<img class="av" src="${esc(mu(u.avatarUrl))}" width="${s}" height="${s}" style="width:${s}px;height:${s}px" alt="">`:`<span class="av red" style="width:${s}px;height:${s}px;font-size:${Math.round(s/2.4)}px">${esc((u?.name||'?').trim().charAt(0).toUpperCase())}</span>`;
const loadAuth=()=>{try{return JSON.parse(ST.getItem('bigo_auth'))}catch(e){return null}};
const saveAuth=()=>{try{AUTH?ST.setItem('bigo_auth',JSON.stringify(AUTH)):ST.removeItem('bigo_auth')}catch(e){}};
AUTH=loadAuth();
const me=()=>AUTH&&AUTH.kind==='user'?AUTH.user:null;
const adm=()=>AUTH&&AUTH.kind==='admin'?AUTH.admin:null;
const isW=u=>u&&u.role==='WORKER';
const roleLabel=u=>u.role==='WORKER'?(u.worker?.profession||u.profession||'Trabalhador'):u.role==='COMPANY'?'Empresa':'Cliente';
const money=c=>(c/100).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const parseMoney=t=>{const n=Number(String(t||'').trim().replace(/\./g,'').replace(',','.'));return Number.isFinite(n)&&n>=0?Math.round(n*100):NaN};
const professions=()=>CATS.flatMap(c=>c.items.map(i=>i.name));

/* ───────── rede ───────── */
class ApiErr extends Error{constructor(s,m){super(m);this.status=s}}
let refreshing=null;
function refreshTokens(used){
  const st=loadAuth();if(st&&st.kind==='user'&&st.access!==used){AUTH=st;return Promise.resolve(true)}  // outra aba já renovou
  if(!AUTH||!AUTH.refresh)return Promise.resolve(false);
  if(!refreshing)refreshing=(async()=>{try{
    const r=await fetch(BASE+'/api/auth/refresh',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({refreshToken:AUTH.refresh})});
    if(r.status===401||r.status===403)return false;if(!r.ok)return null;
    const j=await r.json();AUTH.access=j.accessToken;AUTH.refresh=j.refreshToken;saveAuth();return true}catch(e){return null}})().finally(()=>{refreshing=null});
  return refreshing;
}
async function api(method,path,body,o={}){
  const send=()=>fetch(BASE+'/api'+path,{method,headers:{...(AUTH&&!o.anon?{Authorization:'Bearer '+AUTH.access}:{}),...(body!==undefined&&!o.raw?{'Content-Type':'application/json'}:{})},body:o.raw?body:body!==undefined?JSON.stringify(body):undefined});
  let r,used=AUTH&&AUTH.access;
  try{r=await send()}catch(e){throw new ApiErr(0,'Sem conexão com o servidor. Verifique sua internet e tente novamente.')}
  if(r.status===401&&AUTH&&!o.anon&&!path.startsWith('/auth/')){
    if(AUTH.kind==='user'){const ok=await refreshTokens(used);if(ok===true)r=await send();else if(ok===false){sessionEnd('Sua sessão expirou. Entre novamente.');throw new ApiErr(401,'Sessão expirada.')}}
    else{sessionEnd('A sessão do painel expirou. Entre novamente.');throw new ApiErr(401,'Sessão expirada.')}
  }
  let j=null;try{j=await r.json()}catch(e){}
  if(!r.ok)throw new ApiErr(r.status,(j&&j.error)||'Não foi possível concluir. Tente novamente.');
  return j;
}
function sessionEnd(msg){AUTH=null;saveAuth();S.mode='login';toast(msg,'err');if(location.hash!=='#/auth')location.hash='#/auth';else render()}
async function boot(){
  try{const [c,k]=await Promise.all([api('GET','/settings',undefined,{anon:true}),api('GET','/categories',undefined,{anon:true})]);CFG={...CFG,...c};CATS=k}catch(e){}
  applyTheme();
}
function applyTheme(){const c=CFG.color,r=document.documentElement.style;if(c&&/^#[0-9a-f]{6}$/i.test(c)){r.setProperty('--red',c);r.setProperty('--red2','color-mix(in srgb,'+c+' 78%,black)')}else{r.removeProperty('--red');r.removeProperty('--red2')}document.title=CFG.name||BRAND}

/* ───────── interface básica ───────── */
function toast(msg,kind){const t=$('#toast');t.innerHTML=`<div class="toast ${kind==='err'?'err':''}" role="status">${esc(msg)}</div>`;clearTimeout(toast.t);toast.t=setTimeout(()=>t.innerHTML='',4200)}
const fail=e=>toast(e&&e.message?e.message:'Ocorreu um erro. Tente novamente.','err');
function openModal(html){$('#modal').innerHTML=`<div class="ov"><div class="sheet" role="dialog">${html}</div></div>`}
function closeModal(){$('#modal').innerHTML=''}
const go=p=>{if(location.hash==='#'+p)render();else location.hash='#'+p};
function draw(){const y=scrollY;paint();scrollTo(0,y)}
function field(label,name,val='',o={}){const t=o.type||'text';const req=o.req?' required':'';
  if(t==='textarea')return`<div class="field"><label>${label}</label><textarea class="in" name="${name}" maxlength="${o.max||2000}"${req} placeholder="${esc(o.ph||'')}">${esc(val)}</textarea></div>`;
  if(t==='select')return`<div class="field"><label>${label}</label><select class="in" name="${name}"${req}>${o.opts}</select></div>`;
  const inp=`<input class="in" type="${t}" name="${name}" value="${esc(val)}"${req} maxlength="${o.max||200}" placeholder="${esc(o.ph||'')}" ${o.attr||''}>`;
  return`<div class="field"><label>${label}</label>${t==='password'?`<div class="pw">${inp}<button type="button" class="eye" data-act="eye" aria-label="Mostrar senha">${ic('eye',20)}</button></div>`:inp}</div>`}
const ufOpts=v=>'<option value="">UF</option>'+UFS.map(u=>`<option ${u===v?'selected':''}>${u}</option>`).join('');
const profOpts=v=>'<option value="">Selecione a profissão</option>'+CATS.map(c=>`<optgroup label="${esc(c.name)}">${c.items.map(i=>`<option ${i.name===v?'selected':''}>${esc(i.name)}</option>`).join('')}</optgroup>`).join('');
const fileField=(label,name,o={})=>`<div class="field"><label>${label}</label><input class="in" type="file" name="${name}" ${o.multi?'multiple':''} accept="${o.acc||'image/*'}">${o.prev?'<div class="prev row wrapr"></div>':''}</div>`;
const pillOk=t=>`<span class="pill" style="background:rgba(47,191,113,.15);color:#6be3a0;border-color:rgba(47,191,113,.4)">${t}</span>`;
const verBadges=a=>[a.verifiedIdentity?pillOk('Identidade conferida pela administração'):'',a.verifiedQualifications?pillOk('Qualificações conferidas'):''].filter(Boolean).join(' ');
const empty=(t,extra='')=>`<div class="empty">${t}${extra}</div>`;

/* ───────── envio de mídia (disco do servidor ou S3/R2 direto) ───────── */
const kindOf=f=>{const t=f.type||'',n=f.name||'';if(/^image\//.test(t))return'i';if(/^video\//.test(t))return'v';if(/\.(jpe?g|png|webp|gif|bmp|avif|heic|heif)$/i.test(n))return'i';if(/\.(mp4|m4v|mov|webm|3gp|3gpp|mkv|avi)$/i.test(n))return'v';return''};
function drawImage(file,max){return new Promise((ok,no)=>{const u=URL.createObjectURL(file),im=new Image();
  im.onerror=()=>{URL.revokeObjectURL(u);no(new Error('Não foi possível abrir esta imagem. Se for HEIC/HEIF, tire a foto em JPG ou escolha outra.'))};
  im.onload=()=>{URL.revokeObjectURL(u);const k=Math.min(1,max/Math.max(im.naturalWidth,im.naturalHeight)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(im.naturalWidth*k));c.height=Math.max(1,Math.round(im.naturalHeight*k));c.getContext('2d').drawImage(im,0,0,c.width,c.height);ok(c)};im.src=u})}
const canvasBlob=(c,q)=>new Promise((ok,no)=>c.toBlob(b=>b?ok(b):no(new Error('Falha ao processar a imagem.')),'image/jpeg',q));
async function prepare(file,imgMax=1600){
  const t=kindOf(file);
  if(t==='i'){const b=await canvasBlob(await drawImage(file,imgMax),.82);if(b.size>CFG.maxImageMb*1048576)throw new Error('Imagem maior que '+CFG.maxImageMb+' MB.');return{kind:'image',mime:'image/jpeg',blob:b}}
  if(t==='v'){
    const n=(file.name||'').toLowerCase();let mime=/\.webm$/.test(n)?'video/webm':/\.mov$/.test(n)?'video/quicktime':/\.(mp4|m4v)$/.test(n)?'video/mp4':file.type;
    if(!['video/mp4','video/webm','video/quicktime'].includes(mime))throw new Error('Formato de vídeo não suportado. Use MP4, MOV ou WEBM.');
    if(file.size>CFG.maxVideoMb*1048576)throw new Error('Vídeo maior que '+CFG.maxVideoMb+' MB. Use um vídeo mais curto.');
    return{kind:'video',mime,blob:file}}
  throw new Error('Formato não suportado. Envie foto (JPG/PNG/WEBP) ou vídeo (MP4/MOV/WEBM).');
}
async function uploadOne(file,imgMax){
  const p=await prepare(file,imgMax);
  if(CFG.storage==='s3'){
    const pre=await api('POST','/media/presign',{mime:p.mime,size:p.blob.size});
    let r;try{r=await fetch(pre.uploadUrl,{method:'PUT',headers:pre.headers,body:p.blob})}catch(e){throw new Error('Falha ao enviar o arquivo. Verifique a internet (e a configuração CORS do bucket).')}
    if(!r.ok)throw new Error('O armazenamento recusou o arquivo (código '+r.status+').');
    return api('POST','/media/'+pre.id+'/complete',{});
  }
  return api('POST','/media',p.blob,{raw:true});
}
async function uploadAll(files,imgMax){const out=[];let i=0;for(const f of files){i++;toast('Enviando arquivo '+i+' de '+files.length+'… aguarde.');out.push(await uploadOne(f,imgMax))}return out}
const filesOf=(fd,k)=>fd.getAll(k).filter(f=>f&&f.size>0);
document.addEventListener('change',e=>{
  const i=e.target;if(!(i instanceof HTMLInputElement)||i.type!=='file')return;
  const box=i.parentElement.querySelector('.prev');if(!box)return;box.innerHTML='';
  [...i.files].slice(0,6).forEach(f=>{const t=kindOf(f);if(!t)return;const u=URL.createObjectURL(f);box.insertAdjacentHTML('beforeend',t==='i'?`<img src="${u}" alt="">`:`<video src="${u}" muted preload="metadata"></video>`)});
  const mb=[...i.files].reduce((s,f)=>s+f.size,0)/1048576;if(i.files.length)box.insertAdjacentHTML('beforeend',`<span class="small mut" style="align-self:center">${i.files.length} arquivo(s) · ${mb.toFixed(1)} MB</span>`)});

/* ───────── estrutura ───────── */
const ACT={},FORMS={};
function navBar(){const h=location.hash.slice(1);const on=p=>h.startsWith(p)?'on':'';const u=me();
  return`<nav class="nav"><div><a class="${on('/feed')}" href="#/feed">${ic('home',22)}Início</a>${isW(u)?`<a class="plus" href="#/new">${ic('plus',22)}</a>`:''}<a class="${on('/me')}" href="#/me">${ic('user',22)}Perfil</a><a class="${on('/settings')}" href="#/settings">${ic('gear',22)}Ajustes</a></div></nav>`}
const bellInner=()=>`${ic('bell')}${S.unread?`<i class="dot">${S.unread>99?'99+':S.unread}</i>`:''}`;
function shell(body,o={}){
  return`<div class="wrap"><header class="top">${o.back?`<button class="ib" data-act="back" aria-label="Voltar">${ic('back')}</button>`:`<a href="#/feed" class="brand">${logo(30)}<b>${esc(CFG.name)}</b></a>`}${o.title?`<h2>${esc(o.title)}</h2>`:''}<span class="sp"></span>${o.right||''}${o.home?`<a class="ib" href="#/search" aria-label="Buscar">${ic('search')}</a><a class="ib" data-bell href="#/notifications" aria-label="Notificações">${bellInner()}</a>`:''}</header><main>${body}</main>${o.nav===false?'':navBar()}</div>`}
const loading=()=>`<div class="wrap"><div class="empty">Carregando…</div></div>`;
const errView=(e)=>`<div class="wrap"><header class="top"><a href="#/feed" class="brand">${logo(30)}<b>${esc(CFG.name)}</b></a></header><div class="empty">${esc(e.message||'Erro ao carregar.')}<p><button class="btn red" data-act="retry">Tentar novamente</button></p></div></div>`;
ACT.retry=()=>render();
ACT.eye=el=>{const i=el.parentElement.querySelector('input');if(!i)return;const show=i.type==='password';i.type=show?'text':'password';el.classList.toggle('on',show);el.setAttribute('aria-label',show?'Ocultar senha':'Mostrar senha')};
const envNote=()=>CFG.env==='demo'?`<div class="demo">Ambiente de DEMONSTRAÇÃO: não use dados reais.</div>`:'';

/* ───────── autenticação ───────── */
function viewAuth(){
  const m=S.mode;let body='';
  if(m==='register'&&!S.role){
    body=`<div class="pad col"><b>Como você quer usar a plataforma?</b>
    <button class="btn line" style="justify-content:flex-start;padding:16px" data-act="role" data-v="CLIENT">${ic('user',22)}<span><b>Sou cliente</b><br><span class="mut small">Quero encontrar profissionais e contratar serviços</span></span></button>
    <button class="btn line" style="justify-content:flex-start;padding:16px" data-act="role" data-v="WORKER">${ic('edit',22)}<span><b>Sou trabalhador / prestador</b><br><span class="mut small">Quero divulgar meu trabalho e receber contatos</span></span></button></div>`;
  }else if(m==='register'){
    const w=S.role==='WORKER';
    body=`<form class="pad" data-form="register" novalidate>
    <p class="small mut">Cadastro como <b>${w?'trabalhador / prestador':'cliente'}</b> · <a href="#" data-act="role" data-v="" style="color:var(--red)">trocar</a></p>
    ${field('Nome completo','name','',{req:1,max:120})}${field('E-mail','email','',{type:'email',req:1})}
    ${field('Senha (mínimo 10 caracteres)','password','',{type:'password',req:1,max:100,attr:'autocomplete="new-password"'})}
    ${field('Telefone / WhatsApp (com DDD)','phone','',{type:'tel',req:1,max:20})}
    <div class="row"><div style="flex:2">${field('Cidade','city','',{req:1,max:80})}</div><div style="flex:1">${field('UF','state','',{type:'select',opts:ufOpts(''),req:1})}</div></div>
    ${w?field('Profissão principal','profession','',{type:'select',opts:profOpts(''),req:1}):''}
    ${w?'<label class="chk"><input type="checkbox" name="showContact" checked><span>Divulgar meu WhatsApp e telefone nas minhas publicações e perfil (você pode mudar depois em Editar perfil)</span></label>':''}
    <label class="chk"><input type="checkbox" name="terms"><span>Li e aceito os <a href="#" data-act="doc" data-v="terms" style="color:var(--red)">Termos de Uso</a> e a <a href="#" data-act="doc" data-v="privacy" style="color:var(--red)">Política de Privacidade</a>.</span></label>
    <button class="btn red full" type="submit">Criar conta</button></form>`;
  }else if(m==='forgot'){
    body=S.resetEmail?`<form class="pad" data-form="reset" novalidate><p class="small mut">Enviamos um código de 6 dígitos para <b>${esc(S.resetEmail)}</b> (se o e-mail estiver cadastrado). Ele vale por 15 minutos.${S.devCode?`<br>Ambiente de demonstração — código: <b style="color:var(--txt);font-size:18px">${esc(S.devCode)}</b>`:''}</p>${field('Código','code','',{req:1,max:6})}${field('Nova senha (mínimo 10 caracteres)','password','',{type:'password',req:1,max:100})}<button class="btn red full" type="submit">Redefinir senha</button></form>`
    :`<form class="pad" data-form="forgot" novalidate><p class="small mut">Informe o e-mail da sua conta para receber um código de recuperação.</p>${field('E-mail','email','',{type:'email',req:1})}<button class="btn red full" type="submit">Enviar código</button></form>`;
  }else{
    body=`<form class="pad" data-form="login" novalidate>${field('E-mail ou usuário','login','',{req:1,attr:'autocomplete="username" autocapitalize="none" autocorrect="off"'})}${field('Senha','password','',{type:'password',req:1,max:100,attr:'autocomplete="current-password"'})}<button class="btn red full" type="submit">Entrar</button><p class="center small"><a href="#" data-act="mode" data-v="forgot" style="color:var(--red)">Esqueci minha senha</a></p></form>`;
  }
  return`<div class="wrap" style="padding-bottom:30px"><div class="hero">${logo(64)}<h1>${esc(CFG.name)}</h1><p class="mut">Encontre profissionais. Divulgue seu trabalho. Conquiste oportunidades.</p></div>
  <div class="tabs"><button class="${m==='login'?'on':''}" data-act="mode" data-v="login">Entrar</button><button class="${m==='register'?'on':''}" data-act="mode" data-v="register">Criar conta</button></div>${body}${envNote()}</div>`;
}
const validPhone=p=>{const d=digits(p);return d.length>=10&&d.length<=13};
function startSession(j){AUTH=j.kind==='admin'?{kind:'admin',access:j.accessToken,admin:j.admin}:{kind:'user',access:j.accessToken,refresh:j.refreshToken,user:j.user};saveAuth();S.mode='login';S.role=null;S.resetEmail=null;S.devCode=null}
FORMS.register=async(f,fd)=>{
  const v=k=>String(fd.get(k)||'').trim();const pw=String(fd.get('password')||'');
  if(v('name').length<2)return toast('Informe seu nome completo.','err');
  if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v('email')))return toast('E-mail inválido.','err');
  if(pw.length<10)return toast('A senha deve ter pelo menos 10 caracteres.','err');
  if(!validPhone(v('phone')))return toast('Telefone inválido. Use DDD + número.','err');
  if(!v('city')||!v('state'))return toast('Informe cidade e UF.','err');
  if(S.role==='WORKER'&&!v('profession'))return toast('Selecione sua profissão principal.','err');
  if(!fd.get('terms'))return toast('É necessário aceitar os Termos e a Política de Privacidade.','err');
  try{const j=await api('POST','/auth/register',{role:S.role,name:v('name'),email:v('email').toLowerCase(),password:pw,phone:digits(v('phone')),city:v('city'),state:v('state'),profession:v('profession')||undefined,showContact:S.role==='WORKER'&&!!fd.get('showContact'),acceptTerms:true},{anon:true});
    startSession(j);toast('Conta criada com sucesso!');go('/feed')}catch(e){fail(e)}
};
FORMS.login=async(f,fd)=>{
  try{const j=await api('POST','/auth/login',{login:String(fd.get('login')||'').trim().toLowerCase(),password:String(fd.get('password')||'')},{anon:true});
    startSession(j);go(j.kind==='admin'?'/admin':'/feed')}catch(e){fail(e)}
};
FORMS.forgot=async(f,fd)=>{const email=String(fd.get('email')||'').trim().toLowerCase();
  try{const j=await api('POST','/auth/forgot',{email},{anon:true});S.resetEmail=email;S.devCode=j.devCode||null;toast(j.message||'Código enviado.');draw()}catch(e){fail(e)}};
FORMS.reset=async(f,fd)=>{
  try{await api('POST','/auth/reset',{email:S.resetEmail,code:String(fd.get('code')||'').trim(),password:String(fd.get('password')||'')},{anon:true});
    S.resetEmail=null;S.devCode=null;S.mode='login';toast('Senha redefinida. Faça login.');draw()}catch(e){fail(e)}};
ACT.mode=el=>{S.mode=el.dataset.v;if(S.mode!=='forgot'){S.resetEmail=null;S.devCode=null}draw()};
ACT.role=el=>{S.role=el.dataset.v||null;draw()};
ACT.doc=el=>openModal(`<h3 style="margin-top:0">${el.dataset.v==='terms'?'Termos de Uso':'Política de Privacidade'}</h3><p class="small" style="white-space:pre-wrap">${esc(el.dataset.v==='terms'?(CFG.terms||TERMS):(CFG.privacy||PRIV))}</p><button class="btn red full" data-act="close">Fechar</button>`);
ACT.close=()=>closeModal();
ACT.back=()=>history.length>1?history.back():go('/feed');
ACT.logout=async()=>{const rt=AUTH&&AUTH.refresh;try{if(rt)await api('POST','/auth/logout',{refreshToken:rt},{anon:true})}catch(e){}
  AUTH=null;saveAuth();S.mode='login';S.role=null;S.unread=0;D.feed={items:[],page:0,hasMore:false};PM.clear();closeModal();go('/auth')};

/* ───────── feed ───────── */
function reg(p){const old=PM.get(p.id);if(old){Object.assign(old,p);return old}PM.set(p.id,p);return p}
function postCard(p,o={}){
  const a=p.author,u=me(),mine=p.mine,open=S.openC.has(p.id)||o.open,cms=S.cm[p.id];
  const media=p.media.map((m,i)=>{const tag=p.beforeAfter&&i<2?`<span class="tag">${i===0?'ANTES':'DEPOIS'}</span>`:'';
    return`<div class="m">${m.kind==='video'?`<video src="${esc(mu(m.url))}" controls playsinline preload="metadata"></video>`:`<img src="${esc(mu(m.url))}" alt="Foto do trabalho" loading="lazy">`}${tag}</div>`}).join('');
  const contacts=[];
  if(p.contacts.whatsapp)contacts.push(`<a class="btn wa sm" href="${waLink(p.contacts.whatsapp,'Olá '+a.name+', vi sua publicação na '+CFG.name+'.')}" target="_blank" rel="noopener">WhatsApp</a>`);
  if(p.contacts.phone)contacts.push(`<a class="btn sm" href="tel:${digits(p.contacts.phone)}">${ic('phone',16)}Ligar</a>`);
  contacts.push(`<a class="btn line sm" href="#/profile/${a.id}">Ver perfil</a>`);
  const cmHtml=open?`<div class="cm">${cms===undefined?'<p class="mut small">Carregando comentários…</p>':(cms.map(c=>`<div class="c">${avatar(c.author,30)}<div class="bub"><b class="small">${esc(c.author.name)}</b> <span class="mut small">${ago(c.createdAt)}</span><div>${esc(c.text)}</div><div class="small">${(mine||c.author.id===u.id)?`<a href="#" data-act="delcm" data-id="${c.id}" data-p="${p.id}" class="mut">Excluir</a> `:''}${c.author.id!==u.id?`<a href="#" data-act="reply" data-id="${p.id}" data-n="${esc(c.author.name)}" class="mut">Responder</a>`:''}</div></div></div>`).join('')||'<p class="mut small">Seja o primeiro a comentar.</p>')}
    ${cms===undefined?'':`<form class="row" data-form="comment" data-id="${p.id}"><input class="in" name="text" maxlength="500" placeholder="Escreva um comentário" autocomplete="off"><button class="btn red sm" type="submit">Enviar</button></form>`}</div>`:'';
  return`<article class="card" data-post="${p.id}">
  <div class="phead"><a href="#/profile/${a.id}">${avatar(a,42)}</a><div class="who"><a href="#/profile/${a.id}"><b>${esc(a.name)}</b></a><span class="mut small">${esc(roleLabel(a))} · ${esc(a.city||'')}${a.state?'/'+esc(a.state):''} · ${ago(p.createdAt)}${p.sponsored?' · <span class="pill">Patrocinado</span>':''}</span></div>
  ${!mine&&!a.following?`<button class="btn red sm" data-act="follow" data-id="${a.id}">Seguir</button>`:''}
  ${mine?`<a class="ib" href="#/post/${p.id}/edit" aria-label="Editar">${ic('edit',18)}</a><button class="ib" data-act="delpost" data-id="${p.id}" aria-label="Excluir">${ic('trash',18)}</button>`:`<button class="ib" data-act="report" data-t="post" data-id="${p.id}" aria-label="Denunciar">${ic('flag',18)}</button>`}</div>
  <div class="media">${media}</div>
  <div class="acts"><button class="${p.liked?'on':''}" data-act="like" data-id="${p.id}">${ic('heart',22)}${p.likes}</button><button data-act="cm" data-id="${p.id}">${ic('chat',22)}${p.comments}</button><button data-act="share" data-t="post" data-id="${p.id}">${ic('share',22)}</button>${mine?`<span class="sp"></span><span class="mut small" style="padding:8px">${ic('eye',16)} ${p.views||0}</span>`:''}</div>
  <div class="pad" style="padding-top:2px"><div style="white-space:pre-wrap">${esc(p.text)}</div>${p.priceText?`<p style="margin:8px 0 0"><span class="pill">${esc(p.priceText)}</span></p>`:''}</div>
  <div class="contact">${contacts.join('')}</div>${cmHtml}</article>`;
}
function storiesBar(){
  const u=me();
  const add=isW(u)?`<a class="st" href="#/story/new" aria-label="Criar Story"><div class="ring add">${ic('plus',26)}</div><span>Seu story</span></a>`:'';
  const tiles=D.stories.map(g=>`<button class="st" data-act="story" data-id="${g.author.id}"><div class="ring ${g.hasUnseen?'':'seen'}">${avatar(g.author,56)}</div><span>${g.isMe?'Você':esc(g.author.name.split(' ')[0])}</span></button>`).join('');
  return add||tiles?`<div class="stories">${add}${tiles}</div>`:'';
}
function viewFeed(){
  const u=me(),F=D.feed;
  const chips=[['all','Tudo'],['orders',isW(u)?'Ordens de serviço':'Minhas ordens'],['near','Perto de mim'],['fol','Seguindo'],['ba','Antes e depois'],['offer','Ofertas']].map(([k,l])=>`<button class="chip ${S.filter===k?'on':''}" data-act="filter" data-v="${k}">${l}</button>`).join('');
  const cta=!isW(u)?`<div class="card pad row wrapr"><div style="flex:1;min-width:160px"><b>Precisa de um profissional?</b><div class="mut small">Peça um serviço e os prestadores da sua cidade são avisados.</div></div><a class="btn red sm" href="#/orders/new">Pedir serviço</a></div>`:'';
  let list='';
  if(S.filter==='orders')list=ordersBody();
  else if(F.items.length){list=F.items.map((p,i)=>postCard(p)+((i+1)%5===0&&D.ads.length&&S.filter==='all'?adCard(D.ads[Math.floor(i/5)%D.ads.length]):'')).join('')+(F.hasMore?`<div class="center pad"><button class="btn line" data-act="more">Carregar mais</button></div>`:'')}
  else list=empty(S.filter==='all'?(isW(u)?'Ainda não há publicações. Publique seu primeiro trabalho!':'Ainda não há publicações na plataforma.'):'Nenhuma publicação neste filtro.',isW(u)?`<p><a class="btn red" href="#/new">Criar publicação</a></p>`:'');
  const body=`${storiesBar()}<div class="chips">${chips}</div>${cta}${S.filter==='all'?netStrip():''}${list}`;
  return shell(body,{home:true});
}
async function loadFeed(append){
  const F=D.feed;if(S.filter==='orders'){D.orders=await api('GET','/orders');return}
  if(!append){F.page=0}
  const j=await api('GET','/feed?filter='+S.filter+'&page='+F.page);
  const items=j.items.map(reg);F.items=append?F.items.concat(items):items;F.hasMore=j.hasMore;
}
function adCard(a){return`<article class="card ad" data-ad="${a.id}"><div class="pad" style="padding-bottom:0"><span class="adtag">Anúncio</span></div>
  ${a.imageUrl?`<div class="media"><div class="m"><img src="${esc(mu(a.imageUrl))}" alt="" loading="lazy"></div></div>`:''}
  <div class="pad"><b>${esc(a.title)}</b>${a.body?`<div>${esc(a.body)}</div>`:''}</div>
  <div class="contact">${a.whatsapp?`<a class="btn wa sm" data-act="adclick" data-id="${a.id}" href="${waLink(a.whatsapp,'Olá! Vi seu anúncio na '+CFG.name+'.')}" target="_blank" rel="noopener">WhatsApp</a>`:''}${a.targetUrl?`<a class="btn line sm" data-act="adclick" data-id="${a.id}" href="${esc(a.targetUrl)}" target="_blank" rel="noopener nofollow">Saiba mais</a>`:''}</div></article>`}
ACT.adclick=el=>{api('POST','/ads/'+el.dataset.id+'/click').catch(()=>{})};
function netStrip(){if(!D.net.length)return'';
  return`<div class="pad" style="padding-bottom:0"><b>Rede de profissionais</b> <span class="mut small">· sugestões para você seguir</span></div><div class="net">${D.net.map(x=>`<div class="nc"><a href="#/profile/${x.id}">${avatar(x,56)}</a><a href="#/profile/${x.id}"><b>${esc(x.name)}</b></a><span class="mut small">${esc(x.profession||'')}</span><span class="mut small">${esc(x.city)}${x.state?'/'+esc(x.state):''}</span>${x.following?'<span class="pill">Seguindo</span>':`<button class="btn red sm" data-act="follow" data-id="${x.id}">Seguir</button>`}</div>`).join('')}</div>`}
function ordersBody(){const o=D.orders,u=me();if(!o)return empty('Carregando…');
  if(!isW(u))return o.items.length?o.items.map(r=>`<div class="card pad col"><div class="row wrapr"><b style="flex:1">${esc(r.title)}</b><span class="pill">${r.status==='OPEN'?'Aberta':'Encerrada'}</span></div>${r.profession?`<div class="mut small">${esc(r.profession)}</div>`:''}${r.description?`<div>${esc(r.description)}</div>`:''}<div class="mut small">${ic('pin',14)} ${esc([r.address,r.bairro,r.city].filter(Boolean).join(', '))}/${esc(r.state)} · ${ago(r.createdAt)}</div><div class="row wrapr">${r.status==='OPEN'?`<button class="btn line sm" data-act="ordclose" data-id="${r.id}">Encerrar</button>`:''}<button class="btn line sm" data-act="orddel" data-id="${r.id}">Excluir</button></div></div>`).join(''):empty('Você ainda não pediu nenhum serviço.',`<p><a class="btn red" href="#/orders/new">Pedir serviço</a></p>`);
  const lock=o.vip?'':`<div class="card pad lock"><b>Contato liberado só para prestador VIP.</b><div class="mut small" style="margin:4px 0 8px">Você vê o que o cliente precisa, mas endereço e WhatsApp aparecem somente no plano VIP.</div><a class="btn red sm" href="#/plano">Ver planos VIP</a></div>`;
  return lock+(o.items.length?o.items.map(r=>`<div class="card pad col"><div class="row wrapr"><b style="flex:1">${esc(r.title)}</b>${r.profession?`<span class="pill">${esc(r.profession)}</span>`:''}</div>${r.description?`<div>${esc(r.description)}</div>`:''}<div class="mut small">${ic('pin',14)} ${esc([r.bairro,r.city].filter(Boolean).join(', '))}/${esc(r.state)} · ${esc(r.client.name)} · ${ago(r.createdAt)}</div>
   ${o.vip&&r.contact?`<div class="small"><b>Endereço:</b> ${esc(r.contact.address||'não informado')}</div><div class="row wrapr"><a class="btn wa sm" href="${waLink(r.contact.whatsapp,'Olá '+r.client.name+', vi sua ordem de serviço "'+r.title+'" na '+CFG.name+'.')}" target="_blank" rel="noopener">Chamar no WhatsApp</a></div>`:`<div class="small mut">${ic('eye',14)} Endereço e WhatsApp: somente VIP</div>`}</div>`).join(''):empty('Nenhuma ordem de serviço aberta para você na sua cidade agora. Você será avisado quando surgir uma.'))}
ACT.ordclose=async el=>{try{await api('POST','/orders/'+el.dataset.id+'/close');D.orders=await api('GET','/orders');draw()}catch(e){fail(e)}};
ACT.orddel=async el=>{if(!confirm('Excluir esta ordem?'))return;try{await api('DELETE','/orders/'+el.dataset.id);D.orders=await api('GET','/orders');draw()}catch(e){fail(e)}};
function afterFeed(){const aids=[...document.querySelectorAll('[data-ad]')].map(e=>e.dataset.ad).filter(i=>!S.seenAds.has(i));if(aids.length){aids.forEach(i=>S.seenAds.add(i));api('POST','/ads/views',{ids:aids}).catch(()=>{})}
  const ids=[...document.querySelectorAll('[data-post]')].map(e=>e.dataset.post).filter(i=>!S.seen.has(i));if(!ids.length)return;ids.forEach(i=>S.seen.add(i));api('POST','/posts/views',{ids}).catch(()=>{})}
ACT.filter=async el=>{S.filter=el.dataset.v;try{await loadFeed(false);draw()}catch(e){fail(e)}};
ACT.more=async()=>{D.feed.page++;try{await loadFeed(true);draw();afterFeed()}catch(e){D.feed.page--;fail(e)}};
ACT.cm=async el=>{const id=el.dataset.id;if(S.openC.has(id)){S.openC.delete(id);return draw()}S.openC.add(id);draw();
  try{const j=await api('GET','/posts/'+id+'/comments');S.cm[id]=j.items;draw()}catch(e){fail(e)}};
ACT.like=async el=>{const p=PM.get(el.dataset.id);if(!p)return;try{const j=await api('POST','/posts/'+p.id+'/like');p.liked=j.liked;p.likes=j.likes;draw()}catch(e){fail(e)}};
ACT.reply=async el=>{const id=el.dataset.id;if(!S.openC.has(id)){S.openC.add(id);draw()}const inp=document.querySelector(`form[data-id="${id}"] input`);if(inp){inp.value='@'+el.dataset.n+' ';inp.focus()}};
ACT.delcm=async el=>{if(!confirm('Excluir este comentário?'))return;const pid=el.dataset.p;
  try{await api('DELETE','/comments/'+el.dataset.id);const p=PM.get(pid);S.cm[pid]=(S.cm[pid]||[]).filter(c=>c.id!==el.dataset.id);if(p)p.comments=Math.max(0,p.comments-1);draw()}catch(e){fail(e)}};
ACT.delpost=async el=>{if(!confirm('Excluir esta publicação? Esta ação não pode ser desfeita.'))return;const id=el.dataset.id;
  try{await api('DELETE','/posts/'+id);PM.delete(id);D.feed.items=D.feed.items.filter(p=>p.id!==id);D.pposts=D.pposts.filter(p=>p.id!==id);toast('Publicação excluída.');if(location.hash.startsWith('#/post/'))go('/feed');else draw()}catch(e){fail(e)}};
FORMS.comment=async(f,fd)=>{const id=f.dataset.id,text=String(fd.get('text')||'').trim();if(!text)return;
  try{await api('POST','/posts/'+id+'/comments',{text});const j=await api('GET','/posts/'+id+'/comments');S.cm[id]=j.items;const p=PM.get(id);if(p)p.comments=j.items.length;draw()}catch(e){fail(e)}};
ACT.share=async el=>{
  const url=location.href.split('#')[0]+(el.dataset.t==='post'?'#/post/':'#/profile/')+el.dataset.id;
  try{if(navigator.share){await navigator.share({title:CFG.name,url});return}}catch(e){if(e.name==='AbortError')return}
  try{await navigator.clipboard.writeText(url);toast('Link copiado!')}catch(e){prompt('Copie o link:',url)}};
ACT.report=el=>{if(SV)closeStory();openModal(`<h3 style="margin-top:0">Denunciar</h3><form data-form="report" data-t="${el.dataset.t}" data-id="${el.dataset.id}">${field('Motivo','reason','',{type:'select',req:1,opts:'<option value="">Selecione</option><option>Conteúdo ofensivo ou ilegal</option><option>Golpe ou fraude</option><option>Spam</option><option>Perfil falso</option><option>Informação enganosa</option><option>Outro</option>'})}${field('Detalhes (opcional)','details','',{type:'textarea',max:500})}<button class="btn red full" type="submit">Enviar denúncia</button></form>`)};
FORMS.report=async(f,fd)=>{const r=String(fd.get('reason')||'');if(!r)return toast('Selecione um motivo.','err');
  try{await api('POST','/reports',{targetType:f.dataset.t,targetId:f.dataset.id,reason:r,details:String(fd.get('details')||'')});closeModal();toast('Denúncia enviada. Obrigado por ajudar a manter a comunidade segura.')}catch(e){fail(e)}};

/* ───────── publicar ───────── */
function viewNew(){
  const w=me().worker||{};
  return shell(`<form class="pad" data-form="post" novalidate>
  ${fileField('Fotos ou vídeos do trabalho (até 6)','media',{multi:1,prev:1,acc:'image/*,video/*'})}
  ${field('Descrição do trabalho','text','',{type:'textarea',req:1,max:2000,ph:'Conte o que foi feito, materiais, prazo...'})}
  <label class="chk"><input type="checkbox" name="ba"><span><b>Antes e depois</b><br><span class="mut small">A 1ª mídia será “ANTES” e a 2ª “DEPOIS”.</span></span></label>
  ${field('Preço ou oferta (opcional)','price','',{max:80,ph:'Ex.: A partir de R$ 80 / Orçamento grátis'})}
  <label class="chk"><input type="checkbox" name="showWa" ${w.showWhatsapp!==false?'checked':''}><span>Mostrar botão de WhatsApp</span></label>
  <label class="chk"><input type="checkbox" name="showTel" ${w.showPhone!==false?'checked':''}><span>Mostrar botão de ligação</span></label>
  <button class="btn red full" type="submit">Publicar</button></form>`,{back:1,title:'Nova publicação',nav:false});
}
FORMS.post=async(f,fd)=>{
  const text=String(fd.get('text')||'').trim();if(text.length<3)return toast('Escreva uma descrição.','err');
  const files=filesOf(fd,'media');if(!files.length)return toast('Adicione pelo menos uma foto ou vídeo.','err');if(files.length>6)return toast('Máximo de 6 arquivos.','err');
  const ba=!!fd.get('ba');if(ba&&files.length<2)return toast('Para “antes e depois” envie ao menos 2 mídias.','err');
  try{const ups=await uploadAll(files);toast('Publicando…');
    await api('POST','/posts',{text,mediaIds:ups.map(m=>m.id),beforeAfter:ba,priceText:String(fd.get('price')||'').trim(),showWhatsapp:!!fd.get('showWa'),showPhone:!!fd.get('showTel')});
    toast('Publicado!');go('/feed')}catch(e){fail(e)}
};
function viewPostEdit(){const p=D.post;
  return shell(`<form class="pad" data-form="postedit" data-id="${p.id}" novalidate>${field('Descrição','text',p.text,{type:'textarea',req:1})}${field('Preço ou oferta','price',p.priceText||'',{max:80})}
  <label class="chk"><input type="checkbox" name="showWa" ${p.contacts.whatsapp?'checked':''}><span>Mostrar botão de WhatsApp</span></label><label class="chk"><input type="checkbox" name="showTel" ${p.contacts.phone?'checked':''}><span>Mostrar botão de ligação</span></label>
  <p class="small mut">Para trocar as fotos/vídeos, exclua e publique novamente.</p><button class="btn red full" type="submit">Salvar</button></form>`,{back:1,title:'Editar publicação',nav:false})}
FORMS.postedit=async(f,fd)=>{const text=String(fd.get('text')||'').trim();if(text.length<3)return toast('Escreva uma descrição.','err');
  try{await api('PATCH','/posts/'+f.dataset.id,{text,priceText:String(fd.get('price')||'').trim(),showWhatsapp:!!fd.get('showWa'),showPhone:!!fd.get('showTel')});PM.delete(f.dataset.id);toast('Publicação atualizada.');go('/feed')}catch(e){fail(e)}};
const viewPost=()=>shell(postCard(D.post,{open:true}),{back:1,title:'Publicação'});

/* ───────── Stories ───────── */
const viewStoryNew=()=>shell(`<form class="pad" data-form="story" novalidate><p class="small mut">Seu Story fica visível por 24 horas e depois é removido automaticamente.</p>
  ${fileField('Foto ou vídeo','media',{prev:1,acc:'image/*,video/*'})}${field('Texto (opcional)','text','',{max:200})}${field('Localização (opcional)','loc','',{max:80,ph:'Bairro, cidade'})}
  <label class="chk"><input type="checkbox" name="contact" checked><span>Mostrar botão de contato</span></label><button class="btn red full" type="submit">Publicar Story</button></form>`,{back:1,title:'Novo Story',nav:false});
FORMS.story=async(f,fd)=>{const files=filesOf(fd,'media');if(!files.length)return toast('Escolha uma foto ou vídeo.','err');
  try{const [m]=await uploadAll(files.slice(0,1));await api('POST','/stories',{mediaId:m.id,text:String(fd.get('text')||'').trim(),location:String(fd.get('loc')||'').trim(),showContact:!!fd.get('contact')});toast('Story publicado por 24 horas!');go('/feed')}catch(e){fail(e)}};
let SV=null;
ACT.story=el=>{const g=D.stories.find(x=>x.author.id===el.dataset.id);if(!g||!g.stories.length)return;const first=g.stories.findIndex(s=>g.isMe||!s.seen);SV={g,list:g.stories,i:first<0?0:first,t:null};showStory()};
function showStory(){
  clearTimeout(SV.t);const s=SV.list[SV.i];if(!s)return closeStory();const g=SV.g,mine=g.isMe;
  if(!mine&&!s.seen){s.seen=true;api('POST','/stories/'+s.id+'/view').catch(()=>{});g.hasUnseen=g.stories.some(x=>!x.seen)}
  const bars=SV.list.map((_,i)=>`<i class="${i<SV.i?'d':i===SV.i?'c':''}"></i>`).join('');
  const btns=[];
  if(!mine){if(s.contacts.whatsapp)btns.push(`<a class="btn wa sm" href="${waLink(s.contacts.whatsapp,'Olá! Vi seu Story.')}" target="_blank" rel="noopener">WhatsApp</a>`);if(s.contacts.phone)btns.push(`<a class="btn sm" href="tel:${digits(s.contacts.phone)}">Ligar</a>`)}
  if(mine)btns.push(`<button class="btn sm" data-act="sviews">${ic('eye',16)} ${s.views||0} visualizações</button><button class="btn sm" data-act="sdel">${ic('trash',16)} Excluir</button>`);
  else btns.push(`<button class="btn sm" data-act="report" data-t="story" data-id="${s.id}">${ic('flag',16)} Denunciar</button>`);
  $('#modal').innerHTML=`<div class="sv"><div class="bars">${bars}</div><div class="svh">${avatar(g.author,36)}<b>${esc(g.author.name)}</b><span class="mut small">${ago(s.createdAt)}</span><span class="sp"></span><button class="ib" data-act="sclose" aria-label="Fechar">${ic('x')}</button></div>
  <div class="svb">${s.kind==='video'?`<video src="${esc(mu(s.url))}" autoplay playsinline id="svv"></video>`:`<img src="${esc(mu(s.url))}" alt="Story">`}<div class="tap l" data-act="sprev"></div><div class="tap r" data-act="snext"></div>
  ${s.text||s.location?`<div class="svt">${s.text?`<div style="font-size:18px">${esc(s.text)}</div>`:''}${s.location?`<div class="small">${ic('pin',14)} ${esc(s.location)}</div>`:''}</div>`:''}</div><div class="svf">${btns.join('')}</div></div>`;
  const v=$('#svv');if(v){v.onended=()=>ACT.snext();v.play&&v.play().catch(()=>{})}else SV.t=setTimeout(()=>ACT.snext(),5000);
}
function closeStory(){if(SV)clearTimeout(SV.t);SV=null;closeModal();if(location.hash.startsWith('#/feed'))draw()}
ACT.snext=()=>{if(!SV)return;SV.i++;SV.i>=SV.list.length?closeStory():showStory()};
ACT.sprev=()=>{if(!SV)return;SV.i=Math.max(0,SV.i-1);showStory()};
ACT.sclose=()=>closeStory();
ACT.sdel=async()=>{if(!confirm('Excluir este Story?'))return;const s=SV.list[SV.i];
  try{await api('DELETE','/stories/'+s.id);SV.list.splice(SV.i,1);if(!SV.list.length){D.stories=D.stories.filter(x=>x!==SV.g);return closeStory()}SV.i=Math.min(SV.i,SV.list.length-1);showStory()}catch(e){fail(e)}};
ACT.sviews=async()=>{const s=SV.list[SV.i];clearTimeout(SV.t);
  try{const j=await api('GET','/stories/'+s.id+'/views');$('#modal').insertAdjacentHTML('beforeend',`<div class="ov"><div class="sheet"><h3 style="margin-top:0">Visualizações (${j.items.length})</h3>${j.items.length?j.items.map(n=>`<div style="padding:6px 0">${esc(n.name)}</div>`).join(''):'<p class="mut">Ninguém viu ainda.</p>'}<button class="btn red full" data-act="svclose">Fechar</button></div></div>`)}catch(e){fail(e)}};
ACT.svclose=()=>showStory();

/* ───────── perfil ───────── */
function viewProfile(){
  const u=D.profile,mine=u.isMe,w=u.worker||{},posts=D.pposts;
  const contacts=[];
  if(!mine&&isW(u)){if(u.contacts.whatsapp)contacts.push(`<a class="btn wa" href="${waLink(u.contacts.whatsapp,'Olá '+u.name+'!')}" target="_blank" rel="noopener">WhatsApp</a>`);if(u.contacts.phone)contacts.push(`<a class="btn" href="tel:${digits(u.contacts.phone)}">${ic('phone',16)}Ligar</a>`)}
  const vb=verBadges(w);
  const about=isW(u)?`<div class="pad col">
   ${w.bio?`<div><b>Apresentação</b><p style="margin:4px 0">${esc(w.bio).replace(/\n/g,'<br>')}</p></div>`:''}
   ${w.specialties?`<div><b>Especialidades</b><p style="margin:4px 0">${esc(w.specialties)}</p></div>`:''}
   ${w.experience?`<div><b>Experiência</b><p style="margin:4px 0">${esc(w.experience).replace(/\n/g,'<br>')}</p></div>`:''}
   ${w.courses?`<div><b>Cursos e certificados</b><p style="margin:4px 0">${esc(w.courses).replace(/\n/g,'<br>')}</p></div>`:''}
   <div><b>Disponibilidade</b><p style="margin:4px 0">${esc(w.availability||'—')} · atende em até ${w.radiusKm||'—'} km de ${esc(u.city||'')}</p></div>
   <p class="small mut">${vb?'Conferido pela administração: '+[w.verifiedIdentity&&'identidade',w.verifiedQualifications&&'qualificações/documentos'].filter(Boolean).join(' e ')+'. Isso não representa garantia absoluta de segurança; contrate com cautela.':'Este perfil ainda não possui verificações de identidade ou qualificações. Quando houver, o selo indicará apenas o que foi conferido, sem garantia absoluta de segurança.'}</p></div>`:`<div class="pad mut">${esc(u.role==='COMPANY'?'Empresa':'Cliente')} desde ${new Date(u.createdAt).toLocaleDateString('pt-BR')}.</div>`;
  const grid=posts.length?`<div class="grid3">${posts.map(p=>`<a href="#/post/${p.id}">${p.media[0].kind==='video'?`<video src="${esc(mu(p.media[0].url))}" muted preload="metadata"></video>`:`<img src="${esc(mu(p.media[0].url))}" alt="" loading="lazy">`}</a>`).join('')}</div>`:empty(mine?'Você ainda não publicou trabalhos.':'Nenhum trabalho publicado.');
  const totalViews=posts.reduce((s,p)=>s+(p.views||0),0);
  const body=`<div class="card" style="margin-top:0;border-radius:0;border-width:0 0 1px"><div class="cover" ${w.coverUrl?`style="background-image:url(${esc(mu(w.coverUrl))})"`:''}></div>
  <div class="pf"><div class="row" style="align-items:flex-end">${avatar(u,84)}<span class="sp"></span>${mine?`<a class="btn line sm" href="#/me/edit">${ic('edit',16)}Editar perfil</a>`:`<button class="btn ${u.following?'line':'red'} sm" data-act="follow" data-id="${u.id}">${u.following?'Seguindo':'Seguir'}</button><button class="ib" data-act="report" data-t="user" data-id="${u.id}" aria-label="Denunciar">${ic('flag',18)}</button>`}<button class="ib" data-act="share" data-t="profile" data-id="${u.id}" aria-label="Compartilhar">${ic('share',18)}</button></div>
  <h2 style="margin:10px 0 0">${esc(u.name)}</h2><div class="mut">${esc(roleLabel(u))}</div>${vb?`<div class="row wrapr" style="margin-top:6px">${vb}</div>`:''}
  <div class="mut small">${ic('pin',14)} ${esc([u.bairro,u.city].filter(Boolean).join(', '))}${u.state?'/'+esc(u.state):''}</div>
  <div class="row wrapr" style="margin-top:8px"><span class="small"><b>${u.counts.posts}</b> publicações</span><span class="small"><b>${u.counts.followers}</b> seguidores</span>${w.lookingForJob?'<span class="pill">Procurando emprego</span>':''}</div>
  ${mine&&isW(u)?`<div class="row wrapr small mut" style="margin-top:8px">${ic('eye',16)} ${w.profileViews||0} visitas ao perfil · ${totalViews} visualizações nas publicações</div>`:''}
  ${contacts.length?`<div class="row wrapr" style="margin-top:12px">${contacts.join('')}</div>`:''}</div></div>
  <div class="tabs"><button class="${S.tab==='port'?'on':''}" data-act="ptab" data-v="port">${isW(u)?'Portfólio':'Publicações'}</button><button class="${S.tab==='about'?'on':''}" data-act="ptab" data-v="about">Sobre</button></div>${S.tab==='about'?about:grid}`;
  return shell(body,{back:!mine,nav:true});
}
ACT.ptab=el=>{S.tab=el.dataset.v;draw()};
ACT.follow=async el=>{const id=el.dataset.id;try{const j=await api('POST','/users/'+id+'/follow');
  PM.forEach(p=>{if(p.author.id===id)p.author.following=j.following});
  if(D.profile&&D.profile.id===id){D.profile.following=j.following;D.profile.counts.followers=j.followers}
  [D.net,D.sres||[]].forEach(l=>l.forEach(x=>{if(x.id===id)x.following=j.following}));
  draw();toast(j.following?'Você começou a seguir.':'Você deixou de seguir.')}catch(e){fail(e)}};
function viewEdit(){
  const u=AUTH.user,w=u.worker;
  return shell(`<form class="pad" data-form="profile" novalidate>
  ${fileField('Foto de perfil','avatar')}${w?fileField('Foto de capa','cover'):''}
  ${field('Nome completo','name',u.name,{req:1,max:120})}${field('Telefone (com DDD)','phone',u.phone,{type:'tel',req:1,max:20})}
  <div class="row"><div style="flex:2">${field('Cidade','city',u.city,{req:1})}</div><div style="flex:1">${field('UF','state','',{type:'select',opts:ufOpts(u.state),req:1})}</div></div>
  ${field('Bairro','bairro',u.bairro||'',{max:80})}
  ${w?`${field('Profissão principal','profession','',{type:'select',opts:profOpts(w.profession),req:1})}
  ${field('Outras especialidades','specialties',w.specialties,{max:200,ph:'Ex.: Pintura, gesso, textura'})}
  ${field('Apresentação profissional','bio',w.bio,{type:'textarea',max:1500})}
  ${field('Experiência profissional','experience',w.experience,{type:'textarea',max:1500})}
  ${field('Cursos e certificados','courses',w.courses,{type:'textarea',max:1000})}
  ${field('Disponibilidade','avail','',{type:'select',opts:['Disponível','Disponível em breve','Agenda cheia','Apenas fins de semana'].map(o=>`<option ${o===w.availability?'selected':''}>${o}</option>`).join('')})}
  ${field('Região de atendimento (km)','radius',w.radiusKm,{type:'number',attr:'min="1" max="500"'})}
  ${field('WhatsApp (com DDD)','wa',w.whatsapp,{type:'tel',max:20})}
  <label class="chk"><input type="checkbox" name="showWa" ${w.showWhatsapp?'checked':''}><span>Divulgar meu WhatsApp publicamente</span></label>
  <label class="chk"><input type="checkbox" name="showTel" ${w.showPhone?'checked':''}><span>Divulgar meu telefone publicamente</span></label>
  <label class="chk"><input type="checkbox" name="looking" ${w.lookingForJob?'checked':''}><span>Estou procurando emprego</span></label>`:''}
  <button class="btn red full" type="submit">Salvar perfil</button></form>`,{back:1,title:'Editar perfil',nav:false});
}
FORMS.profile=async(f,fd)=>{
  const u=AUTH.user,v=k=>String(fd.get(k)||'').trim();
  if(v('name').length<2)return toast('Informe seu nome.','err');if(!validPhone(v('phone')))return toast('Telefone inválido.','err');if(!v('city')||!v('state'))return toast('Informe cidade e UF.','err');
  if(u.worker){if(!v('profession'))return toast('Selecione a profissão principal.','err');if(v('wa')&&!validPhone(v('wa')))return toast('WhatsApp inválido.','err')}
  try{
    const body={name:v('name'),phone:digits(v('phone')),city:v('city'),state:v('state'),bairro:v('bairro')};
    const av=filesOf(fd,'avatar')[0];if(av)body.avatarMediaId=(await uploadAll([av],320))[0].id;
    let res=await api('PATCH','/me',body);
    if(u.worker){
      const wb={profession:v('profession'),specialties:v('specialties'),bio:v('bio'),experience:v('experience'),courses:v('courses'),availability:v('avail'),radiusKm:Math.max(1,Math.min(500,parseInt(v('radius'))||30)),whatsapp:digits(v('wa')),showWhatsapp:!!fd.get('showWa'),showPhone:!!fd.get('showTel'),lookingForJob:!!fd.get('looking')};
      const cv=filesOf(fd,'cover')[0];if(cv)wb.coverMediaId=(await uploadAll([cv],1000))[0].id;
      res=await api('PATCH','/me/worker',wb);
    }
    AUTH.user=res;saveAuth();toast('Perfil salvo.');go('/me')}catch(e){fail(e)}
};

/* ───────── notificações e ajustes ───────── */
function viewNotifs(){const l=D.notifs;
  return shell(l.length?l.map(n=>`<a class="notif ${n.read?'':'new'}" href="#${esc(n.link||'/feed')}">${ic('bell',18)}<div><div>${esc(n.text)}</div><div class="mut small">${ago(n.createdAt)}</div></div></a>`).join(''):empty('Você não tem notificações.'),{back:1,title:'Notificações'});
}
function viewSettings(){const u=AUTH.user;
  return shell(`<div class="card pad col"><div class="row">${avatar(u,48)}<div><b>${esc(u.name)}</b><div class="mut small">${esc(u.email)} · ${esc(roleLabel(u))}</div></div></div><a class="btn line" href="#/me/edit">${ic('edit',16)}Editar perfil</a>${CFG.payments&&u.role!=='ADMIN'?`<a class="btn line" href="#/plano">Meu plano e pagamentos</a>`:''}${CFG.payments&&(u.role==='WORKER'||u.role==='COMPANY')?`<a class="btn line" href="#/ads">Anunciar no ${esc(CFG.name)}</a>`:''}</div>
  <div class="card pad col"><b>Alterar senha</b><form data-form="pw" novalidate>${field('Senha atual','old','',{type:'password',req:1,max:100})}${field('Nova senha (mínimo 10 caracteres)','pw','',{type:'password',req:1,max:100})}<button class="btn red full" type="submit">Alterar senha</button></form></div>
  <div class="card pad col"><b>Privacidade e dados (LGPD)</b><button class="btn line" data-act="doc" data-v="terms">Termos de Uso</button><button class="btn line" data-act="doc" data-v="privacy">Política de Privacidade</button><button class="btn line" data-act="export">Exportar meus dados</button><button class="btn line" data-act="delacc" style="color:#ff6b63">Excluir minha conta</button></div>
  <div class="card pad"><button class="btn full" data-act="logout">${ic('out',18)}Sair</button></div>${envNote()}`,{title:'Ajustes',nav:true});
}
FORMS.pw=async(f,fd)=>{const n=String(fd.get('pw')||'');if(n.length<10)return toast('A nova senha deve ter pelo menos 10 caracteres.','err');
  try{const j=await api('POST','/me/password',{oldPassword:String(fd.get('old')||''),newPassword:n});AUTH.access=j.accessToken;AUTH.refresh=j.refreshToken;saveAuth();f.reset();toast('Senha alterada. Outros aparelhos foram desconectados.')}catch(e){fail(e)}};
function download(name,type,text){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;document.body.appendChild(a);a.click();a.remove()}
ACT.export=async()=>{try{const j=await api('GET','/me/export');download('meus-dados.json','application/json',JSON.stringify(j,null,2));toast('Arquivo gerado.')}catch(e){fail(e)}};
ACT.delacc=()=>openModal(`<h3 style="margin-top:0">Excluir conta</h3><p class="small">Seu perfil, publicações, Stories, comentários e curtidas serão apagados definitivamente. Confirme com sua senha.</p><form data-form="delacc">${field('Senha','pw','',{type:'password',req:1,max:100})}<button class="btn red full" type="submit">Excluir definitivamente</button></form>`);
FORMS.delacc=async(f,fd)=>{try{await api('DELETE','/me',{password:String(fd.get('pw')||'')});AUTH=null;saveAuth();S.mode='login';PM.clear();closeModal();toast('Conta excluída.');go('/auth')}catch(e){fail(e)}};

/* ───────── plano e pagamento (Mercado Pago) ───────── */
const PAYST={PAID:'Pago',PENDING:'Aguardando pagamento',FAILED:'Não aprovado',REFUNDED:'Estornado'};
function viewPlano(){
  const b=D.bill,pl=D.plans,s=b.subscription;
  const banner=S.payMsg?`<div class="card pad" style="border-color:var(--red)">${esc(S.payMsg)}</div>`:'';
  const cur=s?`<div class="card pad"><div class="mut small">Seu plano atual</div><div style="font-size:20px;font-weight:800">${esc(s.planName)}</div><div class="mut small">Ativo até ${new Date(s.endsAt).toLocaleDateString('pt-BR')}</div></div>`:`<div class="card pad"><b>Você está no plano gratuito.</b><div class="mut small">Planos pagos dão mais destaque e vantagens quando disponíveis.</div></div>`;
  const list=pl.items.length?pl.items.map(p=>`<div class="card pad col"><div class="row"><b style="flex:1;font-size:17px">${esc(p.name)}</b><span style="font-size:18px;font-weight:800">${money(p.priceCents)}</span></div><div class="mut small">por ${p.durationDays} dias</div>${p.description?`<div>${esc(p.description)}</div>`:''}${(p.benefits.list||[]).length?`<ul style="margin:0;padding-left:18px">${p.benefits.list.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:''}
    <button class="btn red full" data-act="buy" data-id="${p.id}" ${pl.enabled?'':'disabled'}>${s&&s.planId===p.id?'Renovar':'Assinar'} · Pix ou cartão</button></div>`).join(''):empty('Ainda não há planos pagos disponíveis para o seu tipo de conta.');
  const pays=b.payments.length?`<div class="card pad col"><b>Meus pagamentos</b>${b.payments.map(x=>`<div class="row wrapr small"><span style="flex:1">${esc(x.planName||'Plano')} · ${new Date(x.createdAt).toLocaleDateString('pt-BR')}</span><span>${money(x.amountCents)}</span><span class="pill">${PAYST[x.status]||x.status}</span></div>`).join('')}</div>`:'';
  return shell(`${banner}${cur}${pl.enabled?'':'<div class="demo">Pagamentos ainda não estão ativados neste servidor.</div>'}${list}${pays}<p class="small mut pad">O pagamento é feito no ambiente seguro do Mercado Pago (Pix ou cartão). O BiGo não vê nem guarda dados do seu cartão. O plano só é liberado depois da confirmação do pagamento.</p>${envNote()}`,{back:1,title:'Meu plano'});
}
ACT.buy=async el=>{el.disabled=true;
  try{const j=await api('POST','/billing/checkout',{planId:el.dataset.id});toast('Abrindo o pagamento seguro do Mercado Pago…');location.href=j.checkoutUrl}catch(e){el.disabled=false;fail(e)}};
async function pollPay(ref,my,n=0,ad=false){
  try{const j=await api('GET','/billing/payments/'+ref);if(my!==RT)return;
    if(j.status==='PAID'){if(ad){S.payMsg='Pagamento confirmado! Seu anúncio já está no ar.';D.admine=(await api('GET','/ads/mine')).items}else{S.payMsg='Pagamento confirmado! Seu plano já está ativo.';D.bill=await api('GET','/billing/me')}return draw()}
    if(j.status==='FAILED'){S.payMsg='O pagamento não foi aprovado. Você pode tentar novamente.';return draw()}
    if(j.status==='REFUNDED'){S.payMsg='Este pagamento foi estornado.';return draw()}
    S.payMsg='Aguardando a confirmação do pagamento… (Pix pode levar alguns instantes)';draw();
    if(n<30)setTimeout(()=>pollPay(ref,my,n+1,ad),4000);else{S.payMsg='Ainda não recebemos a confirmação. Se você já pagou, aguarde alguns minutos e volte a esta tela.';draw()}
  }catch(e){}
}

/* ───────── ordem de serviço, busca e anúncios ───────── */
function viewOrderNew(){const u=AUTH.user;
  return shell(`<form class="pad" data-form="ordernew" novalidate><p class="small mut">Os prestadores da sua cidade (da profissão escolhida) recebem um aviso. Endereço e WhatsApp só aparecem para prestadores VIP.</p>
  ${field('O que você precisa?','title','',{req:1,max:100,ph:'Ex.: Pintar sala e dois quartos'})}
  ${field('Profissional','profession','',{type:'select',opts:'<option value="">Qualquer profissional</option>'+profOpts('').replace(/^<option value="">[^<]*<\/option>/,'')})}
  ${field('Detalhes','description','',{type:'textarea',max:1500,ph:'Tamanho, prazo, materiais...'})}
  ${field('Endereço do serviço (rua e número)','address','',{max:200})}
  ${field('Bairro','bairro',u.bairro||'',{max:80})}
  <div class="row"><div style="flex:2">${field('Cidade','city',u.city||'',{req:1})}</div><div style="flex:1">${field('UF','state','',{type:'select',opts:ufOpts(u.state),req:1})}</div></div>
  ${field('Seu WhatsApp (com DDD)','whatsapp',u.phone||'',{type:'tel',req:1,max:20})}
  <button class="btn red full" type="submit">Enviar ordem de serviço</button></form>`,{back:1,title:'Pedir serviço',nav:false});
}
FORMS.ordernew=async(f,fd)=>{const v=k=>String(fd.get(k)||'').trim();
  if(v('title').length<3)return toast('Diga o que você precisa.','err');if(!v('city')||!v('state'))return toast('Informe cidade e UF.','err');if(!validPhone(v('whatsapp')))return toast('WhatsApp inválido.','err');
  try{const j=await api('POST','/orders',{title:v('title'),profession:v('profession'),description:v('description'),address:v('address'),bairro:v('bairro'),city:v('city'),state:v('state'),whatsapp:digits(v('whatsapp'))});
    S.filter='orders';toast(j.notified?'Ordem enviada! '+j.notified+' prestador(es) da sua cidade foram avisados.':'Ordem enviada! Ainda não há prestadores dessa profissão na sua cidade; ela ficará aberta para quem entrar.');go('/feed')}catch(e){fail(e)}};

const srchRole=x=>x.role==='WORKER'?(x.profession||'Trabalhador'):x.role==='COMPANY'?'Empresa':'Cliente';
function searchRes(){const l=D.sres;if(l===null)return'<p class="mut pad small">Digite pelo menos 2 letras: nome, profissão ou cidade.</p>';
  return l.length?l.map(x=>`<div class="card pad row" style="margin:8px 12px"><a href="#/profile/${x.id}">${avatar(x,46)}</a><a href="#/profile/${x.id}" style="flex:1;min-width:0"><b>${esc(x.name)}</b>${x.verified?' <span class="pill" style="color:#6be3a0">conferido</span>':''}<div class="mut small">${esc(srchRole(x))} · ${esc(x.city)}${x.state?'/'+esc(x.state):''}</div></a>${x.following?'<span class="pill">Seguindo</span>':`<button class="btn red sm" data-act="follow" data-id="${x.id}">Seguir</button>`}</div>`).join(''):empty('Nenhuma conta encontrada.')}
function viewSearch(){return shell(`<form class="srch" data-form="search"><input class="in" name="q" value="${esc(S.q)}" placeholder="Buscar pessoas, profissões ou cidades" autocomplete="off" maxlength="60"><button class="btn red" type="submit" aria-label="Buscar">${ic('search',18)}</button></form>
  <div class="chips"><button class="chip ${S.stype!=='workers'?'on':''}" data-act="stype" data-v="all">Todas as contas</button><button class="chip ${S.stype==='workers'?'on':''}" data-act="stype" data-v="workers">Só profissionais</button></div><div id="sres">${searchRes()}</div>`,{back:1,title:'Buscar'})}
async function runSearch(){const q=S.q.trim();if(q.length<2){D.sres=null}else{try{D.sres=(await api('GET','/search?q='+encodeURIComponent(q)+'&type='+S.stype)).items}catch(e){return fail(e)}}
  if(location.hash.startsWith('#/search')){const b=$('#sres');if(b)b.innerHTML=searchRes()}}
FORMS.search=async(f,fd)=>{S.q=String(fd.get('q')||'');await runSearch()};
ACT.stype=async el=>{S.stype=el.dataset.v;await runSearch();draw()};
let ST_T;document.addEventListener('input',e=>{const i=e.target;if(!(i instanceof HTMLInputElement)||i.name!=='q'||!i.closest('form[data-form=search]'))return;S.q=i.value;clearTimeout(ST_T);ST_T=setTimeout(runSearch,350)});

const ADST={AWAITING_PAYMENT:'Aguardando pagamento',ACTIVE:'No ar',PAUSED:'Pausado',EXPIRED:'Encerrado'};
function viewAds(){const u=AUTH.user,pk=D.adpk,l=D.admine;
  const banner=S.payMsg?`<div class="card pad" style="border-color:var(--red)">${esc(S.payMsg)}</div>`:'';
  const mine=l.length?l.map(a=>`<div class="card pad col"><div class="row wrapr">${a.imageUrl?`<img src="${esc(mu(a.imageUrl))}" alt="" style="width:56px;height:56px;object-fit:cover;border-radius:10px">`:''}<div style="flex:1;min-width:140px"><b>${esc(a.title)}</b><div class="mut small">${esc(a.packageName||'')}${a.status==='ACTIVE'&&a.endsAt?' · até '+new Date(a.endsAt).toLocaleDateString('pt-BR'):''}</div></div><span class="pill">${ADST[a.status]||a.status}</span></div><div class="mut small">${a.impressions} visualizações · ${a.clicks} cliques</div><div class="row wrapr">${a.status==='AWAITING_PAYMENT'?`<button class="btn red sm" data-act="adpay" data-id="${a.id}">Pagar e publicar</button>`:''}${['AWAITING_PAYMENT','PAUSED','EXPIRED'].includes(a.status)?`<button class="btn line sm" data-act="addel" data-id="${a.id}">Excluir</button>`:''}</div></div>`).join(''):empty('Você ainda não criou anúncios.');
  const form=pk.items.length?`<form class="card pad" data-form="adnew" novalidate><b>Criar anúncio</b><p class="small mut">O anúncio só entra no ar depois do pagamento aprovado e aparece no feed das pessoas da região escolhida.</p>
   ${field('Título','title','',{req:1,max:80})}${field('Texto (opcional)','body','',{type:'textarea',max:300})}${fileField('Imagem do anúncio','media',{prev:1})}
   ${field('WhatsApp (com DDD)','whatsapp',u.phone||'',{type:'tel',max:20})}${field('Ou link do site (https://...)','targetUrl','',{max:300})}
   <div class="row"><div style="flex:2">${field('Cidade (vazio = todo o estado)','city',u.city||'',{max:80})}</div><div style="flex:1">${field('UF','state','',{type:'select',opts:ufOpts(u.state)})}</div></div>
   ${field('Pacote','packageId','',{type:'select',req:1,opts:pk.items.map(p=>`<option value="${p.id}">${esc(p.name)} — ${money(p.priceCents)} por ${p.durationDays} dias</option>`).join('')})}
   <button class="btn red full" type="submit" ${pk.enabled?'':'disabled'}>Continuar para o pagamento</button></form>`:empty('Os pacotes de anúncio ainda não foram definidos pela administração.');
  return shell(`${banner}${pk.enabled?'':'<div class="demo">Pagamentos ainda não estão ativados neste servidor.</div>'}${form}<div class="pad"><b>Meus anúncios</b></div>${mine}<p class="small mut pad">Pagamento no ambiente seguro do Mercado Pago (Pix ou cartão). Anúncios que violem as regras podem ser retirados pela administração.</p>`,{back:1,title:'Anunciar',nav:true});
}
FORMS.adnew=async(f,fd)=>{const v=k=>String(fd.get(k)||'').trim();
  if(v('title').length<3)return toast('Informe o título do anúncio.','err');if(!v('whatsapp')&&!v('targetUrl'))return toast('Informe um WhatsApp ou um link.','err');if(v('whatsapp')&&!validPhone(v('whatsapp')))return toast('WhatsApp inválido.','err');
  try{const img=filesOf(fd,'media')[0];let mediaId;if(img)mediaId=(await uploadAll([img],1200))[0].id;
    const j=await api('POST','/ads',{packageId:v('packageId'),title:v('title'),body:v('body'),mediaId,whatsapp:digits(v('whatsapp')),targetUrl:v('targetUrl'),city:v('city'),state:v('state')});
    toast('Abrindo o pagamento seguro do Mercado Pago…');location.href=j.checkoutUrl}catch(e){fail(e)}};
ACT.adpay=async el=>{el.disabled=true;try{const j=await api('POST','/ads/'+el.dataset.id+'/checkout');location.href=j.checkoutUrl}catch(e){el.disabled=false;fail(e)}};
ACT.addel=async el=>{if(!confirm('Excluir este anúncio?'))return;try{await api('DELETE','/ads/'+el.dataset.id);D.admine=(await api('GET','/ads/mine')).items;draw()}catch(e){fail(e)}};

/* ───────── painel administrativo ───────── */
const A={tab:'over',q:'',role:'',st:'',rst:'OPEN',d:null,err:null};
const isSuper=a=>a&&a.role==='SUPER_ADMIN';
const ATABS=[['over','Visão geral'],['users','Usuários'],['posts','Publicações'],['stories','Stories'],['cms','Comentários'],['reps','Denúncias'],['cats','Categorias'],['set','Configurações'],['admins','Admins'],['plans','Planos'],['ads','Anúncios'],['pays','Pagamentos'],['logs','Atividades']];
const tabsFor=a=>ATABS.filter(([k])=>isSuper(a)||!['logs','plans','pays'].includes(k));
const exc=(s,n=90)=>esc(String(s||'').slice(0,n))+(String(s||'').length>n?'…':'');
const thumb=(url,kind)=>url?(kind==='video'?`<video src="${esc(mu(url))}" muted preload="metadata" style="width:56px;height:56px;object-fit:cover;border-radius:8px"></video>`:`<img src="${esc(mu(url))}" alt="" style="width:56px;height:56px;object-fit:cover;border-radius:8px">`):'';
async function loadAdmin(){
  const t=A.tab,q=new URLSearchParams();let d=null;
  if(t==='over')d=await api('GET','/admin/overview');
  else if(t==='users'){if(A.q)q.set('q',A.q);if(A.role)q.set('role',A.role);if(A.st)q.set('status',A.st);d=await api('GET','/admin/users?'+q)}
  else if(t==='posts')d=await api('GET','/admin/posts');
  else if(t==='stories')d=await api('GET','/admin/stories');
  else if(t==='cms')d=await api('GET','/admin/comments');
  else if(t==='reps')d=await api('GET','/admin/reports'+(A.rst?'?status='+A.rst:''));
  else if(t==='cats'){CATS=await api('GET','/categories',undefined,{anon:true});d=CATS}
  else if(t==='admins')d=isSuper(adm())?await api('GET','/admin/admins'):{items:[]};
  else if(t==='plans')d=await api('GET','/admin/plans');
  else if(t==='pays')d=await api('GET','/admin/payments');
  else if(t==='ads')d=await api('GET','/admin/ads');
  else if(t==='logs')d=await api('GET','/admin/logs');
  A.d=d;
}
function viewAdmin(){
  const a=adm();
  const tabs=tabsFor(a).map(([k,l])=>`<button class="chip ${A.tab===k?'on':''}" data-act="atab" data-v="${k}">${l}</button>`).join('');
  const fn={over:aOver,users:aUsers,posts:aPosts,stories:aStories,cms:aCms,reps:aReps,cats:aCats,set:aSet,admins:aAdmins,plans:aPlans,pays:aPays,ads:aAds,logs:aLogs}[A.tab]||aOver;
  const body=A.err?`<div class="empty">${esc(A.err)}<p><button class="btn red" data-act="retry">Tentar novamente</button></p></div>`:(A.d===null&&!['set'].includes(A.tab)?'<div class="empty">Carregando…</div>':fn(a));
  return`<div class="wrap" style="max-width:980px"><header class="top">${logo(30)}<b>Painel ADM</b><span class="sp"></span><span class="mut small">${esc(a.name)}</span><button class="ib" data-act="alogout" aria-label="Sair">${ic('out')}</button></header><div class="chips">${tabs}</div>${a.mustChangePassword?'<div class="demo" style="border-color:var(--red);color:var(--txt)">Você ainda usa a senha inicial. Troque agora em <b>Admins → Meus dados de acesso</b>.</div>':''}${body}</div>`}
ACT.atab=async el=>{A.tab=el.dataset.v;A.d=null;A.err=null;draw();try{await loadAdmin()}catch(e){if(e.status!==401)A.err=e.message}draw()};
ACT.alogout=()=>{AUTH=null;saveAuth();S.mode='login';go('/auth')};
async function areload(){try{await loadAdmin();A.err=null}catch(e){if(e.status!==401)A.err=e.message}draw()}
const doA=async(fn,okMsg)=>{try{await fn();if(okMsg)toast(okMsg);await areload()}catch(e){fail(e)}};

function aOver(){const t=A.d.totals,g=A.d.growth,mx=Math.max(1,...g.map(d=>d.n));
  const tiles=[['Total de usuários',t.users],['Clientes',t.clients],['Trabalhadores',t.workers],['Empresas',t.companies],['Publicações',t.posts],['Stories ativos',t.stories],['Comentários',t.comments],['Denúncias abertas',t.openReports],['Ativos em 7 dias',t.active7],['Bloqueados',t.blocked]];
  return`<div class="grid2">${tiles.map(([l,n])=>`<div class="card pad" style="margin:6px"><div class="mut small">${l}</div><div style="font-size:26px;font-weight:800">${n}</div></div>`).join('')}</div>
  <div class="card pad"><b>Crescimento: novos usuários nos últimos 14 dias</b><div class="bars2">${g.map(d=>`<div title="${new Date(d.day).toLocaleDateString('pt-BR')}: ${d.n}"><i style="height:${Math.round(d.n/mx*80)+4}%"></i><span>${d.n}</span></div>`).join('')}</div></div>
  <div class="card pad small mut">Ainda não existem nesta versão: vagas, cupons e anúncios. Eles entram nas próximas etapas. Planos e pagamentos estão nas abas Planos e Pagamentos.</div>
  ${isSuper(adm())?`<div class="card pad"><button class="btn line" data-act="aexport">Exportar usuários (CSV)</button></div>`:''}`}
ACT.aexport=async()=>{try{const j=await api('GET','/admin/users/export');download('usuarios.csv','text/csv',j.csv);toast('Relatório gerado.')}catch(e){fail(e)}};
function aUsers(){const sup=isSuper(adm()),l=A.d.items;
  const sel=(n,v,o)=>`<select class="in" style="width:auto" name="${n}">${o.map(([k,t])=>`<option value="${k}" ${k===v?'selected':''}>${t}</option>`).join('')}</select>`;
  return`<form class="pad row wrapr" data-form="afilter"><input class="in" style="flex:1;min-width:150px" name="q" placeholder="Buscar nome, e-mail ou cidade" value="${esc(A.q)}">${sel('role',A.role,[['','Todos os tipos'],['CLIENT','Clientes'],['WORKER','Trabalhadores'],['COMPANY','Empresas']])}${sel('st',A.st,[['','Todas as situações'],['active','Ativos'],['blocked','Bloqueados']])}<button class="btn sm" type="submit">Filtrar</button>${sup?'<button class="btn red sm" type="button" data-act="anew">+ Cadastrar</button>':''}</form>
  <div class="small mut" style="padding:0 14px">${l.length} usuário(s)${l.length>=100?' (mostrando os 100 mais recentes)':''}</div>`+
  (l.map(u=>`<div class="card pad row wrapr" style="margin:8px 12px">${avatar(u,40)}<div style="flex:1;min-width:150px"><b>${esc(u.name)}</b> ${u.status==='blocked'?'<span class="pill">Bloqueado</span>':''}<div class="mut small">${esc(u.role==='WORKER'?(u.profession||'Trabalhador'):u.role==='COMPANY'?'Empresa':'Cliente')} · ${esc(u.email)} · ${esc(u.city||'')}${u.state?'/'+esc(u.state):''}</div>${verBadges(u)?`<div style="margin-top:4px">${verBadges(u)}</div>`:''}</div>${sup?`<button class="btn line sm" data-act="aeditu" data-id="${u.id}">Editar</button>`:''}<button class="btn line sm" data-act="ablock" data-id="${u.id}" data-b="${u.status==='blocked'?0:1}">${u.status==='blocked'?'Desbloquear':'Bloquear'}</button>${sup?`<button class="ib" data-act="adelu" data-id="${u.id}" aria-label="Excluir">${ic('trash',18)}</button>`:''}</div>`).join('')||empty('Nenhum usuário encontrado.'))}
FORMS.afilter=async(f,fd)=>{A.q=String(fd.get('q')||'').trim();A.role=String(fd.get('role')||'');A.st=String(fd.get('st')||'');A.d=null;draw();await areload()};
const roleOpts=v=>[['CLIENT','Cliente'],['WORKER','Trabalhador'],['COMPANY','Empresa']].map(([k,t])=>`<option value="${k}" ${k===v?'selected':''}>${t}</option>`).join('');
ACT.anew=()=>openModal(`<h3 style="margin-top:0">Cadastrar usuário</h3><form data-form="anewu" novalidate>${field('Tipo','role','',{type:'select',opts:roleOpts('CLIENT')})}${field('Nome','name','',{req:1,max:120})}${field('E-mail','email','',{type:'email',req:1})}${field('Senha provisória (mín. 10)','password','',{type:'password',req:1,max:100})}${field('Telefone com DDD','phone','',{type:'tel',req:1,max:20})}<div class="row"><div style="flex:2">${field('Cidade','city','',{req:1})}</div><div style="flex:1">${field('UF','state','',{type:'select',opts:ufOpts('')})}</div></div>${field('Profissão (se trabalhador)','profession','',{type:'select',opts:profOpts('')})}<button class="btn red full" type="submit">Cadastrar</button></form>`);
FORMS.anewu=async(f,fd)=>{const v=k=>String(fd.get(k)||'').trim();
  await doA(async()=>{await api('POST','/admin/users',{role:v('role'),name:v('name'),email:v('email').toLowerCase(),password:String(fd.get('password')||''),phone:digits(v('phone')),city:v('city'),state:v('state'),profession:v('profession')||undefined});closeModal()},'Usuário cadastrado.')};
ACT.aeditu=el=>{const u=A.d.items.find(x=>x.id===el.dataset.id);if(!u)return;const w=u.role==='WORKER';
  const extra=w?field('Profissão','profession','',{type:'select',opts:profOpts(u.profession)})+`<label class="chk"><input type="checkbox" name="verId" ${u.verifiedIdentity?'checked':''}><span>Identidade conferida (selo)</span></label><label class="chk"><input type="checkbox" name="verQual" ${u.verifiedQualifications?'checked':''}><span>Qualificações / documentos conferidos (selo)</span></label>`:'';
  openModal(`<h3 style="margin-top:0">Editar usuário</h3><p class="small mut">${esc(u.email)}</p><form data-form="aeditu" data-id="${u.id}" data-w="${w?1:0}" novalidate>${field('Nome','name',u.name,{req:1,max:120})}${field('Telefone','phone',u.phone||'',{type:'tel',max:20})}<div class="row"><div style="flex:2">${field('Cidade','city',u.city||'')}</div><div style="flex:1">${field('UF','state','',{type:'select',opts:ufOpts(u.state)})}</div></div>${extra}${field('Nova senha (opcional, mín. 10)','pw','',{type:'password',max:100})}<button class="btn red full" type="submit">Salvar</button></form>`)};
FORMS.aeditu=async(f,fd)=>{const v=k=>String(fd.get(k)||'').trim(),pw=String(fd.get('pw')||'');
  const b={name:v('name'),phone:digits(v('phone')),city:v('city'),state:v('state')};if(pw)b.password=pw;
  if(f.dataset.w==='1'){if(v('profession'))b.profession=v('profession');b.verifiedIdentity=!!fd.get('verId');b.verifiedQualifications=!!fd.get('verQual')}
  await doA(async()=>{await api('PATCH','/admin/users/'+f.dataset.id,b);closeModal()},'Usuário atualizado.')};
ACT.ablock=el=>doA(()=>api('POST','/admin/users/'+el.dataset.id+(el.dataset.b==='1'?'/block':'/unblock'),{}));
ACT.adelu=el=>{const u=A.d.items.find(x=>x.id===el.dataset.id);if(!u||!confirm('Excluir a conta de '+u.name+' e todo o conteúdo dela? Esta ação é definitiva.'))return;doA(()=>api('DELETE','/admin/users/'+u.id),'Conta excluída.')};
function aPosts(){return A.d.items.map(p=>`<div class="card pad row wrapr" style="margin:8px 12px">${thumb(p.thumbUrl,p.thumbKind)}<div style="flex:1;min-width:150px"><b>${esc(p.author)}</b> ${p.hidden?'<span class="pill">Oculta</span>':''} ${p.sponsored?'<span class="pill">Patrocinada</span>':''}<div class="small">${exc(p.text)}</div><div class="mut small">${ago(p.createdAt)} · ${p.likes} curtidas · ${p.comments} comentários · ${p.views||0} visualizações</div></div><button class="btn line sm" data-act="aphide" data-id="${p.id}" data-v="${p.hidden?0:1}">${p.hidden?'Mostrar':'Ocultar'}</button>${isSuper(adm())?`<button class="btn line sm" data-act="apspons" data-id="${p.id}" data-v="${p.sponsored?0:1}">${p.sponsored?'Remover destaque':'Patrocinar'}</button>`:''}<button class="ib" data-act="apdel" data-id="${p.id}" aria-label="Excluir">${ic('trash',18)}</button></div>`).join('')||empty('Nenhuma publicação.')}
ACT.aphide=el=>doA(()=>api('PATCH','/admin/posts/'+el.dataset.id,{hidden:el.dataset.v==='1'}));
ACT.apspons=el=>doA(()=>api('PATCH','/admin/posts/'+el.dataset.id,{sponsored:el.dataset.v==='1'}));
ACT.apdel=el=>{if(confirm('Excluir esta publicação definitivamente?'))doA(()=>api('DELETE','/admin/posts/'+el.dataset.id))};
function aStories(){return A.d.items.map(s=>`<div class="card pad row wrapr" style="margin:8px 12px">${thumb(s.thumbUrl,s.thumbKind)}<div style="flex:1;min-width:150px"><b>${esc(s.author)}</b> ${s.hidden?'<span class="pill">Oculto</span>':''}<div class="small">${exc(s.text)||'<span class="mut">sem texto</span>'}</div><div class="mut small">expira em ${Math.max(0,Math.round((ts(s.expiresAt)-Date.now())/36e5))} h · ${s.views} visualizações</div></div><button class="btn line sm" data-act="ashide" data-id="${s.id}" data-v="${s.hidden?0:1}">${s.hidden?'Mostrar':'Ocultar'}</button><button class="ib" data-act="asdel" data-id="${s.id}" aria-label="Excluir">${ic('trash',18)}</button></div>`).join('')||empty('Nenhum Story ativo.')}
ACT.ashide=el=>doA(()=>api('PATCH','/admin/stories/'+el.dataset.id,{hidden:el.dataset.v==='1'}));
ACT.asdel=el=>{if(confirm('Excluir este Story?'))doA(()=>api('DELETE','/admin/stories/'+el.dataset.id))};
function aCms(){return A.d.items.map(c=>`<div class="card pad row wrapr" style="margin:8px 12px"><div style="flex:1;min-width:150px"><b>${esc(c.author)}</b> ${c.hidden?'<span class="pill">Oculto</span>':''}<div class="small">${exc(c.text,200)}</div><div class="mut small">${ago(c.createdAt)}</div></div><button class="btn line sm" data-act="achide" data-id="${c.id}" data-v="${c.hidden?0:1}">${c.hidden?'Mostrar':'Ocultar'}</button><button class="ib" data-act="acdel" data-id="${c.id}" aria-label="Excluir">${ic('trash',18)}</button></div>`).join('')||empty('Nenhum comentário.')}
ACT.achide=el=>doA(()=>api('PATCH','/admin/comments/'+el.dataset.id,{hidden:el.dataset.v==='1'}));
ACT.acdel=el=>{if(confirm('Excluir este comentário?'))doA(()=>api('DELETE','/admin/comments/'+el.dataset.id))};
function aReps(){
  const chips=[['OPEN','Abertas'],['RESOLVED','Resolvidas'],['DISMISSED','Dispensadas'],['','Todas']].map(([k,l])=>`<button class="chip ${A.rst===k?'on':''}" data-act="arst" data-v="${k}">${l}</button>`).join('');
  const T={post:'Publicação',story:'Story',user:'Perfil'};
  return`<div class="chips">${chips}</div>`+(A.d.items.map(r=>{
    const what=r.live?T[r.targetType]+(r.targetType==='user'?' de ':r.ownerName?' de '+esc(r.ownerName)+': ':': ')+(r.targetType==='user'?esc(r.preview):exc(r.preview,100)):T[r.targetType]+' já removido(a)';
    const open=r.status==='OPEN';
    return`<div class="card pad col" style="margin:8px 12px"><div><span class="pill">${esc(r.reason)}</span> <span class="mut small">${ago(r.createdAt)} · por ${esc(r.reporter)} · ${open?'aberta':r.status==='RESOLVED'?'resolvida':'dispensada'}</span></div><div>${what}</div>${r.details?`<div class="small mut">“${esc(r.details)}”</div>`:''}
    ${open&&r.live?`<div class="row wrapr">${r.targetType!=='user'?`<button class="btn red sm" data-act="arep" data-v="hide" data-id="${r.id}">Ocultar conteúdo</button>`:''}<button class="btn line sm" data-act="arep" data-v="block" data-id="${r.id}">Bloquear usuário</button><button class="btn line sm" data-act="arep" data-v="resolve" data-id="${r.id}">Marcar resolvida</button><button class="btn line sm" data-act="arep" data-v="dismiss" data-id="${r.id}">Dispensar</button></div>`:open?`<div class="row"><button class="btn line sm" data-act="arep" data-v="resolve" data-id="${r.id}">Marcar resolvida</button></div>`:''}</div>`}).join('')||empty('Nenhuma denúncia neste filtro.'))}
ACT.arst=async el=>{A.rst=el.dataset.v;A.d=null;draw();await areload()};
ACT.arep=el=>doA(()=>api('POST','/admin/reports/'+el.dataset.id+'/action',{action:el.dataset.v}),'Denúncia atualizada.');
function aCats(){const sup=isSuper(adm());if(!sup)return'<div class="card pad small mut">Somente o administrador principal edita categorias.</div>';
  return`<form class="pad row" data-form="acatadd"><input class="in" name="name" maxlength="60" placeholder="Nova categoria" required><button class="btn red sm" type="submit">Adicionar</button></form>`+
  A.d.map(c=>`<div class="card pad col" style="margin:8px 12px"><div class="row wrapr"><b style="flex:1">${esc(c.name)}</b><button class="ib" data-act="acatmv" data-id="${c.id}" data-v="up" aria-label="Subir">↑</button><button class="ib" data-act="acatmv" data-id="${c.id}" data-v="down" aria-label="Descer">↓</button><button class="btn line sm" data-act="acatren" data-id="${c.id}">Renomear</button><button class="ib" data-act="acatdel" data-id="${c.id}" aria-label="Excluir">${ic('trash',18)}</button></div>
  <div class="row wrapr">${c.items.map(it=>`<span class="chip">${esc(it.name)} <a href="#" data-act="aitemdel" data-id="${it.id}" data-n="${esc(it.name)}" aria-label="Remover ${esc(it.name)}" style="color:var(--red);margin-left:4px">×</a></span>`).join('')||'<span class="mut small">Sem profissões.</span>'}</div>
  <form class="row" data-form="aitemadd" data-id="${c.id}"><input class="in" name="name" maxlength="60" placeholder="Nova profissão nesta categoria" required><button class="btn sm" type="submit">Adicionar</button></form></div>`).join('')}
FORMS.acatadd=async(f,fd)=>{const n=String(fd.get('name')||'').trim();if(n.length<2)return toast('Informe o nome da categoria.','err');await doA(()=>api('POST','/admin/categories',{name:n}))};
FORMS.aitemadd=async(f,fd)=>{const n=String(fd.get('name')||'').trim();if(n.length<2)return toast('Informe o nome.','err');await doA(()=>api('POST','/admin/categories/'+f.dataset.id+'/services',{name:n}))};
ACT.aitemdel=el=>{if(confirm('Remover "'+el.dataset.n+'"? Perfis que já usam essa profissão continuam com ela.'))doA(()=>api('DELETE','/admin/services/'+el.dataset.id))};
ACT.acatmv=el=>doA(()=>api('PATCH','/admin/categories/'+el.dataset.id,{move:el.dataset.v}));
ACT.acatren=el=>{const c=A.d.find(x=>x.id===el.dataset.id);if(!c)return;const n=(prompt('Novo nome da categoria:',c.name)||'').trim();if(n.length<2||n===c.name)return;doA(()=>api('PATCH','/admin/categories/'+c.id,{name:n}))};
ACT.acatdel=el=>{const c=A.d.find(x=>x.id===el.dataset.id);if(c&&confirm('Excluir a categoria "'+c.name+'" e suas profissões?'))doA(()=>api('DELETE','/admin/categories/'+c.id))};
function aSet(){if(!isSuper(adm()))return'<div class="card pad small mut">Somente o administrador principal altera configurações.</div>';
  return`<form class="card pad" data-form="aset" novalidate><b>Identidade e textos</b>
  ${field('Nome da plataforma','name',CFG.name||'',{req:1,max:60})}
  <div class="field"><label>Cor principal</label><input class="in" type="color" name="color" value="${esc(CFG.color||'#E10600')}" style="height:46px;padding:4px"></div>
  ${field('Termos de Uso','terms',CFG.terms||TERMS,{type:'textarea',max:20000})}${field('Política de Privacidade','privacy',CFG.privacy||PRIV,{type:'textarea',max:20000})}
  <button class="btn red full" type="submit">Salvar configurações</button></form>
  <form class="card pad" data-form="anotice" novalidate><b>Aviso administrativo a todos os usuários</b>${field('Mensagem','text','',{type:'textarea',req:1,max:300})}<button class="btn red full" type="submit">Enviar aviso</button></form>`}
FORMS.aset=async(f,fd)=>{const v=k=>String(fd.get(k)||'').trim();if(v('name').length<2)return toast('Informe o nome da plataforma.','err');
  try{await api('PUT','/admin/settings',{name:v('name'),color:v('color'),terms:v('terms'),privacy:v('privacy')});const c=await api('GET','/settings',undefined,{anon:true});CFG={...CFG,...c};applyTheme();toast('Configurações salvas.');draw()}catch(e){fail(e)}};
FORMS.anotice=async(f,fd)=>{const t=String(fd.get('text')||'').trim();if(!t)return;try{const j=await api('POST','/admin/notice',{text:t});f.reset();toast('Aviso enviado a '+j.sent+' usuário(s).')}catch(e){fail(e)}};
function aAdmins(a){
  const list=isSuper(a)?A.d.items.map(x=>`<div class="card pad row wrapr" style="margin:8px 12px"><div style="flex:1;min-width:150px"><b>${esc(x.name)}</b> <span class="pill">${x.role==='SUPER_ADMIN'?'Principal':'Moderador'}</span> ${x.active?'':'<span class="pill">Desativado</span>'}<div class="mut small">${esc(x.login)}</div></div><button class="btn line sm" data-act="aadmpw" data-id="${x.id}">Redefinir senha</button>${x.id!==a.id?`<button class="btn line sm" data-act="aadmtg" data-id="${x.id}" data-v="${x.active?0:1}">${x.active?'Desativar':'Ativar'}</button>`:''}</div>`).join('')+`<form class="card pad" data-form="aadmadd" novalidate><b>Adicionar administrador</b>${field('Nome','name','',{req:1,max:80})}${field('Login (usuário ou e-mail)','login','',{req:1,attr:'autocapitalize="none"'})}${field('Senha (mín. 10)','password','',{type:'password',req:1,max:100})}${field('Permissão','role','',{type:'select',opts:'<option value="MODERATOR">Moderador (conteúdo e denúncias)</option><option value="SUPER_ADMIN">Administrador principal (controle total)</option>'})}<button class="btn red full" type="submit">Adicionar</button></form>`:'<div class="card pad small mut">Somente o administrador principal gerencia administradores.</div>';
  return list+`<form class="card pad" data-form="aaccess" novalidate><b>Meus dados de acesso</b>${field('Nome','name',a.name,{req:1,max:80})}${field('Login (usuário ou e-mail)','login',a.login,{req:1,max:80,attr:'autocapitalize="none"'})}${field('Senha atual (obrigatória)','old','',{type:'password',req:1,max:100})}${field('Nova senha (opcional, mín. 10 caracteres)','pw','',{type:'password',max:100})}<button class="btn red full" type="submit">Salvar meus dados</button></form>`}
FORMS.aaccess=async(f,fd)=>{const v=k=>String(fd.get(k)||'').trim(),n=String(fd.get('pw')||'');
  if(!String(fd.get('old')||''))return toast('Informe a senha atual.','err');if(n&&n.length<10)return toast('A nova senha deve ter pelo menos 10 caracteres.','err');
  try{const body={oldPassword:String(fd.get('old')||''),name:v('name'),login:v('login').toLowerCase()};if(n)body.newPassword=n;
    const j=await api('PATCH','/admin/me',body);AUTH.admin=j.admin;saveAuth();toast('Dados de acesso atualizados.');await areload()}catch(e){fail(e)}};
ACT.aadmpw=el=>{const n=prompt('Nova senha para este administrador (mín. 10 caracteres):')||'';if(!n)return;if(n.length<10)return toast('A senha deve ter pelo menos 10 caracteres.','err');doA(()=>api('POST','/admin/admins/'+el.dataset.id+'/password',{password:n}),'Senha redefinida.')};
FORMS.aadmadd=async(f,fd)=>{const v=k=>String(fd.get(k)||'').trim();await doA(()=>api('POST','/admin/admins',{name:v('name'),login:v('login').toLowerCase(),password:String(fd.get('password')||''),role:v('role')}),'Administrador adicionado.')};
ACT.aadmtg=el=>doA(()=>api('PATCH','/admin/admins/'+el.dataset.id,{active:el.dataset.v==='1'}));
const AUD={CLIENT:'Clientes',WORKER:'Trabalhadores',COMPANY:'Empresas'};
function aPlans(){
  const d=A.d;
  const rows=d.items.map(p=>`<div class="card pad row wrapr" style="margin:8px 12px"><div style="flex:1;min-width:150px"><b>${esc(p.name)}</b> ${p.active?'':'<span class="pill">Desativado</span>'}<div class="mut small">${AUD[p.audience]} · ${money(p.priceCents)} por ${p.durationDays} dias</div>${p.description?`<div class="small">${esc(p.description)}</div>`:''}</div><button class="btn line sm" data-act="aplanedit" data-id="${p.id}">Editar</button><button class="btn line sm" data-act="aplantg" data-id="${p.id}" data-v="${p.active?0:1}">${p.active?'Desativar':'Ativar'}</button></div>`).join('');
  return`${d.paymentsEnabled?'':'<div class="demo">O servidor ainda não tem o token do Mercado Pago (MP_ACCESS_TOKEN). Você já pode cadastrar planos, mas ninguém consegue pagar até configurar.</div>'}<div class="pad"><button class="btn red" data-act="aplannew">+ Novo plano</button></div>${rows||empty('Nenhum plano cadastrado. Crie o primeiro (por exemplo, VIP).')}`}
const planForm=p=>`<form data-form="aplan" data-id="${p?p.id:''}" novalidate>${field('Nome do plano','name',p?p.name:'',{req:1,max:60})}${field('Descrição curta','description',p?p.description:'',{max:300})}${field('Para quem','audience','',{type:'select',opts:Object.entries(AUD).map(([k,v])=>`<option value="${k}" ${p&&p.audience===k||!p&&k==='WORKER'?'selected':''}>${v}</option>`).join('')})}${field('Preço (R$)','price',p?(p.priceCents/100).toFixed(2).replace('.',','):'',{req:1,max:12,ph:'29,90'})}${field('Duração (dias)','days',p?p.durationDays:30,{type:'number',attr:'min="1" max="3650"'})}${field('Vantagens (uma por linha)','benefits',p?(p.benefits.list||[]).join('\n'):'',{type:'textarea',max:600})}${field('Ordem na lista','sort',p?p.sortOrder:0,{type:'number'})}<button class="btn red full" type="submit">Salvar plano</button></form>`;
ACT.aplannew=()=>openModal('<h3 style="margin-top:0">Novo plano</h3>'+planForm(null));
ACT.aplanedit=el=>{const p=A.d.items.find(x=>x.id===el.dataset.id);if(p)openModal('<h3 style="margin-top:0">Editar plano</h3>'+planForm(p))};
ACT.aplantg=el=>doA(()=>api('PATCH','/admin/plans/'+el.dataset.id,{active:el.dataset.v==='1'}));
FORMS.aplan=async(f,fd)=>{const v=k=>String(fd.get(k)||'').trim(),cents=parseMoney(v('price'));
  if(!Number.isFinite(cents))return toast('Preço inválido. Use o formato 29,90.','err');
  const body={name:v('name'),description:v('description'),audience:v('audience'),priceCents:cents,durationDays:parseInt(v('days'))||30,sortOrder:parseInt(v('sort'))||0,benefits:{list:v('benefits').split('\n').map(x=>x.trim()).filter(Boolean).slice(0,12)}};
  await doA(async()=>{f.dataset.id?await api('PATCH','/admin/plans/'+f.dataset.id,body):await api('POST','/admin/plans',body);closeModal()},'Plano salvo.')};
function aAds(a){const d=A.d,sup=isSuper(a);
  const pk=d.packages.map(p=>`<div class="card pad row wrapr" style="margin:8px 12px"><div style="flex:1;min-width:150px"><b>${esc(p.name)}</b> ${p.active?'':'<span class="pill">Desativado</span>'}<div class="mut small">${money(p.priceCents)} por ${p.durationDays} dias${p.description?' · '+esc(p.description):''}</div></div>${sup?`<button class="btn line sm" data-act="apkedit" data-id="${p.id}">Editar</button><button class="btn line sm" data-act="apktg" data-id="${p.id}" data-v="${p.active?0:1}">${p.active?'Desativar':'Ativar'}</button>`:''}</div>`).join('');
  const ads=d.items.map(x=>`<div class="card pad row wrapr" style="margin:8px 12px">${thumb(x.imageUrl,'image')}<div style="flex:1;min-width:150px"><b>${esc(x.title)}</b> <span class="pill">${ADST[x.status]||x.status}</span><div class="small mut">${esc(x.owner)} · ${esc(x.packageName||'')}${x.endsAt?' · até '+new Date(x.endsAt).toLocaleDateString('pt-BR'):''}</div><div class="small mut">${x.impressions} visualizações · ${x.clicks} cliques</div></div>${x.status==='ACTIVE'?`<button class="btn line sm" data-act="adpause" data-id="${x.id}" data-v="pause">Pausar</button>`:x.status==='PAUSED'?`<button class="btn line sm" data-act="adpause" data-id="${x.id}" data-v="resume">Reativar</button>`:''}<button class="ib" data-act="adrm" data-id="${x.id}" aria-label="Remover">${ic('trash',18)}</button></div>`).join('');
  return`${d.paymentsEnabled?'':'<div class="demo">Sem MP_ACCESS_TOKEN no servidor: ninguém consegue pagar anúncio ainda.</div>'}<div class="pad row"><b style="flex:1">Pacotes de anúncio</b>${sup?'<button class="btn red sm" data-act="apknew">+ Novo pacote</button>':''}</div>${pk||empty('Nenhum pacote. Crie um para liberar a venda de anúncios.')}<div class="pad"><b>Anúncios</b></div>${ads||empty('Nenhum anúncio criado ainda.')}<p class="small mut pad">Anúncio pago entra no ar na hora. Se retirar um anúncio por violar as regras, faça o estorno manualmente no painel do Mercado Pago.</p>`}
const pkgForm=p=>`<form data-form="apkg" data-id="${p?p.id:''}" novalidate>${field('Nome do pacote','name',p?p.name:'',{req:1,max:60})}${field('Descrição curta','description',p?p.description:'',{max:300})}${field('Preço (R$)','price',p?(p.priceCents/100).toFixed(2).replace('.',','):'',{req:1,max:12,ph:'19,90'})}${field('Duração (dias)','days',p?p.durationDays:7,{type:'number',attr:'min="1" max="365"'})}<button class="btn red full" type="submit">Salvar</button></form>`;
ACT.apknew=()=>openModal('<h3 style="margin-top:0">Novo pacote de anúncio</h3>'+pkgForm(null));
ACT.apkedit=el=>{const p=A.d.packages.find(x=>x.id===el.dataset.id);if(p)openModal('<h3 style="margin-top:0">Editar pacote</h3>'+pkgForm(p))};
ACT.apktg=el=>doA(()=>api('PATCH','/admin/ad-packages/'+el.dataset.id,{active:el.dataset.v==='1'}));
FORMS.apkg=async(f,fd)=>{const v=k=>String(fd.get(k)||'').trim(),cents=parseMoney(v('price'));if(!Number.isFinite(cents))return toast('Preço inválido. Use o formato 19,90.','err');
  const body={name:v('name'),description:v('description'),priceCents:cents,durationDays:parseInt(v('days'))||7};
  await doA(async()=>{f.dataset.id?await api('PATCH','/admin/ad-packages/'+f.dataset.id,body):await api('POST','/admin/ad-packages',body);closeModal()},'Pacote salvo.')};
ACT.adpause=el=>doA(()=>api('PATCH','/admin/ads/'+el.dataset.id,{action:el.dataset.v}));
ACT.adrm=el=>{if(confirm('Remover este anúncio definitivamente?'))doA(()=>api('DELETE','/admin/ads/'+el.dataset.id))};
function aPays(){const d=A.d;
  return`<div class="grid2"><div class="card pad" style="margin:6px"><div class="mut small">Total recebido</div><div style="font-size:24px;font-weight:800">${money(d.totalPaidCents)}</div></div><div class="card pad" style="margin:6px"><div class="mut small">Pagamentos aprovados</div><div style="font-size:24px;font-weight:800">${d.paidCount}</div></div></div>`+
  (d.items.map(p=>`<div class="card pad row wrapr" style="margin:8px 12px"><div style="flex:1;min-width:150px"><b>${esc(p.user)}</b> <span class="mut small">${esc(p.email)}</span><div class="mut small">${esc(p.plan||'—')} · ${new Date(p.createdAt).toLocaleString('pt-BR')}${p.method?' · '+esc(p.method):''}</div></div><b>${money(p.amountCents)}</b><span class="pill">${PAYST[p.status]||p.status}</span></div>`).join('')||empty('Nenhum pagamento ainda.'))}
function aLogs(){return A.d.items.map(l=>`<div class="notif"><div style="flex:1"><div><b>${esc(l.admin)}</b> · ${esc(l.action)}</div>${l.target?`<div class="small mut">${esc(l.target)}</div>`:''}<div class="small mut">${new Date(l.createdAt).toLocaleString('pt-BR')}</div></div></div>`).join('')||empty('Sem atividades registradas.')}

/* ───────── roteador ───────── */
let CURRENT=null; // função que desenha a tela atual a partir do estado
function paint(){if(CURRENT){$('#app').innerHTML=CURRENT();if(!LS_OK)$('#app').insertAdjacentHTML('afterbegin','<div class="demo" style="border-color:var(--red);color:var(--txt)">Este navegador bloqueou o armazenamento: você terá de entrar de novo ao fechar.</div>')}}
async function render(){
  const my=++RT;const path=(location.hash.slice(1)||'/').split('?')[0];
  const u=me(),a=adm();
  if(path==='/admin'){
    if(!a)return go('/auth');closeModal();
    A.err=null;if(A.d===null||A.tab==='over')A.d=null;CURRENT=viewAdmin;paint();
    try{if(!A.d&&A.tab!=='set')await loadAdmin()}catch(e){if(e.status===401)return;A.err=e.message}
    if(my===RT)paint();return;
  }
  if(a&&path!=='/auth')return go('/admin');
  if(!u&&path!=='/auth')return go('/auth');
  if(u&&(path==='/'||path==='/auth'))return go('/feed');
  if(!u&&a&&path==='/auth'){AUTH=null;saveAuth()}
  closeModal();SV=null;
  if(path==='/auth'){CURRENT=viewAuth;paint();return}
  const show=(fn)=>{CURRENT=fn;paint()};
  let m;
  try{
    if(path==='/feed'){
      if(!D.feed.items.length||true){if(!D.feed.items.length)show(loading)}
      await Promise.all([loadFeed(false),api('GET','/stories').then(j=>{D.stories=j.items}),api('GET','/network').then(j=>{D.net=j.items}).catch(()=>{D.net=[]}),api('GET','/ads/feed').then(j=>{D.ads=j.items}).catch(()=>{D.ads=[]})]);if(my!==RT)return;
      show(viewFeed);afterFeed();refreshUnread();
    }else if(path==='/new'||path==='/story/new'){if(!isW(u))return go('/feed');show(path==='/new'?viewNew:viewStoryNew)}
    else if(m=path.match(/^\/post\/([^/]+)\/edit$/)){show(loading);const p=reg(await api('GET','/posts/'+m[1]));if(my!==RT)return;if(!p.mine)return go('/feed');D.post=p;show(viewPostEdit)}
    else if(m=path.match(/^\/post\/([^/]+)$/)){show(loading);const [p,c]=await Promise.all([api('GET','/posts/'+m[1]),api('GET','/posts/'+m[1]+'/comments')]);if(my!==RT)return;D.post=reg(p);S.cm[p.id]=c.items;S.openC.add(p.id);show(viewPost);afterFeed()}
    else if((m=path.match(/^\/profile\/([^/]+)$/))||path==='/me'){
      const id=m?m[1]:u.id;show(loading);
      const [pr,ps]=await Promise.all([api('GET','/users/'+id),api('GET','/users/'+id+'/posts')]);if(my!==RT)return;
      D.profile=pr;D.pposts=ps.items.map(reg);if(pr.isMe){AUTH.user={...AUTH.user,name:pr.name,city:pr.city,state:pr.state}}show(viewProfile)}
    else if(path==='/me/edit'){show(loading);const fresh=await api('GET','/me');if(my!==RT)return;AUTH.user=fresh;saveAuth();show(viewEdit)}
    else if(path==='/notifications'){show(loading);const j=await api('GET','/notifications');if(my!==RT)return;D.notifs=j.items;show(viewNotifs);if(j.unread){api('POST','/notifications/read',{}).catch(()=>{});S.unread=0}}
    else if(path==='/orders'){S.filter='orders';return go('/feed')}
    else if(path==='/orders/new'){if(isW(u))return go('/feed');show(viewOrderNew)}
    else if(path==='/search')show(viewSearch);
    else if(path==='/ads'){if(!(u.role==='WORKER'||u.role==='COMPANY'))return go('/feed');show(loading);const [pk,mn]=await Promise.all([api('GET','/ads/packages'),api('GET','/ads/mine')]);if(my!==RT)return;D.adpk=pk;D.admine=mn.items;
      const ref=(location.hash.split('?')[1]||'').match(/ref=([0-9a-f-]{36})/i);S.payMsg=null;show(viewAds);if(ref)pollPay(ref[1],my,0,true)}
    else if(path==='/settings')show(viewSettings);
    else if(path==='/plano'){show(loading);const [pl,bl]=await Promise.all([api('GET','/billing/plans'),api('GET','/billing/me')]);if(my!==RT)return;D.plans=pl;D.bill=bl;
      const ref=(location.hash.split('?')[1]||'').match(/ref=([0-9a-f-]{36})/i);S.payMsg=null;show(viewPlano);if(ref)pollPay(ref[1],my)}
    else show(()=>shell(empty('Página não encontrada.'),{back:1}));
  }catch(e){if(my!==RT||e.status===401)return;CURRENT=()=>errView(e);paint()}
}
async function refreshUnread(){if(!me())return;try{const j=await api('GET','/notifications/count');S.unread=j.unread;const b=$('[data-bell]');if(b)b.innerHTML=bellInner()}catch(e){}}
window.addEventListener('hashchange',()=>{S.openC=new Set();if(SV){clearTimeout(SV.t);SV=null}render();scrollTo(0,0)});
document.addEventListener('click',e=>{
  if(e.target.classList.contains('ov')&&!SV){closeModal();return}
  const el=e.target.closest('[data-act]');if(!el)return;
  const fn=ACT[el.dataset.act];if(!fn)return;if(el.tagName==='A'&&el.getAttribute('href')==='#')e.preventDefault();Promise.resolve(fn(el,e)).catch(fail)});
document.addEventListener('submit',async e=>{
  const f=e.target.closest('form[data-form]');if(!f)return;e.preventDefault();
  const h=FORMS[f.dataset.form];if(!h)return;const b=f.querySelector('[type=submit]');if(b)b.disabled=true;
  try{await h(f,new FormData(f))}catch(err){console.error(err);fail(err)}finally{if(b&&b.isConnected)b.disabled=false}});
document.addEventListener('keydown',e=>{if(!SV)return;if(e.key==='Escape')closeStory();if(e.key==='ArrowRight')ACT.snext();if(e.key==='ArrowLeft')ACT.sprev()});
window.addEventListener('storage',e=>{if(e.key==='bigo_auth'){AUTH=loadAuth();if(!AUTH&&location.hash!=='#/auth')location.hash='#/auth'}});
setInterval(()=>{if(me()&&!document.hidden)refreshUnread()},60e3);
(async()=>{
  $('#splashin').innerHTML=`${logo(72)}<h2 style="margin:12px 0 0">${esc(CFG.name)}</h2>`;
  await boot();
  $('#splashin').innerHTML=`${logo(72)}<h2 style="margin:12px 0 0">${esc(CFG.name)}</h2>`;
  setTimeout(()=>$('#splash')?.remove(),900);
  if(me()){try{AUTH.user=await api('GET','/me');saveAuth()}catch(e){}}
  render();
})();
})();
