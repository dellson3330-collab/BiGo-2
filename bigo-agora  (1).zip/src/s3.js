'use strict';
// Cliente S3 mínimo (AWS Signature V4), sem dependências. Funciona com Cloudflare R2, MinIO, AWS S3 etc.
const crypto = require('crypto');

const hmac = (k, d) => crypto.createHmac('sha256', k).update(d).digest();
const sha = (d) => crypto.createHash('sha256').update(d).digest('hex');
const EMPTY_SHA = sha('');
const enc = (s) => encodeURIComponent(s).replace(/[!'()*]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase());
const encPath = (p) => p.split('/').map(enc).join('/');
const signingKey = (secret, date, region) => hmac(hmac(hmac(hmac('AWS4' + secret, date), region), 's3'), 'aws4_request');
const stamp = (d) => d.toISOString().replace(/[:-]|\.\d{3}/g, '');

function canonical(method, path, query, headers, signedNames, payload) {
  const cq = Object.keys(query).sort().map((k) => enc(k) + '=' + enc(query[k])).join('&');
  const ch = signedNames.map((n) => n + ':' + String(headers[n]).trim().replace(/\s+/g, ' ') + '\n').join('');
  return { cq, text: [method, encPath(path), cq, ch, signedNames.join(';'), payload].join('\n') };
}

/** URL pré-assinada (ex.: PUT direto do navegador para o bucket). */
function presign({ method, host, path, region, accessKey, secretKey, expires = 600, now = new Date(), headers = {}, protocol = 'https' }) {
  const amz = stamp(now), date = amz.slice(0, 8), scope = date + '/' + region + '/s3/aws4_request';
  const hdrs = { host, ...headers };
  const names = Object.keys(hdrs).map((n) => n.toLowerCase()).sort();
  const lower = {}; for (const k of Object.keys(hdrs)) lower[k.toLowerCase()] = hdrs[k];
  const query = {
    'X-Amz-Algorithm': 'AWS4-HMAC-SHA256',
    'X-Amz-Credential': accessKey + '/' + scope,
    'X-Amz-Date': amz,
    'X-Amz-Expires': String(expires),
    'X-Amz-SignedHeaders': names.join(';'),
  };
  const c = canonical(method, path, query, lower, names, 'UNSIGNED-PAYLOAD');
  const sts = ['AWS4-HMAC-SHA256', amz, scope, sha(c.text)].join('\n');
  const sig = hmac(signingKey(secretKey, date, region), sts).toString('hex');
  return protocol + '://' + host + encPath(path) + '?' + c.cq + '&X-Amz-Signature=' + sig;
}

/** Cabeçalhos assinados para requisições feitas pelo servidor (HEAD, GET com Range, DELETE). */
function signHeaders({ method, host, path, region, accessKey, secretKey, extra = {}, now = new Date() }) {
  const amz = stamp(now), date = amz.slice(0, 8), scope = date + '/' + region + '/s3/aws4_request';
  const h = { host, 'x-amz-content-sha256': EMPTY_SHA, 'x-amz-date': amz };
  for (const k of Object.keys(extra)) h[k.toLowerCase()] = extra[k];
  const names = Object.keys(h).sort();
  const c = canonical(method, path, {}, h, names, EMPTY_SHA);
  const sts = ['AWS4-HMAC-SHA256', amz, scope, sha(c.text)].join('\n');
  const sig = hmac(signingKey(secretKey, date, region), sts).toString('hex');
  const out = { ...h };
  delete out.host;
  out.Authorization = 'AWS4-HMAC-SHA256 Credential=' + accessKey + '/' + scope + ', SignedHeaders=' + names.join(';') + ', Signature=' + sig;
  return out;
}

function make(s3) {
  const u = new URL(s3.endpoint);
  const location = (key) => {
    if (s3.pathStyle) return { host: u.host, path: '/' + s3.bucket + '/' + key };
    return { host: s3.bucket + '.' + u.host, path: '/' + key };
  };
  const base = { region: s3.region, accessKey: s3.accessKey, secretKey: s3.secretKey };
  return {
    presignPut(key, contentType, expires = 600) {
      const l = location(key);
      return presign({ method: 'PUT', host: l.host, path: l.path, expires, headers: { 'content-type': contentType }, protocol: u.protocol.replace(':', ''), ...base });
    },
    async request(method, key, extra = {}) {
      const l = location(key);
      const headers = signHeaders({ method, host: l.host, path: l.path, extra, ...base });
      return fetch(u.protocol + '//' + l.host + encPath(l.path), { method, headers });
    },
    async head(key) {
      const r = await this.request('HEAD', key);
      if (r.status === 404) return null;
      if (!r.ok) throw new Error('S3 HEAD ' + r.status);
      return { size: Number(r.headers.get('content-length') || 0), type: r.headers.get('content-type') || '' };
    },
    async firstBytes(key, n = 32) {
      const r = await this.request('GET', key, { range: 'bytes=0-' + (n - 1) });
      if (!r.ok && r.status !== 206) throw new Error('S3 GET ' + r.status);
      return Buffer.from(await r.arrayBuffer());
    },
    async remove(key) {
      const r = await this.request('DELETE', key);
      if (!r.ok && r.status !== 404 && r.status !== 204) throw new Error('S3 DELETE ' + r.status);
    },
    publicUrl: (key) => s3.publicUrl + '/' + key.split('/').map(enc).join('/'),
  };
}
module.exports = { presign, signHeaders, make };
