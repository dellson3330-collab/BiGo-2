'use strict';
const db = require('../db');
const { api } = require('../http');
const L = require('../lib');
const { HttpError, bad } = L;
const { cfg } = require('../config');
const MP = require('../mp');
const U = require('../users');
const { logAdmin } = require('../audit');

const planOut = (r) => ({ id: r.id, name: r.name, description: r.description || '', audience: r.audience, priceCents: r.price_cents, durationDays: r.duration_days, benefits: r.benefits || {}, active: r.active, sortOrder: r.sort_order });
const fmtDate = (d) => new Date(d).toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' });

/* ───── aplica o resultado de um pagamento consultado DIRETO na API do Mercado Pago ───── */
const MAP = { approved: 'PAID', authorized: 'PAID', rejected: 'FAILED', cancelled: 'FAILED', refunded: 'REFUNDED', charged_back: 'REFUNDED' };
async function applyMpPayment(mp) {
  const ref = mp && mp.external_reference;
  if (!L.isUuid(ref)) return 'ignorado';
  const note = await db.tx(async (q) => {
    const pay = (await q('SELECT p.*, pl.name plan_name, pl.duration_days FROM payments p LEFT JOIN plans pl ON pl.id = p.plan_id WHERE p.id=$1 FOR UPDATE OF p', [ref])).rows[0];
    if (!pay) return { out: 'desconhecido' };
    if (Math.round(Number(mp.transaction_amount) * 100) !== pay.amount_cents || (mp.currency_id && mp.currency_id !== 'BRL')) {
      console.error('[pagamento] valor divergente', ref, mp.transaction_amount, pay.amount_cents);
      return { out: 'valor divergente' };
    }
    const target = MAP[mp.status] || 'PENDING';
    const method = [mp.payment_type_id, mp.payment_method_id].filter(Boolean).join(':') || null;
    await q('UPDATE payments SET mp_payment_id=$2, mp_status=$3, method=$4 WHERE id=$1', [ref, String(mp.id), String(mp.status || ''), method]);
    if (target === 'PAID' && pay.status !== 'PAID' && pay.ad_id) {
      // anúncio pago: entra no ar na hora pelo período do pacote (o ADM pode pausar/remover depois)
      const ad = (await q('SELECT a.id, a.title, pk.duration_days FROM advertisements a LEFT JOIN ad_packages pk ON pk.id = a.package_id WHERE a.id=$1 FOR UPDATE OF a', [pay.ad_id])).rows[0];
      const days = (ad && ad.duration_days) || 7;
      if (ad) await q("UPDATE advertisements SET status='ACTIVE', active=true, starts_at=now(), ends_at=now() + ($2 || ' days')::interval WHERE id=$1 AND status <> 'PAUSED'", [ad.id, String(days)]);
      await q("UPDATE payments SET status='PAID', paid_at=now() WHERE id=$1", [ref]);
      return { out: 'pago', notify: [pay.user_id, `Pagamento confirmado! Seu anúncio "${ad ? ad.title : ''}" já está no ar por ${days} dias.`, '/ads'] };
    }
    if (target === 'REFUNDED' && pay.status === 'PAID' && pay.ad_id) {
      await q("UPDATE payments SET status='REFUNDED' WHERE id=$1", [ref]);
      await q("UPDATE advertisements SET status='PAUSED', active=false WHERE id=$1", [pay.ad_id]);
      return { out: 'estornado', notify: [pay.user_id, 'Um pagamento de anúncio foi estornado e o anúncio foi retirado do ar.', '/ads'] };
    }
    if (target === 'PAID' && pay.status !== 'PAID') {
      const days = pay.duration_days || 30;
      const cur = (await q("SELECT id, ends_at FROM subscriptions WHERE user_id=$1 AND plan_id=$2 AND status='ACTIVE' AND ends_at > now() ORDER BY ends_at DESC LIMIT 1", [pay.user_id, pay.plan_id])).rows[0];
      let subId, endsAt;
      if (cur) {
        const r = await q("UPDATE subscriptions SET ends_at = ends_at + ($2 || ' days')::interval WHERE id=$1 RETURNING id, ends_at", [cur.id, String(days)]);
        subId = r.rows[0].id; endsAt = r.rows[0].ends_at;
      } else {
        const r = await q("INSERT INTO subscriptions (user_id, plan_id, status, starts_at, ends_at) VALUES ($1,$2,'ACTIVE', now(), now() + ($3 || ' days')::interval) RETURNING id, ends_at", [pay.user_id, pay.plan_id, String(days)]);
        subId = r.rows[0].id; endsAt = r.rows[0].ends_at;
      }
      await q("UPDATE payments SET status='PAID', paid_at=now(), subscription_id=$2 WHERE id=$1", [ref, subId]);
      return { out: 'pago', notify: [pay.user_id, `Pagamento confirmado! Seu plano ${pay.plan_name || ''} está ativo até ${fmtDate(endsAt)}.`] };
    }
    if (target === 'REFUNDED' && pay.status === 'PAID') {
      await q("UPDATE payments SET status='REFUNDED' WHERE id=$1", [ref]);
      if (pay.subscription_id) await q("UPDATE subscriptions SET status='CANCELED', ends_at = LEAST(ends_at, now()) WHERE id=$1", [pay.subscription_id]);
      return { out: 'estornado', notify: [pay.user_id, 'Um pagamento foi estornado e o plano correspondente foi encerrado.'] };
    }
    if (target === 'FAILED' && pay.status === 'PENDING') { await q("UPDATE payments SET status='FAILED' WHERE id=$1", [ref]); return { out: 'recusado' }; }
    return { out: target === 'PAID' ? 'já pago' : 'pendente' };
  });
  if (note.notify) await U.notify(note.notify[0], note.notify[1], note.notify[2] || '/plano');
  return note.out;
}

/* ───── usuário ───── */
api.get('/billing/plans', async (ctx) => {
  const { rows } = await db.query('SELECT * FROM plans WHERE active AND audience=$1 AND price_cents > 0 ORDER BY sort_order, price_cents', [ctx.user.role]);
  return { enabled: MP.enabled(), items: rows.map(planOut) };
});
api.get('/billing/me', async (ctx) => {
  const s = (await db.query(
    `SELECT s.id, s.status, s.starts_at, s.ends_at, p.id plan_id, p.name, p.benefits FROM subscriptions s JOIN plans p ON p.id = s.plan_id
      WHERE s.user_id=$1 AND s.status='ACTIVE' AND s.ends_at > now() ORDER BY s.ends_at DESC LIMIT 1`, [ctx.user.id])).rows[0];
  const pays = (await db.query(
    `SELECT p.id, p.amount_cents, p.status, p.method, p.created_at, p.paid_at, pl.name plan_name FROM payments p LEFT JOIN plans pl ON pl.id = p.plan_id
      WHERE p.user_id=$1 ORDER BY p.created_at DESC LIMIT 10`, [ctx.user.id])).rows;
  return {
    vip: ctx.user.role === 'WORKER' && !!s && (await db.query('SELECT 1 FROM plans WHERE id=$1 AND audience=$2', [s.plan_id, 'WORKER'])).rows.length > 0,
    subscription: s ? { planId: s.plan_id, planName: s.name, benefits: s.benefits || {}, startsAt: s.starts_at, endsAt: s.ends_at } : null,
    payments: pays.map((p) => ({ id: p.id, amountCents: p.amount_cents, status: p.status, method: p.method, planName: p.plan_name, createdAt: p.created_at, paidAt: p.paid_at })),
  };
});

api.post('/billing/checkout', { limit: { key: 'checkout', perUser: true, max: 10, windowMs: 3600e3 } }, async (ctx) => {
  if (!MP.enabled()) throw new HttpError(503, 'Pagamentos ainda não estão ativados.');
  const planId = L.uuid(ctx.body.planId, 'Plano');
  const plan = (await db.query('SELECT * FROM plans WHERE id=$1 AND active', [planId])).rows[0];
  if (!plan || plan.audience !== ctx.user.role) throw new HttpError(404, 'Plano não disponível para o seu tipo de conta.');
  if (plan.price_cents <= 0) throw bad('Este plano é gratuito e não precisa de pagamento.');
  const pay = (await db.query(
    "INSERT INTO payments (user_id, plan_id, amount_cents, status, provider) VALUES ($1,$2,$3,'PENDING','mercadopago') RETURNING id", [ctx.user.id, plan.id, plan.price_cents])).rows[0];
  const back = (cfg.appUrl || '') + '/api/billing/return?ref=' + pay.id;
  let pref;
  try {
    pref = await MP.createPreference({ title: `${cfg.appEnv === 'demo' ? '[TESTE] ' : ''}BiGo — plano ${plan.name}`.slice(0, 120), amountCents: plan.price_cents, externalRef: pay.id, payerEmail: ctx.user.email, backBase: back });
  } catch (e) { await db.query("UPDATE payments SET status='FAILED' WHERE id=$1", [pay.id]); throw e; }
  await db.query('UPDATE payments SET provider_ref=$2 WHERE id=$1', [pay.id, String(pref.id)]);
  ctx.status = 201;
  return { paymentId: pay.id, checkoutUrl: pref.init_point };
});

/** Volta do Mercado Pago: não confia em nada que vem na URL; só leva o usuário de volta ao app. */
api.get('/billing/return', { auth: 'none' }, async (ctx) => {
  const ref = L.isUuid(ctx.query.ref) ? ctx.query.ref : '';
  ctx.sent = true;
  ctx.res.writeHead(302, { Location: '/#/' + (ctx.query.k === 'ad' ? 'ads' : 'plano') + (ref ? '?ref=' + ref : ''), 'Cache-Control': 'no-store' });
  ctx.res.end();
});

/** Situação do pagamento. Se ainda pendente, confere direto no Mercado Pago (funciona mesmo se o webhook atrasar). */
api.get('/billing/payments/:id', { limit: { key: 'paystat', perUser: true, max: 60, windowMs: 60e3 } }, async (ctx) => {
  const id = L.uuid(ctx.params.id);
  let p = (await db.query('SELECT status, amount_cents, plan_id FROM payments WHERE id=$1 AND user_id=$2', [id, ctx.user.id])).rows[0];
  if (!p) throw new HttpError(404, 'Pagamento não encontrado.');
  if (p.status === 'PENDING' && MP.enabled()) {
    try {
      const list = await MP.searchByRef(id);
      list.sort((a, b) => (b.status === 'approved') - (a.status === 'approved'));
      if (list[0]) await applyMpPayment(list[0]);
    } catch (e) { console.error('[pagamento] conferência falhou:', e.message); }
    p = (await db.query('SELECT status, amount_cents, plan_id FROM payments WHERE id=$1', [id])).rows[0];
  }
  return { status: p.status };
});

/* ───── webhook do Mercado Pago ───── */
api.post('/billing/webhook', { auth: 'none', limit: { key: 'mpwh', max: 300, windowMs: 60e3 } }, async (ctx) => {
  const q = ctx.query, b = ctx.body || {};
  const type = q.type || q.topic || b.type || b.topic;
  const dataId = q['data.id'] || q.id || (b.data && b.data.id);
  if (type !== 'payment' || !dataId) return { ok: true, ignored: true };
  if (!MP.verifySignature(ctx.req.headers, q['data.id'] || dataId)) throw new HttpError(401, 'Assinatura inválida.');
  if (!/^\d{3,20}$/.test(String(dataId))) throw bad('Identificador inválido.');
  const mp = await MP.getPayment(dataId);   // a verdade vem da API do Mercado Pago, nunca do corpo recebido
  const out = await applyMpPayment(mp);
  db.query('INSERT INTO webhook_events (provider, ref, outcome) VALUES ($1,$2,$3)', ['mercadopago', String(dataId), out]).catch(() => {});
  return { ok: true };
});

/* ───── administração ───── */
const SUPER = { auth: 'admin', role: 'SUPER_ADMIN' };
api.get('/admin/plans', SUPER, async () => {
  const { rows } = await db.query('SELECT * FROM plans ORDER BY sort_order, price_cents, name');
  return { items: rows.map(planOut), paymentsEnabled: MP.enabled() };
});
function planFields(b, partial) {
  const o = {};
  const has = (k) => b[k] !== undefined;
  if (!partial || has('name')) o.name = L.str(b.name, { min: 2, max: 60, required: true, label: 'Nome' });
  if (has('description')) o.description = L.str(b.description, { max: 300, label: 'Descrição' });
  if (!partial || has('audience')) { if (!['CLIENT', 'WORKER', 'COMPANY'].includes(b.audience)) throw bad('Público do plano inválido.'); o.audience = b.audience; }
  if (!partial || has('priceCents')) { const n = Math.round(Number(b.priceCents)); if (!(n >= 0 && n <= 10000000)) throw bad('Preço inválido.'); o.price_cents = n; }
  if (!partial || has('durationDays')) { const n = Math.round(Number(b.durationDays)); if (!(n >= 1 && n <= 3650)) throw bad('Duração deve ficar entre 1 e 3650 dias.'); o.duration_days = n; }
  if (has('benefits')) {
    let v = b.benefits; if (typeof v === 'string') { try { v = v.trim() ? JSON.parse(v) : {}; } catch (_) { throw bad('Benefícios: JSON inválido.'); } }
    if (!v || typeof v !== 'object' || Array.isArray(v) || JSON.stringify(v).length > 4000) throw bad('Benefícios devem ser um objeto JSON pequeno.');
    o.benefits = JSON.stringify(v);
  }
  if (has('active')) o.active = L.bool(b.active);
  if (has('sortOrder')) o.sort_order = Math.round(Number(b.sortOrder)) || 0;
  return o;
}
api.post('/admin/plans', SUPER, async (ctx) => {
  const o = planFields(ctx.body, false);
  const cols = Object.keys(o);
  const r = await db.query(`INSERT INTO plans (${cols.join(',')}) VALUES (${cols.map((_, i) => '$' + (i + 1) + (cols[i] === 'benefits' ? '::jsonb' : '')).join(',')}) RETURNING id`, cols.map((c) => o[c]));
  await logAdmin(ctx.admin, 'Criou plano', o.name, ctx.ip);
  ctx.status = 201;
  return { id: r.rows[0].id };
});
api.patch('/admin/plans/:id', SUPER, async (ctx) => {
  const id = L.uuid(ctx.params.id), o = planFields(ctx.body, true), cols = Object.keys(o);
  if (!cols.length) return { ok: true };
  const r = await db.query(`UPDATE plans SET ${cols.map((c, i) => c + '=$' + (i + 2) + (c === 'benefits' ? '::jsonb' : '')).join(', ')} WHERE id=$1`, [id, ...cols.map((c) => o[c])]);
  if (!r.rowCount) throw new HttpError(404, 'Plano não encontrado.');
  await logAdmin(ctx.admin, 'Alterou plano', id, ctx.ip);
  return { ok: true };
});
api.get('/admin/payments', SUPER, async () => {
  const { rows } = await db.query(
    `SELECT p.id, p.amount_cents, p.status, p.method, p.mp_status, p.created_at, p.paid_at, u.name user_name, u.email, pl.name plan_name
       FROM payments p JOIN users u ON u.id = p.user_id LEFT JOIN plans pl ON pl.id = p.plan_id ORDER BY p.created_at DESC LIMIT 200`);
  const t = (await db.query("SELECT coalesce(sum(amount_cents) FILTER (WHERE status='PAID'),0)::bigint paid, count(*) FILTER (WHERE status='PAID')::int n FROM payments")).rows[0];
  return { totalPaidCents: Number(t.paid), paidCount: t.n, items: rows.map((r) => ({ id: r.id, amountCents: r.amount_cents, status: r.status, method: r.method, mpStatus: r.mp_status, createdAt: r.created_at, paidAt: r.paid_at, user: r.user_name, email: r.email, plan: r.plan_name })) };
});

module.exports = { applyMpPayment };
