'use strict';
const db = require('../db');
const { api } = require('../http');
const L = require('../lib');
const { HttpError, bad } = L;
const { cfg } = require('../config');
const MP = require('../mp');
const { logAdmin } = require('../audit');
const { claimMedia, deleteMedia } = require('./media');
const { mediaUrl } = require('../users');

const pk = (r) => ({ id: r.id, name: r.name, description: r.description, priceCents: r.price_cents, durationDays: r.duration_days, active: r.active });
const status = (r) => (r.status === 'ACTIVE' && r.ends_at && new Date(r.ends_at) < new Date() ? 'EXPIRED' : r.status);
const out = (r) => ({
  id: r.id, title: r.title, body: r.body || '', imageUrl: mediaUrl(r.media_id), targetUrl: r.target_url || '', whatsapp: r.whatsapp || '',
  city: r.city || '', state: r.state || '', status: status(r), startsAt: r.starts_at, endsAt: r.ends_at, impressions: r.impressions, clicks: r.clicks,
  packageName: r.package_name || null, createdAt: r.created_at,
});
const AD_SQL = 'SELECT a.*, pk.name package_name FROM advertisements a LEFT JOIN ad_packages pk ON pk.id = a.package_id';
const canAdvertise = (u) => u.role === 'WORKER' || u.role === 'COMPANY';

api.get('/ads/packages', async (ctx) => {
  const { rows } = await db.query('SELECT * FROM ad_packages WHERE active ORDER BY sort_order, price_cents');
  return { enabled: MP.enabled(), items: rows.map(pk) };
});
api.get('/ads/mine', async (ctx) => {
  const { rows } = await db.query(AD_SQL + ' WHERE a.owner_id=$1 ORDER BY a.created_at DESC LIMIT 50', [ctx.user.id]);
  return { items: rows.map(out) };
});

/** Cria o anúncio (ainda fora do ar) e já devolve o link de pagamento. Sem pagar, nada aparece. */
api.post('/ads', { limit: { key: 'adnew', perUser: true, max: 10, windowMs: 3600e3 } }, async (ctx) => {
  const u = ctx.user, b = ctx.body;
  if (!canAdvertise(u)) throw new HttpError(403, 'Anúncios são para trabalhadores e empresas.');
  if (!MP.enabled()) throw new HttpError(503, 'Pagamentos ainda não estão ativados.');
  const pkg = (await db.query('SELECT * FROM ad_packages WHERE id=$1 AND active', [L.uuid(b.packageId, 'Pacote')])).rows[0];
  if (!pkg) throw new HttpError(404, 'Pacote de anúncio indisponível.');
  const title = L.str(b.title, { min: 3, max: 80, required: true, label: 'Título' });
  const body = L.str(b.body, { max: 300, label: 'Texto' });
  let target = L.str(b.targetUrl, { max: 300, label: 'Link' });
  if (target && !/^https:\/\/[^\s]+$/i.test(target)) throw bad('O link do anúncio deve começar com https://');
  const whatsapp = b.whatsapp ? L.phone(b.whatsapp, true) : '';
  if (!target && !whatsapp) throw bad('Informe um WhatsApp ou um link para o anúncio.');
  const state = L.uf(b.state || u.state);
  const city = L.str(b.city, { max: 80, label: 'Cidade' });   // vazio = todo o estado
  const ad = await db.tx(async (q) => {
    if (b.mediaId) await claimMedia(q, [b.mediaId], u.id, ['image']);
    return (await q(
      `INSERT INTO advertisements (owner_id, package_id, title, body, media_id, target_url, whatsapp, state, city, status, active)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'AWAITING_PAYMENT',false) RETURNING id`,
      [u.id, pkg.id, title, body, b.mediaId || null, target, whatsapp, state, city])).rows[0];
  });
  return startCheckout(ctx, ad.id, pkg);
});
async function startCheckout(ctx, adId, pkg) {
  const pay = (await db.query(
    "INSERT INTO payments (user_id, ad_id, amount_cents, status, provider) VALUES ($1,$2,$3,'PENDING','mercadopago') RETURNING id", [ctx.user.id, adId, pkg.price_cents])).rows[0];
  let pref;
  try {
    pref = await MP.createPreference({ title: `${cfg.appEnv === 'demo' ? '[TESTE] ' : ''}BiGo — anúncio ${pkg.name}`.slice(0, 120), amountCents: pkg.price_cents, externalRef: pay.id, payerEmail: ctx.user.email, backBase: (cfg.appUrl || '') + '/api/billing/return?k=ad&ref=' + pay.id });
  } catch (e) { await db.query("UPDATE payments SET status='FAILED' WHERE id=$1", [pay.id]); throw e; }
  await db.query('UPDATE payments SET provider_ref=$2 WHERE id=$1', [pay.id, String(pref.id)]);
  ctx.status = 201;
  return { adId, paymentId: pay.id, checkoutUrl: pref.init_point };
}
api.post('/ads/:id/checkout', { limit: { key: 'adpay', perUser: true, max: 10, windowMs: 3600e3 } }, async (ctx) => {
  if (!MP.enabled()) throw new HttpError(503, 'Pagamentos ainda não estão ativados.');
  const a = (await db.query("SELECT a.id, a.package_id FROM advertisements a WHERE a.id=$1 AND a.owner_id=$2 AND a.status='AWAITING_PAYMENT'", [L.uuid(ctx.params.id), ctx.user.id])).rows[0];
  if (!a) throw new HttpError(404, 'Anúncio não encontrado ou já pago.');
  const pkg = (await db.query('SELECT * FROM ad_packages WHERE id=$1 AND active', [a.package_id])).rows[0];
  if (!pkg) throw new HttpError(404, 'Este pacote não está mais disponível.');
  return startCheckout(ctx, a.id, pkg);
});
api.del('/ads/:id', async (ctx) => {
  const r = await db.query("DELETE FROM advertisements WHERE id=$1 AND owner_id=$2 AND (status IN ('AWAITING_PAYMENT','PAUSED') OR ends_at < now()) RETURNING media_id", [L.uuid(ctx.params.id), ctx.user.id]);
  if (!r.rowCount) throw new HttpError(409, 'Só é possível excluir anúncio não pago ou já encerrado.');
  if (r.rows[0].media_id) await deleteMedia([r.rows[0].media_id]);
  return { ok: true };
});

/* ───── no feed ───── */
async function feedAds(user) {
  const { rows } = await db.query(
    `${AD_SQL} WHERE a.status='ACTIVE' AND a.active AND a.ends_at > now() AND a.starts_at <= now()
        AND (a.state IS NULL OR a.state = $1) AND (a.city IS NULL OR a.city = '' OR lower(a.city) = lower($2)) AND a.owner_id <> $3
      ORDER BY random() LIMIT 3`, [user.state || '', user.city || '', user.id]);
  return rows.map(out);
}
api.post('/ads/views', async (ctx) => {
  const ids = (Array.isArray(ctx.body.ids) ? ctx.body.ids : []).filter(L.isUuid).slice(0, 10);
  if (ids.length) await db.query("UPDATE advertisements SET impressions = impressions + 1 WHERE id = ANY($1::uuid[]) AND status='ACTIVE'", [ids]);
  return { ok: true };
});
api.post('/ads/:id/click', { limit: { key: 'adclick', perUser: true, max: 60, windowMs: 60e3 } }, async (ctx) => {
  await db.query("UPDATE advertisements SET clicks = clicks + 1 WHERE id=$1 AND status='ACTIVE'", [L.uuid(ctx.params.id)]);
  return { ok: true };
});
api.get('/ads/feed', async (ctx) => ({ items: await feedAds(ctx.user) }));

/* ───── administração ───── */
const SUPER = { auth: 'admin', role: 'SUPER_ADMIN' };
api.get('/admin/ads', { auth: 'admin' }, async () => {
  const { rows } = await db.query(
    `SELECT a.*, pk.name package_name, u.name owner_name FROM advertisements a LEFT JOIN ad_packages pk ON pk.id = a.package_id JOIN users u ON u.id = a.owner_id ORDER BY a.created_at DESC LIMIT 200`);
  const pk2 = await db.query('SELECT * FROM ad_packages ORDER BY sort_order, price_cents');
  return { packages: pk2.rows.map(pk), items: rows.map((r) => ({ ...out(r), owner: r.owner_name })), paymentsEnabled: MP.enabled() };
});
api.patch('/admin/ads/:id', { auth: 'admin' }, async (ctx) => {
  const id = L.uuid(ctx.params.id), act = ctx.body.action;
  if (!['pause', 'resume'].includes(act)) throw bad('Ação inválida.');
  const a = (await db.query('SELECT title, status, ends_at FROM advertisements WHERE id=$1', [id])).rows[0];
  if (!a) throw new HttpError(404, 'Anúncio não encontrado.');
  if (act === 'pause') await db.query("UPDATE advertisements SET status='PAUSED', active=false WHERE id=$1", [id]);
  else {
    if (!a.ends_at || new Date(a.ends_at) < new Date()) throw bad('Este anúncio já encerrou ou nunca foi pago.');
    await db.query("UPDATE advertisements SET status='ACTIVE', active=true WHERE id=$1", [id]);
  }
  await logAdmin(ctx.admin, act === 'pause' ? 'Pausou anúncio' : 'Reativou anúncio', a.title, ctx.ip);
  return { ok: true };
});
api.del('/admin/ads/:id', { auth: 'admin' }, async (ctx) => {
  const r = await db.query('DELETE FROM advertisements WHERE id=$1 RETURNING title, media_id', [L.uuid(ctx.params.id)]);
  if (!r.rowCount) throw new HttpError(404, 'Anúncio não encontrado.');
  if (r.rows[0].media_id) await deleteMedia([r.rows[0].media_id]);
  await logAdmin(ctx.admin, 'Removeu anúncio', r.rows[0].title, ctx.ip);
  return { ok: true };
});
function pkgFields(b, partial) {
  const o = {}, has = (k) => b[k] !== undefined;
  if (!partial || has('name')) o.name = L.str(b.name, { min: 2, max: 60, required: true, label: 'Nome' });
  if (has('description')) o.description = L.str(b.description, { max: 300, label: 'Descrição' });
  if (!partial || has('priceCents')) { const n = Math.round(Number(b.priceCents)); if (!(n >= 100 && n <= 10000000)) throw bad('Preço inválido (mínimo R$ 1,00).'); o.price_cents = n; }
  if (!partial || has('durationDays')) { const n = Math.round(Number(b.durationDays)); if (!(n >= 1 && n <= 365)) throw bad('Duração deve ficar entre 1 e 365 dias.'); o.duration_days = n; }
  if (has('active')) o.active = L.bool(b.active);
  return o;
}
api.post('/admin/ad-packages', SUPER, async (ctx) => {
  const o = pkgFields(ctx.body, false), cols = Object.keys(o);
  const r = await db.query(`INSERT INTO ad_packages (${cols.join(',')}) VALUES (${cols.map((_, i) => '$' + (i + 1)).join(',')}) RETURNING id`, cols.map((c) => o[c]));
  await logAdmin(ctx.admin, 'Criou pacote de anúncio', o.name, ctx.ip);
  ctx.status = 201;
  return { id: r.rows[0].id };
});
api.patch('/admin/ad-packages/:id', SUPER, async (ctx) => {
  const id = L.uuid(ctx.params.id), o = pkgFields(ctx.body, true), cols = Object.keys(o);
  if (!cols.length) return { ok: true };
  const r = await db.query(`UPDATE ad_packages SET ${cols.map((c, i) => c + '=$' + (i + 2)).join(', ')} WHERE id=$1`, [id, ...cols.map((c) => o[c])]);
  if (!r.rowCount) throw new HttpError(404, 'Pacote não encontrado.');
  await logAdmin(ctx.admin, 'Alterou pacote de anúncio', id, ctx.ip);
  return { ok: true };
});
module.exports = { feedAds };
