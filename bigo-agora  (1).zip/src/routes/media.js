'use strict';
const fs = require('fs');
const path = require('path');
const { Transform } = require('stream');
const { pipeline } = require('stream/promises');
const crypto = require('crypto');
const { cfg } = require('../config');
const db = require('../db');
const { api } = require('../http');
const { HttpError, bad, isUuid, str } = require('../lib');
const s3lib = require('../s3');

const S3 = cfg.storage === 's3' ? s3lib.make(cfg.s3) : null;
const TYPES = {
  'image/jpeg': { kind: 'image', ext: 'jpg' }, 'image/png': { kind: 'image', ext: 'png' },
  'image/webp': { kind: 'image', ext: 'webp' }, 'image/gif': { kind: 'image', ext: 'gif' },
  'video/mp4': { kind: 'video', ext: 'mp4' }, 'video/webm': { kind: 'video', ext: 'webm' },
  'video/quicktime': { kind: 'video', ext: 'mov' },
};
const maxBytes = (kind) => (kind === 'image' ? cfg.maxImageMb : cfg.maxVideoMb) * 1048576;
const mediaUrl = (id) => (id ? '/media/' + id : null);

/** Descobre o tipo real do arquivo pelos primeiros bytes (não confia no nome nem no Content-Type). */
function sniff(b) {
  const a = (s, e) => b.toString('latin1', s, e);
  if (b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return { mime: 'image/jpeg' };
  if (b.length >= 8 && a(1, 4) === 'PNG' && b[0] === 0x89) return { mime: 'image/png' };
  if (b.length >= 12 && a(0, 4) === 'RIFF' && a(8, 12) === 'WEBP') return { mime: 'image/webp' };
  if (a(0, 6) === 'GIF87a' || a(0, 6) === 'GIF89a') return { mime: 'image/gif' };
  if (b.length >= 4 && b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3) return { mime: 'video/webm' };
  if (b.length >= 12 && a(4, 8) === 'ftyp') {
    const brand = a(8, 12);
    if (/^(heic|heix|hevc|heim|heis|mif1|msf1|avif|avis)$/.test(brand)) return { reject: 'Imagens HEIC/AVIF não são suportadas. Envie em JPG ou PNG.' };
    return { mime: brand === 'qt  ' ? 'video/quicktime' : 'video/mp4' };
  }
  return null;
}

async function removeFiles(keys) {
  for (const k of keys) {
    try {
      if (S3) await S3.remove(k);
      else await fs.promises.unlink(path.join(cfg.uploadDir, k));
    } catch (e) { if (e.code !== 'ENOENT') console.warn('[media] falha ao remover', k, e.message); }
  }
}
/** Remove linhas de mídia e arquivos. */
async function deleteMedia(ids) {
  ids = (ids || []).filter(isUuid);
  if (!ids.length) return;
  const { rows } = await db.query('DELETE FROM media WHERE id = ANY($1::uuid[]) RETURNING storage_key', [ids]);
  await removeFiles(rows.map((r) => r.storage_key));
}

/** Valida que a mídia pertence ao usuário, está pronta, livre e é do tipo esperado. */
async function claimMedia(q, ids, ownerId, kinds) {
  if (!ids.length) return [];
  for (const id of ids) if (!isUuid(id)) throw bad('Mídia inválida.');
  const { rows } = await q('SELECT id, kind, attached, ready, owner_id FROM media WHERE id = ANY($1::uuid[])', [ids]);
  if (rows.length !== new Set(ids).size) throw bad('Mídia não encontrada. Envie o arquivo novamente.');
  for (const r of rows) {
    if (r.owner_id !== ownerId) throw new HttpError(403, 'Mídia não pertence a você.');
    if (!r.ready) throw bad('Envio da mídia não foi concluído.');
    if (r.attached) throw bad('Esta mídia já está em uso.');
    if (kinds && !kinds.includes(r.kind)) throw bad('Tipo de mídia não permitido aqui.');
  }
  await q('UPDATE media SET attached = true WHERE id = ANY($1::uuid[])', [ids]);
  return rows;
}

/* ───── armazenamento local (disco) ───── */
if (!S3) {
  fs.mkdirSync(path.join(cfg.uploadDir, 'tmp'), { recursive: true });

  api.post('/media', { raw: true, limit: { key: 'upload', perUser: true, max: 30, windowMs: 3600e3 } }, async (ctx) => {
    const req = ctx.req;
    const declared = Number(req.headers['content-length'] || 0);
    if (!declared) throw new HttpError(411, 'Informe o tamanho do arquivo (Content-Length).');
    const hardMax = cfg.maxVideoMb * 1048576;
    if (declared > hardMax) throw new HttpError(413, 'Arquivo maior que ' + cfg.maxVideoMb + ' MB.');
    const id = crypto.randomUUID();
    const tmp = path.join(cfg.uploadDir, 'tmp', id);
    let size = 0, head = Buffer.alloc(0);
    const counter = new Transform({
      transform(chunk, enc, cb) {
        size += chunk.length;
        if (head.length < 32) head = Buffer.concat([head, chunk]).subarray(0, 32);
        if (size > hardMax) return cb(new HttpError(413, 'Arquivo grande demais.'));
        cb(null, chunk);
      },
    });
    try {
      await pipeline(req, counter, fs.createWriteStream(tmp));
    } catch (e) {
      fs.promises.unlink(tmp).catch(() => {});
      throw e instanceof HttpError ? e : new HttpError(400, 'Falha no envio do arquivo.');
    }
    const t = sniff(head);
    const fail = async (st, msg) => { await fs.promises.unlink(tmp).catch(() => {}); throw new HttpError(st, msg); };
    if (!t) await fail(415, 'Formato não suportado. Envie foto (JPG, PNG, WEBP) ou vídeo (MP4, WEBM, MOV).');
    if (t.reject) await fail(415, t.reject);
    const info = TYPES[t.mime];
    if (size > maxBytes(info.kind)) await fail(413, (info.kind === 'image' ? 'Imagem' : 'Vídeo') + ' maior que ' + (info.kind === 'image' ? cfg.maxImageMb : cfg.maxVideoMb) + ' MB.');
    const key = id + '.' + info.ext;
    await fs.promises.rename(tmp, path.join(cfg.uploadDir, key));
    await db.query('INSERT INTO media (id, owner_id, kind, mime, size_bytes, storage_key, ready) VALUES ($1,$2,$3,$4,$5,$6,true)', [id, ctx.user.id, info.kind, t.mime, size, key]);
    ctx.status = 201;
    return { id, kind: info.kind, url: mediaUrl(id) };
  });

  api.post('/media/presign', () => { throw bad('Este servidor usa envio direto: use POST /api/media.'); });
}

/* ───── armazenamento S3 (envio direto do navegador para o bucket) ───── */
if (S3) {
  api.post('/media', { raw: true }, () => { throw bad('Este servidor usa envio direto ao armazenamento: use POST /api/media/presign.'); });

  api.post('/media/presign', { limit: { key: 'presign', perUser: true, max: 60, windowMs: 3600e3 } }, async (ctx) => {
    const mime = str(ctx.body.mime, { required: true, max: 40, label: 'Tipo do arquivo' }).toLowerCase();
    const info = TYPES[mime];
    if (!info) throw bad('Formato não suportado. Envie foto (JPG, PNG, WEBP) ou vídeo (MP4, WEBM, MOV).');
    const size = Number(ctx.body.size);
    if (!Number.isFinite(size) || size <= 0) throw bad('Tamanho do arquivo inválido.');
    if (size > maxBytes(info.kind)) throw bad((info.kind === 'image' ? 'Imagem' : 'Vídeo') + ' maior que ' + (info.kind === 'image' ? cfg.maxImageMb : cfg.maxVideoMb) + ' MB.');
    const id = crypto.randomUUID();
    const key = 'u/' + ctx.user.id + '/' + id + '.' + info.ext;
    await db.query('INSERT INTO media (id, owner_id, kind, mime, size_bytes, storage_key, ready) VALUES ($1,$2,$3,$4,$5,$6,false)', [id, ctx.user.id, info.kind, mime, Math.round(size), key]);
    ctx.status = 201;
    return { id, kind: info.kind, uploadUrl: S3.presignPut(key, mime, 900), headers: { 'Content-Type': mime } };
  });

  api.post('/media/:id/complete', async (ctx) => {
    const id = ctx.params.id;
    if (!isUuid(id)) throw bad('Identificador inválido.');
    const { rows } = await db.query('SELECT * FROM media WHERE id=$1 AND owner_id=$2', [id, ctx.user.id]);
    const m = rows[0];
    if (!m) throw new HttpError(404, 'Mídia não encontrada.');
    if (m.ready) return { id, kind: m.kind, url: mediaUrl(id) };
    const reject = async (st, msg) => { await deleteMedia([id]); throw new HttpError(st, msg); };
    let head;
    try { head = await S3.head(m.storage_key); } catch (e) { console.error('[s3]', e.message); throw new HttpError(502, 'Não foi possível verificar o arquivo enviado.'); }
    if (!head) throw bad('O arquivo ainda não foi enviado ao armazenamento.');
    if (head.size > maxBytes(m.kind) || head.size > m.size_bytes * 1.05 + 1024) await reject(413, 'O arquivo enviado é maior que o informado.');
    let first;
    try { first = await S3.firstBytes(m.storage_key, 32); } catch (e) { throw new HttpError(502, 'Não foi possível verificar o arquivo enviado.'); }
    const t = sniff(first);
    if (!t) await reject(415, 'O conteúdo do arquivo não é uma foto ou vídeo válido.');
    if (t.reject) await reject(415, t.reject);
    if (TYPES[t.mime].kind !== m.kind) await reject(415, 'O conteúdo do arquivo não corresponde ao tipo informado.');
    await db.query('UPDATE media SET ready=true, size_bytes=$2, mime=$3 WHERE id=$1', [id, head.size, t.mime]);
    return { id, kind: m.kind, url: mediaUrl(id) };
  });
}

/* ───── leitura pública ───── */
api.get('/media/:id', { auth: 'none' }, async (ctx) => {
  const { req, res } = ctx;
  if (!isUuid(ctx.params.id)) throw new HttpError(404, 'Arquivo não encontrado.');
  const { rows } = await db.query('SELECT storage_key, mime, size_bytes FROM media WHERE id=$1 AND ready', [ctx.params.id]);
  const m = rows[0];
  if (!m) throw new HttpError(404, 'Arquivo não encontrado.');
  ctx.sent = true;
  const base = { 'X-Content-Type-Options': 'nosniff', 'Access-Control-Allow-Origin': '*', 'Cross-Origin-Resource-Policy': 'cross-origin' };
  if (S3) {
    res.writeHead(302, { ...base, Location: S3.publicUrl(m.storage_key), 'Cache-Control': 'public, max-age=86400' });
    return res.end();
  }
  const file = path.join(cfg.uploadDir, m.storage_key);
  let st;
  try { st = await fs.promises.stat(file); } catch (_) { ctx.sent = false; throw new HttpError(404, 'Arquivo não encontrado.'); }
  const headers = { ...base, 'Content-Type': m.mime, 'Accept-Ranges': 'bytes', 'Cache-Control': 'public, max-age=31536000, immutable', 'Content-Security-Policy': "default-src 'none'; sandbox" };
  let start = 0, end = st.size - 1, status = 200;
  const rg = /^bytes=(\d*)-(\d*)$/.exec(String(req.headers.range || ''));
  if (rg && (rg[1] || rg[2])) {
    if (rg[1]) { start = Number(rg[1]); if (rg[2]) end = Math.min(end, Number(rg[2])); }
    else { start = Math.max(0, st.size - Number(rg[2])); }
    if (start > end || start >= st.size) {
      res.writeHead(416, { ...base, 'Content-Range': 'bytes */' + st.size });
      return res.end();
    }
    status = 206; headers['Content-Range'] = 'bytes ' + start + '-' + end + '/' + st.size;
  }
  headers['Content-Length'] = end - start + 1;
  res.writeHead(status, headers);
  fs.createReadStream(file, { start, end }).on('error', () => res.destroy()).pipe(res);
});

module.exports = { mediaUrl, claimMedia, deleteMedia, removeFiles, S3 };
