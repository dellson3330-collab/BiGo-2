'use strict';
const db = require('../db');
const { api } = require('../http');
const L = require('../lib');
const { HttpError, bad } = L;
const U = require('../users');
const { isVip } = require('../vip');

const mine = (r) => ({
  id: r.id, title: r.title, description: r.description, profession: r.profession, city: r.city, state: r.state, bairro: r.bairro,
  address: r.address, whatsapp: r.whatsapp, status: r.status, createdAt: r.created_at, mine: true,
});

/** Cliente (ou empresa) cria uma ordem de serviço; prestadores da mesma cidade recebem notificação. */
api.post('/orders', { limit: { key: 'order', perUser: true, max: 10, windowMs: 24 * 3600e3 } }, async (ctx) => {
  const u = ctx.user, b = ctx.body;
  if (u.role === 'WORKER') throw new HttpError(403, 'Ordens de serviço são criadas por clientes e empresas.');
  const title = L.str(b.title, { min: 3, max: 100, required: true, label: 'Título' });
  const description = L.str(b.description, { max: 1500, label: 'Descrição' });
  let profession = L.str(b.profession, { max: 80, label: 'Profissão' });
  if (profession) await U.checkProfession(profession);
  const city = L.str(b.city || u.city, { min: 2, max: 80, required: true, label: 'Cidade' });
  const state = L.uf(b.state || u.state);
  const bairro = L.str(b.bairro, { max: 80, label: 'Bairro' });
  const address = L.str(b.address, { max: 200, label: 'Endereço' });
  const whatsapp = L.phone(b.whatsapp || u.phone, true);
  const r = (await db.query(
    `INSERT INTO service_orders (client_id, profession, title, description, city, state, bairro, address, whatsapp)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`, [u.id, profession, title, description, city, state, bairro, address, whatsapp])).rows[0];
  // avisa os prestadores da mesma cidade (e da profissão pedida, se houver)
  const n = await db.query(
    `INSERT INTO notifications (user_id, text, link)
     SELECT us.id, $1, '/orders' FROM users us JOIN worker_profiles wp ON wp.user_id = us.id
      WHERE us.role='WORKER' AND us.status='active' AND us.id <> $2 AND us.state = $3 AND lower(us.city) = lower($4)
        AND ($5 = '' OR wp.profession = $5)`,
    ['Nova ordem de serviço em ' + city + ': ' + title, u.id, state, city, profession]);
  ctx.status = 201;
  return { ...mine(r), notified: n.rowCount };
});

api.get('/orders', async (ctx) => {
  const u = ctx.user;
  if (u.role !== 'WORKER') {
    const { rows } = await db.query('SELECT * FROM service_orders WHERE client_id=$1 ORDER BY created_at DESC LIMIT 50', [u.id]);
    return { role: u.role, vip: false, items: rows.map(mine) };
  }
  const vip = await isVip(u.id);
  const wp = (await db.query('SELECT profession FROM worker_profiles WHERE user_id=$1', [u.id])).rows[0] || {};
  const scope = ctx.query.scope === 'state' ? 'state' : 'city';
  const { rows } = await db.query(
    `SELECT o.*, c.name client_name FROM service_orders o JOIN users c ON c.id = o.client_id AND c.status='active'
      WHERE o.status='OPEN' AND NOT o.hidden AND o.expires_at > now() AND o.state = $1 AND ($2 = 'state' OR lower(o.city) = lower($3))
        AND (o.profession = '' OR o.profession = $4)
      ORDER BY o.created_at DESC LIMIT 50`, [u.state || '', scope, u.city || '', wp.profession || '']);
  return {
    role: 'WORKER', vip,
    items: rows.map((r) => ({
      id: r.id, title: r.title, description: r.description, profession: r.profession, city: r.city, state: r.state, bairro: r.bairro,
      createdAt: r.created_at, client: { name: r.client_name.split(' ')[0] },
      // endereço e WhatsApp do cliente: somente para prestador VIP
      contact: vip ? { address: r.address, whatsapp: r.whatsapp } : null,
    })),
  };
});

api.post('/orders/:id/close', async (ctx) => {
  const r = await db.query("UPDATE service_orders SET status='CLOSED' WHERE id=$1 AND client_id=$2", [L.uuid(ctx.params.id), ctx.user.id]);
  if (!r.rowCount) throw new HttpError(404, 'Ordem não encontrada.');
  return { ok: true };
});
api.del('/orders/:id', async (ctx) => {
  const r = await db.query('DELETE FROM service_orders WHERE id=$1 AND client_id=$2', [L.uuid(ctx.params.id), ctx.user.id]);
  if (!r.rowCount) throw new HttpError(404, 'Ordem não encontrada.');
  return { ok: true };
});

/* ───── busca de contas/profissionais e rede de profissionais ───── */
const like = (s) => '%' + String(s).replace(/[\\%_]/g, (c) => '\\' + c) + '%';
const card = (r) => ({
  id: r.id, name: r.name, role: r.role, profession: r.profession || null, city: r.city || '', state: r.state || '',
  avatarUrl: U.mediaUrl(r.avatar_media), verified: !!(r.ver_identity || r.ver_qualifications), following: !!r.following,
});
const CARD_SQL = `SELECT u.id, u.name, u.role, u.city, u.state, u.avatar_media, wp.profession, wp.ver_identity, wp.ver_qualifications,
  EXISTS(SELECT 1 FROM follows f WHERE f.follower_id = $1 AND f.following_id = u.id) following
  FROM users u LEFT JOIN worker_profiles wp ON wp.user_id = u.id`;

api.get('/search', { limit: { key: 'search', perUser: true, max: 60, windowMs: 60e3 } }, async (ctx) => {
  const q = String(ctx.query.q || '').trim().slice(0, 60);
  if (q.length < 2) return { items: [] };
  const type = ctx.query.type === 'workers' ? "AND u.role='WORKER'" : '';
  const { rows } = await db.query(
    `${CARD_SQL} WHERE u.status='active' AND u.id <> $1 ${type}
        AND (u.name ILIKE $2 OR wp.profession ILIKE $2 OR wp.specialties ILIKE $2 OR u.city ILIKE $2)
      ORDER BY (u.name ILIKE $3) DESC, (wp.profession ILIKE $3) DESC, (lower(u.city) = lower($4)) DESC, u.name LIMIT 30`,
    [ctx.user.id, like(q), q + '%', ctx.user.city || '']);
  return { items: rows.map(card) };
});

api.get('/network', async (ctx) => {
  const u = ctx.user;
  const { rows } = await db.query(
    `${CARD_SQL} WHERE u.status='active' AND u.role='WORKER' AND u.id <> $1
        AND NOT EXISTS (SELECT 1 FROM follows f WHERE f.follower_id = $1 AND f.following_id = u.id)
      ORDER BY (lower(u.city) = lower($2) AND u.state = $3) DESC, (u.state = $3) DESC, random() LIMIT 12`,
    [u.id, u.city || '', u.state || '']);
  return { items: rows.map(card) };
});
