'use strict';
const db = require('../db');
const { api } = require('../http');
const L = require('../lib');
const { HttpError, bad } = L;
const U = require('../users');
const { logAdmin } = require('../audit');
const { claimMedia, deleteMedia } = require('./media');

const mod = (m, p, opts, h) => api[m]('/admin' + p, { auth: 'admin', ...(typeof opts === 'function' ? {} : opts) }, typeof opts === 'function' ? opts : h);
const SUPER = { role: 'SUPER_ADMIN' };
const like = (s) => '%' + String(s).replace(/[\\%_]/g, (c) => '\\' + c) + '%';
const log = (ctx, action, target) => logAdmin(ctx.admin, action, target, ctx.ip);
const pg = (q) => { const limit = 100; return { limit, offset: Math.max(0, parseInt(q.page, 10) || 0) * limit }; };

mod('get', '/me', async (ctx) => ({ admin: { id: ctx.admin.id, login: ctx.admin.login, name: ctx.admin.name, role: ctx.admin.role, mustChangePassword: ctx.admin.must_change_password } }));

mod('get', '/overview', async () => {
  const c = (await db.query(
    `SELECT (SELECT count(*) FROM users)::int users,
            (SELECT count(*) FROM users WHERE role='CLIENT')::int clients,
            (SELECT count(*) FROM users WHERE role='WORKER')::int workers,
            (SELECT count(*) FROM users WHERE role='COMPANY')::int companies,
            (SELECT count(*) FROM posts)::int posts,
            (SELECT count(*) FROM stories WHERE expires_at > now())::int stories,
            (SELECT count(*) FROM comments)::int comments,
            (SELECT count(*) FROM reports WHERE status='OPEN')::int open_reports,
            (SELECT count(*) FROM users WHERE last_seen > now() - interval '7 days')::int active7,
            (SELECT count(*) FROM users WHERE status='blocked')::int blocked`)).rows[0];
  const g = await db.query(
    `SELECT d::date AS day, count(u.id)::int n
       FROM generate_series(current_date - 13, current_date, interval '1 day') d
       LEFT JOIN users u ON u.created_at::date = d::date GROUP BY d ORDER BY d`);
  return {
    totals: { users: c.users, clients: c.clients, workers: c.workers, companies: c.companies, posts: c.posts, stories: c.stories, comments: c.comments, openReports: c.open_reports, active7: c.active7, blocked: c.blocked },
    growth: g.rows.map((r) => ({ day: r.day, n: r.n })),
  };
});

/* ───── usuários ───── */
function userRow(r) {
  return { id: r.id, email: r.email, role: r.role, status: r.status, name: r.name, phone: r.phone || '', city: r.city || '', state: r.state || '',
    createdAt: r.created_at, lastSeen: r.last_seen, avatarUrl: U.mediaUrl(r.avatar_media), profession: r.profession || null,
    verifiedIdentity: !!r.ver_identity, verifiedQualifications: !!r.ver_qualifications };
}
const USER_SQL = `SELECT u.id, u.email, u.role, u.status, u.name, u.phone, u.city, u.state, u.created_at, u.last_seen, u.avatar_media,
  wp.profession, wp.ver_identity, wp.ver_qualifications FROM users u LEFT JOIN worker_profiles wp ON wp.user_id = u.id`;
mod('get', '/users/export', SUPER, async (ctx) => {
  const { rows } = await db.query(USER_SQL + ' ORDER BY u.created_at DESC');
  const q = (v) => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';
  const head = ['Nome', 'E-mail', 'Tipo', 'Cidade', 'UF', 'Situação', 'Cadastro'];
  const lines = rows.map((r) => [r.name, r.email, r.role, r.city, r.state, r.status, new Date(r.created_at).toLocaleDateString('pt-BR')].map(q).join(';'));
  await log(ctx, 'Exportou usuários (CSV)');
  return { csv: '﻿' + [head.map(q).join(';'), ...lines].join('\r\n') };
});
mod('get', '/users', async (ctx) => {
  const { q, role, status } = ctx.query, where = [], params = [];
  if (q) { params.push(like(q)); where.push(`(u.name ILIKE $${params.length} OR u.email ILIKE $${params.length} OR u.city ILIKE $${params.length})`); }
  if (['CLIENT', 'WORKER', 'COMPANY'].includes(role)) { params.push(role); where.push('u.role = $' + params.length); }
  if (['active', 'blocked'].includes(status)) { params.push(status); where.push('u.status = $' + params.length); }
  const { limit, offset } = pg(ctx.query);
  params.push(limit, offset);
  const { rows } = await db.query(USER_SQL + (where.length ? ' WHERE ' + where.join(' AND ') : '') + ` ORDER BY u.created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`, params);
  return { items: rows.map(userRow) };
});
mod('post', '/users', SUPER, async (ctx) => {
  const b = ctx.body, role = ['CLIENT', 'WORKER', 'COMPANY'].includes(b.role) ? b.role : null;
  if (!role) throw bad('Tipo de usuário inválido.');
  const d = {
    role, email: L.email(b.email), password: L.password(b.password),
    name: L.str(b.name, { min: 2, max: 120, required: true, label: 'Nome' }), phone: L.phone(b.phone),
    city: L.str(b.city, { min: 2, max: 80, required: true, label: 'Cidade' }), state: L.uf(b.state),
    profession: role === 'WORKER' ? L.str(b.profession, { required: true, max: 80, label: 'Profissão' }) : null,
    consentVer: 'cadastro-administrativo',
  };
  if (role === 'WORKER') await U.checkProfession(d.profession);
  const taken = await db.query('SELECT 1 FROM users WHERE email=$1 UNION ALL SELECT 1 FROM admin_users WHERE login=$1', [d.email]);
  if (taken.rows.length) throw new HttpError(409, 'Este e-mail já está cadastrado.');
  const id = await U.createUser(d);
  await log(ctx, 'Cadastrou usuário', d.email);
  ctx.status = 201;
  return { id };
});
mod('patch', '/users/:id', SUPER, async (ctx) => {
  const id = L.uuid(ctx.params.id), b = ctx.body;
  const cur = (await db.query('SELECT u.email, u.role, wp.ver_identity, wp.ver_qualifications FROM users u LEFT JOIN worker_profiles wp ON wp.user_id=u.id WHERE u.id=$1', [id])).rows[0];
  if (!cur) throw new HttpError(404, 'Usuário não encontrado.');
  const sets = [], vals = [id];
  const set = (c, v) => { vals.push(v); sets.push(c + '=$' + vals.length); };
  if (b.name !== undefined) set('name', L.str(b.name, { min: 2, max: 120, required: true, label: 'Nome' }));
  if (b.phone !== undefined) set('phone', L.phone(b.phone));
  if (b.city !== undefined) set('city', L.str(b.city, { min: 2, max: 80, required: true, label: 'Cidade' }));
  if (b.state !== undefined) set('state', L.uf(b.state));
  const wsets = [], wvals = [id];
  const wset = (c, v) => { wvals.push(v); wsets.push(c + '=$' + wvals.length); };
  if (cur.role === 'WORKER') {
    if (b.profession !== undefined) { const p = L.str(b.profession, { required: true, max: 80, label: 'Profissão' }); await U.checkProfession(p); wset('profession', p); }
    if (b.verifiedIdentity !== undefined) wset('ver_identity', L.bool(b.verifiedIdentity));
    if (b.verifiedQualifications !== undefined) wset('ver_qualifications', L.bool(b.verifiedQualifications));
  }
  if (b.password) set('password_hash', await L.hashPassword(L.password(b.password)));
  if (sets.length) await db.query('UPDATE users SET ' + sets.join(', ') + ' WHERE id=$1', vals);
  if (wsets.length) await db.query('UPDATE worker_profiles SET ' + wsets.join(', ') + ' WHERE user_id=$1', wvals);
  if (b.password) await db.query('UPDATE refresh_tokens SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL', [id]);
  const gained = (b.verifiedIdentity === true && !cur.ver_identity) || (b.verifiedQualifications === true && !cur.ver_qualifications);
  if (gained) await U.notify(id, 'Seu perfil recebeu selo de verificação da administração.', '/me');
  await log(ctx, 'Editou usuário' + (b.password ? ' (senha redefinida)' : ''), cur.email);
  return { ok: true };
});
for (const [path, status, action] of [['block', 'blocked', 'Bloqueou usuário'], ['unblock', 'active', 'Desbloqueou usuário']]) {
  mod('post', '/users/:id/' + path, async (ctx) => {
    const id = L.uuid(ctx.params.id);
    const r = await db.query('UPDATE users SET status=$2 WHERE id=$1 RETURNING email', [id, status]);
    if (!r.rowCount) throw new HttpError(404, 'Usuário não encontrado.');
    if (status === 'blocked') await db.query('UPDATE refresh_tokens SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL', [id]);
    await log(ctx, action, r.rows[0].email);
    return { ok: true };
  });
}
mod('del', '/users/:id', SUPER, async (ctx) => {
  const id = L.uuid(ctx.params.id);
  const u = (await db.query('SELECT email FROM users WHERE id=$1', [id])).rows[0];
  if (!u) throw new HttpError(404, 'Usuário não encontrado.');
  await U.wipeUser(id);
  await log(ctx, 'Excluiu conta de usuário', u.email);
  return { ok: true };
});

/* ───── moderação de conteúdo ───── */
mod('get', '/posts', async (ctx) => {
  const { limit, offset } = pg(ctx.query);
  const { rows } = await db.query(
    `SELECT p.id, p.text, p.hidden, p.sponsored, p.views, p.created_at, u.name author_name,
            (SELECT media_id FROM post_media pm WHERE pm.post_id = p.id ORDER BY position LIMIT 1) first_media,
            (SELECT kind FROM media m JOIN post_media pm ON pm.media_id = m.id WHERE pm.post_id = p.id ORDER BY pm.position LIMIT 1) first_kind,
            (SELECT count(*) FROM likes l WHERE l.post_id = p.id)::int likes,
            (SELECT count(*) FROM comments c WHERE c.post_id = p.id)::int comments
       FROM posts p JOIN users u ON u.id = p.author_id ORDER BY p.created_at DESC LIMIT $1 OFFSET $2`, [limit, offset]);
  return { items: rows.map((r) => ({ id: r.id, text: r.text, hidden: r.hidden, sponsored: r.sponsored, views: r.views, createdAt: r.created_at, author: r.author_name, thumbUrl: U.mediaUrl(r.first_media), thumbKind: r.first_kind, likes: r.likes, comments: r.comments })) };
});
mod('patch', '/posts/:id', async (ctx) => {
  const id = L.uuid(ctx.params.id), b = ctx.body;
  if (b.sponsored !== undefined && ctx.admin.role !== 'SUPER_ADMIN') throw new HttpError(403, 'Sem permissão para patrocinar publicações.');
  const cur = (await db.query('SELECT author_id, hidden, sponsored FROM posts WHERE id=$1', [id])).rows[0];
  if (!cur) throw new HttpError(404, 'Publicação não encontrada.');
  const hidden = b.hidden === undefined ? cur.hidden : L.bool(b.hidden);
  const sponsored = b.sponsored === undefined ? cur.sponsored : L.bool(b.sponsored);
  await db.query('UPDATE posts SET hidden=$2, sponsored=$3 WHERE id=$1', [id, hidden, sponsored]);
  if (hidden && !cur.hidden) await U.notify(cur.author_id, 'Uma publicação sua foi ocultada pela moderação.');
  if (hidden !== cur.hidden) await log(ctx, hidden ? 'Ocultou publicação' : 'Reexibiu publicação', id);
  if (sponsored !== cur.sponsored) await log(ctx, sponsored ? 'Marcou publicação como patrocinada' : 'Removeu patrocínio', id);
  return { ok: true };
});
mod('del', '/posts/:id', async (ctx) => {
  const id = L.uuid(ctx.params.id);
  const m = await db.query('SELECT media_id FROM post_media WHERE post_id=$1', [id]);
  const r = await db.query('DELETE FROM posts WHERE id=$1', [id]);
  if (!r.rowCount) throw new HttpError(404, 'Publicação não encontrada.');
  await deleteMedia(m.rows.map((x) => x.media_id));
  await log(ctx, 'Excluiu publicação', id);
  return { ok: true };
});

mod('get', '/stories', async () => {
  const { rows } = await db.query(
    `SELECT s.id, s.text, s.hidden, s.created_at, s.expires_at, s.media_id, md.kind, u.name author_name,
            (SELECT count(*) FROM story_views v WHERE v.story_id = s.id)::int views
       FROM stories s JOIN users u ON u.id = s.author_id JOIN media md ON md.id = s.media_id
      WHERE s.expires_at > now() ORDER BY s.created_at DESC LIMIT 200`);
  return { items: rows.map((r) => ({ id: r.id, text: r.text, hidden: r.hidden, createdAt: r.created_at, expiresAt: r.expires_at, thumbUrl: U.mediaUrl(r.media_id), thumbKind: r.kind, author: r.author_name, views: r.views })) };
});
mod('patch', '/stories/:id', async (ctx) => {
  const id = L.uuid(ctx.params.id), hidden = L.bool(ctx.body.hidden);
  const r = await db.query('UPDATE stories SET hidden=$2 WHERE id=$1', [id, hidden]);
  if (!r.rowCount) throw new HttpError(404, 'Story não encontrado.');
  await log(ctx, hidden ? 'Ocultou Story' : 'Reexibiu Story', id);
  return { ok: true };
});
mod('del', '/stories/:id', async (ctx) => {
  const id = L.uuid(ctx.params.id);
  const r = await db.query('DELETE FROM stories WHERE id=$1 RETURNING media_id', [id]);
  if (!r.rowCount) throw new HttpError(404, 'Story não encontrado.');
  await deleteMedia([r.rows[0].media_id]);
  await log(ctx, 'Excluiu Story', id);
  return { ok: true };
});

mod('get', '/comments', async (ctx) => {
  const { limit, offset } = pg(ctx.query);
  const { rows } = await db.query(
    `SELECT c.id, c.body, c.hidden, c.created_at, u.name FROM comments c JOIN users u ON u.id = c.author_id ORDER BY c.created_at DESC LIMIT $1 OFFSET $2`, [limit, offset]);
  return { items: rows.map((r) => ({ id: r.id, text: r.body, hidden: r.hidden, createdAt: r.created_at, author: r.name })) };
});
mod('patch', '/comments/:id', async (ctx) => {
  const id = L.uuid(ctx.params.id), hidden = L.bool(ctx.body.hidden);
  const r = await db.query('UPDATE comments SET hidden=$2 WHERE id=$1', [id, hidden]);
  if (!r.rowCount) throw new HttpError(404, 'Comentário não encontrado.');
  await log(ctx, hidden ? 'Ocultou comentário' : 'Reexibiu comentário', id);
  return { ok: true };
});
mod('del', '/comments/:id', async (ctx) => {
  const id = L.uuid(ctx.params.id);
  const r = await db.query('DELETE FROM comments WHERE id=$1', [id]);
  if (!r.rowCount) throw new HttpError(404, 'Comentário não encontrado.');
  await log(ctx, 'Excluiu comentário', id);
  return { ok: true };
});

/* ───── denúncias ───── */
mod('get', '/reports', async (ctx) => {
  const st = ['OPEN', 'RESOLVED', 'DISMISSED'].includes(ctx.query.status) ? ctx.query.status : null;
  const { rows } = await db.query(
    `SELECT r.id, r.target_type, r.target_id, r.reason, r.details, r.status, r.created_at, ru.name reporter,
            CASE r.target_type WHEN 'post' THEN (SELECT left(p.text, 100) FROM posts p WHERE p.id = r.target_id)
                               WHEN 'user' THEN (SELECT name FROM users x WHERE x.id = r.target_id)
                               WHEN 'story' THEN (SELECT coalesce(nullif(s.text, ''), 'Story') FROM stories s WHERE s.id = r.target_id) END preview,
            CASE r.target_type WHEN 'post' THEN (SELECT u.name FROM posts p JOIN users u ON u.id = p.author_id WHERE p.id = r.target_id)
                               WHEN 'story' THEN (SELECT u.name FROM stories s JOIN users u ON u.id = s.author_id WHERE s.id = r.target_id) END owner_name
       FROM reports r JOIN users ru ON ru.id = r.reporter_id WHERE ($1::text IS NULL OR r.status = $1) ORDER BY r.created_at DESC LIMIT 200`, [st]);
  return { items: rows.map((r) => ({ id: r.id, targetType: r.target_type, targetId: r.target_id, reason: r.reason, details: r.details, status: r.status, createdAt: r.created_at, reporter: r.reporter, preview: r.preview, ownerName: r.owner_name, live: r.preview !== null })) };
});
mod('post', '/reports/:id/action', async (ctx) => {
  const id = L.uuid(ctx.params.id), action = ctx.body.action;
  if (!['hide', 'block', 'resolve', 'dismiss'].includes(action)) throw bad('Ação inválida.');
  const r = (await db.query('SELECT * FROM reports WHERE id=$1', [id])).rows[0];
  if (!r) throw new HttpError(404, 'Denúncia não encontrada.');
  let owner = null;
  if (r.target_type === 'user') owner = r.target_id;
  else if (r.target_type === 'post') owner = ((await db.query('SELECT author_id FROM posts WHERE id=$1', [r.target_id])).rows[0] || {}).author_id;
  else if (r.target_type === 'story') owner = ((await db.query('SELECT author_id FROM stories WHERE id=$1', [r.target_id])).rows[0] || {}).author_id;
  if (action === 'hide') {
    if (r.target_type === 'user') throw bad('Para perfis, use bloquear usuário.');
    const t = r.target_type === 'post' ? 'posts' : 'stories';
    const u = await db.query('UPDATE ' + t + ' SET hidden = true WHERE id=$1', [r.target_id]);
    if (u.rowCount && owner) await U.notify(owner, 'Um conteúdo seu foi ocultado pela moderação após denúncia.');
  }
  if (action === 'block' && owner) {
    await db.query("UPDATE users SET status='blocked' WHERE id=$1", [owner]);
    await db.query('UPDATE refresh_tokens SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL', [owner]);
  }
  await db.query('UPDATE reports SET status=$2, resolved_at=now() WHERE id=$1', [id, action === 'dismiss' ? 'DISMISSED' : 'RESOLVED']);
  await log(ctx, 'Denúncia: ' + { hide: 'conteúdo ocultado', block: 'usuário bloqueado', resolve: 'resolvida', dismiss: 'dispensada' }[action], r.target_type + ':' + r.target_id);
  return { ok: true };
});

/* ───── categorias e profissões ───── */
mod('post', '/categories', SUPER, async (ctx) => {
  const name = L.str(ctx.body.name, { min: 2, max: 60, required: true, label: 'Nome' });
  const r = await db.query('INSERT INTO categories (name, sort_order) VALUES ($1, coalesce((SELECT max(sort_order) + 1 FROM categories), 0)) RETURNING id', [name]);
  await log(ctx, 'Criou categoria', name);
  ctx.status = 201;
  return { id: r.rows[0].id };
});
mod('patch', '/categories/:id', SUPER, async (ctx) => {
  const id = L.uuid(ctx.params.id), b = ctx.body;
  if (b.name !== undefined) {
    const name = L.str(b.name, { min: 2, max: 60, required: true, label: 'Nome' });
    const r = await db.query('UPDATE categories SET name=$2 WHERE id=$1', [id, name]);
    if (!r.rowCount) throw new HttpError(404, 'Categoria não encontrada.');
    await log(ctx, 'Renomeou categoria', name);
  }
  if (b.move === 'up' || b.move === 'down') {
    await db.tx(async (q) => {
      const { rows } = await q('SELECT id FROM categories ORDER BY sort_order, name');
      const i = rows.findIndex((x) => x.id === id), j = i + (b.move === 'up' ? -1 : 1);
      if (i < 0 || j < 0 || j >= rows.length) return;
      [rows[i], rows[j]] = [rows[j], rows[i]];
      for (let k = 0; k < rows.length; k++) await q('UPDATE categories SET sort_order=$2 WHERE id=$1', [rows[k].id, k]);
    });
    await log(ctx, 'Reordenou categorias');
  }
  return { ok: true };
});
mod('del', '/categories/:id', SUPER, async (ctx) => {
  const id = L.uuid(ctx.params.id);
  const r = await db.query('DELETE FROM categories WHERE id=$1 RETURNING name', [id]);
  if (!r.rowCount) throw new HttpError(404, 'Categoria não encontrada.');
  await log(ctx, 'Excluiu categoria', r.rows[0].name);
  return { ok: true };
});
mod('post', '/categories/:id/services', SUPER, async (ctx) => {
  const id = L.uuid(ctx.params.id);
  const name = L.str(ctx.body.name, { min: 2, max: 60, required: true, label: 'Nome' });
  const c = await db.query('SELECT name FROM categories WHERE id=$1', [id]);
  if (!c.rows.length) throw new HttpError(404, 'Categoria não encontrada.');
  const dup = await db.query('SELECT 1 FROM services WHERE lower(name)=lower($1)', [name]);
  if (dup.rows.length) throw new HttpError(409, 'Esta profissão já existe.');
  const r = await db.query('INSERT INTO services (category_id, name, sort_order) VALUES ($1,$2, coalesce((SELECT max(sort_order) + 1 FROM services WHERE category_id=$1), 0)) RETURNING id', [id, name]);
  await log(ctx, 'Adicionou profissão em ' + c.rows[0].name, name);
  ctx.status = 201;
  return { id: r.rows[0].id };
});
mod('del', '/services/:id', SUPER, async (ctx) => {
  const id = L.uuid(ctx.params.id);
  const r = await db.query('DELETE FROM services WHERE id=$1 RETURNING name', [id]);
  if (!r.rowCount) throw new HttpError(404, 'Profissão não encontrada.');
  await log(ctx, 'Removeu profissão', r.rows[0].name);
  return { ok: true };
});

/* ───── configurações da plataforma ───── */
const setKV = (k, v) => db.query('INSERT INTO settings (key, value) VALUES ($1,$2::jsonb) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value', [k, JSON.stringify(v)]);
mod('put', '/settings', { ...SUPER, maxBody: 128 * 1024 }, async (ctx) => {
  const b = ctx.body;
  if (b.name !== undefined) await setKV('name', L.str(b.name, { min: 2, max: 60, required: true, label: 'Nome' }));
  if (b.color !== undefined) { if (!/^#[0-9a-f]{6}$/i.test(b.color)) throw bad('Cor inválida. Use o formato #RRGGBB.'); await setKV('color', b.color); }
  if (b.terms !== undefined) await setKV('terms', L.str(b.terms, { max: 20000, label: 'Termos de Uso' }));
  if (b.privacy !== undefined) await setKV('privacy', L.str(b.privacy, { max: 20000, label: 'Política de Privacidade' }));
  if (b.logoMediaId !== undefined) {
    const old = (await db.query("SELECT value FROM settings WHERE key='logoMedia'")).rows[0];
    if (b.logoMediaId === null) await db.query("DELETE FROM settings WHERE key='logoMedia'");
    else { await claimMedia(db.query, [b.logoMediaId], ctx.admin.id, ['image']); await setKV('logoMedia', b.logoMediaId); }
    if (old && old.value !== b.logoMediaId) await deleteMedia([old.value]);
  }
  await log(ctx, 'Alterou configurações da plataforma');
  return { ok: true };
});
mod('post', '/notice', SUPER, async (ctx) => {
  const text = L.str(ctx.body.text, { required: true, max: 300, label: 'Mensagem' });
  const r = await db.query("INSERT INTO notifications (user_id, text, link) SELECT id, $1, '/feed' FROM users WHERE status='active'", ['Aviso: ' + text]);
  await log(ctx, 'Enviou aviso administrativo', text.slice(0, 60));
  return { sent: r.rowCount };
});

/* ───── administradores e registro de atividades ───── */
const adminRow = (r) => ({ id: r.id, login: r.login, name: r.name, role: r.role, active: r.active, mustChangePassword: r.must_change_password, createdAt: r.created_at });
mod('get', '/admins', SUPER, async () => {
  const { rows } = await db.query('SELECT id, login, name, role, active, must_change_password, created_at FROM admin_users ORDER BY created_at');
  return { items: rows.map(adminRow) };
});
async function loginFree(login, exceptAdmin) {
  const a = await db.query('SELECT 1 FROM admin_users WHERE login=$1 AND ($2::uuid IS NULL OR id <> $2)', [login, exceptAdmin || null]);
  const u = await db.query('SELECT 1 FROM users WHERE email=$1', [login]);
  return !a.rows.length && !u.rows.length;
}
const adminLogin = (v) => {
  const s = L.str(v, { min: 3, max: 80, required: true, label: 'Login' }).toLowerCase();
  if (/\s/.test(s)) throw bad('Login inválido: sem espaços.');
  return s;
};
mod('post', '/admins', SUPER, async (ctx) => {
  const b = ctx.body, login = adminLogin(b.login), name = L.str(b.name, { min: 2, max: 80, required: true, label: 'Nome' });
  const role = b.role === 'SUPER_ADMIN' ? 'SUPER_ADMIN' : 'MODERATOR';
  const hash = await L.hashPassword(L.password(b.password));
  if (!(await loginFree(login))) throw new HttpError(409, 'Este login já está em uso.');
  const r = await db.query('INSERT INTO admin_users (login, name, password_hash, role) VALUES ($1,$2,$3,$4) RETURNING id', [login, name, hash, role]);
  await log(ctx, 'Adicionou administrador', login);
  ctx.status = 201;
  return { id: r.rows[0].id };
});
mod('patch', '/admins/:id', SUPER, async (ctx) => {
  const id = L.uuid(ctx.params.id), active = L.bool(ctx.body.active);
  if (id === ctx.admin.id) throw bad('Você não pode desativar o próprio acesso.');
  const t = (await db.query('SELECT login, role, active FROM admin_users WHERE id=$1', [id])).rows[0];
  if (!t) throw new HttpError(404, 'Administrador não encontrado.');
  if (!active && t.role === 'SUPER_ADMIN') {
    const n = (await db.query("SELECT count(*)::int n FROM admin_users WHERE role='SUPER_ADMIN' AND active AND id <> $1", [id])).rows[0].n;
    if (n < 1) throw bad('Mantenha ao menos um administrador principal ativo.');
  }
  await db.query('UPDATE admin_users SET active=$2 WHERE id=$1', [id, active]);
  await log(ctx, active ? 'Ativou administrador' : 'Desativou administrador', t.login);
  return { ok: true };
});
mod('post', '/admins/:id/password', SUPER, async (ctx) => {
  const id = L.uuid(ctx.params.id);
  const hash = await L.hashPassword(L.password(ctx.body.password));
  const r = await db.query('UPDATE admin_users SET password_hash=$2, failed_logins=0, locked_until=NULL, must_change_password=($1 <> $3::uuid) WHERE id=$1 RETURNING login', [id, hash, ctx.admin.id]);
  if (!r.rowCount) throw new HttpError(404, 'Administrador não encontrado.');
  await log(ctx, 'Redefiniu a senha de administrador', r.rows[0].login);
  return { ok: true };
});
mod('patch', '/me', { limit: { key: 'admme', perUser: true, max: 10, windowMs: 3600e3 } }, async (ctx) => {
  const b = ctx.body;
  const row = (await db.query('SELECT password_hash FROM admin_users WHERE id=$1', [ctx.admin.id])).rows[0];
  if (!(await L.verifyPassword(String(b.oldPassword || ''), row.password_hash))) throw bad('Senha atual incorreta.');
  const sets = [], vals = [ctx.admin.id];
  const set = (c, v) => { vals.push(v); sets.push(c + '=$' + vals.length); };
  if (b.name !== undefined) set('name', L.str(b.name, { min: 2, max: 80, required: true, label: 'Nome' }));
  if (b.login !== undefined) {
    const login = adminLogin(b.login);
    if (!(await loginFree(login, ctx.admin.id))) throw new HttpError(409, 'Este login já está em uso.');
    set('login', login);
  }
  if (b.newPassword) { set('password_hash', await L.hashPassword(L.password(b.newPassword))); sets.push('must_change_password=false'); }
  if (sets.length) await db.query('UPDATE admin_users SET ' + sets.join(', ') + ' WHERE id=$1', vals);
  await log(ctx, 'Alterou os próprios dados de acesso' + (b.newPassword ? ' (senha alterada)' : ''));
  const a = (await db.query('SELECT id, login, name, role, must_change_password FROM admin_users WHERE id=$1', [ctx.admin.id])).rows[0];
  return { admin: { id: a.id, login: a.login, name: a.name, role: a.role, mustChangePassword: a.must_change_password } };
});
mod('get', '/logs', SUPER, async (ctx) => {
  const { limit, offset } = pg(ctx.query);
  const { rows } = await db.query('SELECT id, admin_name, action, target, created_at FROM admin_logs ORDER BY created_at DESC, id DESC LIMIT $1 OFFSET $2', [limit, offset]);
  return { items: rows.map((r) => ({ id: r.id, admin: r.admin_name, action: r.action, target: r.target, createdAt: r.created_at })) };
});
