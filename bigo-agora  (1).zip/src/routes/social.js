'use strict';
const { cfg } = require('../config');
const db = require('../db');
const { api } = require('../http');
const L = require('../lib');
const { HttpError, bad, isUuid } = L;
const U = require('../users');
const { claimMedia, deleteMedia } = require('./media');

const mediaUrl = U.mediaUrl;
const page = (q, def = 10, max = 30) => {
  const limit = Math.min(max, Math.max(1, parseInt(q.limit, 10) || def));
  const pg = Math.max(0, parseInt(q.page, 10) || 0);
  return { limit, offset: pg * limit };
};

/* ───── dados públicos ───── */
api.get('/health', { auth: 'none' }, async () => {
  await db.query('SELECT 1');
  return { ok: true, env: cfg.appEnv };
});
api.get('/settings', { auth: 'none' }, async () => {
  const { rows } = await db.query('SELECT key, value FROM settings');
  const s = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  return {
    name: s.name || 'BiGo', color: s.color || '#E10600', logoUrl: s.logoMedia ? mediaUrl(s.logoMedia) : null,
    terms: s.terms || null, privacy: s.privacy || null, storage: cfg.storage,
    maxImageMb: cfg.maxImageMb, maxVideoMb: cfg.maxVideoMb, payments: !!cfg.mp.token, env: cfg.appEnv,
  };
});
api.get('/categories', { auth: 'none' }, async () => {
  const { rows } = await db.query(
    `SELECT c.id cid, c.name cname, s.id sid, s.name sname
       FROM categories c LEFT JOIN services s ON s.category_id = c.id AND s.active
      WHERE c.active ORDER BY c.sort_order, c.name, s.sort_order, s.name`);
  const out = []; const idx = new Map();
  for (const r of rows) {
    if (!idx.has(r.cid)) { idx.set(r.cid, { id: r.cid, name: r.cname, items: [] }); out.push(idx.get(r.cid)); }
    if (r.sid) idx.get(r.cid).items.push({ id: r.sid, name: r.sname });
  }
  return out;
});

/* ───── publicações ───── */
const POST_COLS = `p.id, p.author_id, p.text, p.price_text, p.before_after, p.sponsored, p.hidden, p.views, p.created_at,
  u.name author_name, u.role author_role, u.city author_city, u.state author_state, u.avatar_media author_avatar, u.phone author_phone,
  wp.profession, wp.whatsapp w_whatsapp, wp.ver_identity, wp.ver_qualifications,
  (p.show_whatsapp AND COALESCE(wp.show_whatsapp, false)) can_wa,
  (p.show_phone AND COALESCE(wp.show_phone, false)) can_tel,
  (SELECT count(*) FROM likes l WHERE l.post_id = p.id)::int likes,
  EXISTS(SELECT 1 FROM likes l WHERE l.post_id = p.id AND l.user_id = $1) liked,
  EXISTS(SELECT 1 FROM follows fw WHERE fw.follower_id = $1 AND fw.following_id = p.author_id) author_following,
  (SELECT count(*) FROM comments c WHERE c.post_id = p.id AND NOT c.hidden)::int comments`;
const POST_FROM = `FROM posts p JOIN users u ON u.id = p.author_id AND u.status = 'active'
  LEFT JOIN worker_profiles wp ON wp.user_id = u.id`;

async function hydrate(rows, meId) {
  if (!rows.length) return [];
  const ids = rows.map((r) => r.id);
  const m = await db.query(
    `SELECT pm.post_id, pm.position, md.id, md.kind FROM post_media pm JOIN media md ON md.id = pm.media_id
      WHERE pm.post_id = ANY($1::uuid[]) ORDER BY pm.post_id, pm.position`, [ids]);
  const by = new Map();
  for (const r of m.rows) { if (!by.has(r.post_id)) by.set(r.post_id, []); by.get(r.post_id).push({ id: r.id, kind: r.kind, url: mediaUrl(r.id) }); }
  return rows.map((r) => ({
    id: r.id, text: r.text, priceText: r.price_text, beforeAfter: r.before_after, sponsored: r.sponsored,
    createdAt: r.created_at, views: r.author_id === meId ? r.views : undefined,
    author: {
      id: r.author_id, name: r.author_name, role: r.author_role, city: r.author_city || '', state: r.author_state || '',
      avatarUrl: mediaUrl(r.author_avatar), profession: r.profession || null,
      verifiedIdentity: !!r.ver_identity, verifiedQualifications: !!r.ver_qualifications, following: !!r.author_following,
    },
    contacts: { whatsapp: r.can_wa ? r.w_whatsapp : null, phone: r.can_tel ? r.author_phone : null },
    media: by.get(r.id) || [], likes: r.likes, liked: r.liked, comments: r.comments, mine: r.author_id === meId,
  }));
}
async function getPost(id, me) {
  const { rows } = await db.query(`SELECT ${POST_COLS} ${POST_FROM} WHERE p.id = $2`, [me.id, id]);
  const r = rows[0];
  if (!r || (r.hidden && r.author_id !== me.id)) throw new HttpError(404, 'Publicação não encontrada ou removida.');
  return (await hydrate([r], me.id))[0];
}

api.get('/feed', async (ctx) => {
  const me = ctx.user, f = ctx.query.filter || 'all';
  const { limit, offset } = page(ctx.query);
  const params = [me.id, me.city || '', me.state || ''];
  const where = ['NOT p.hidden'];
  if (f === 'near') where.push('lower(u.city) = lower($2) AND u.state = $3');
  else if (f === 'fol') where.push('EXISTS (SELECT 1 FROM follows fw WHERE fw.follower_id = $1 AND fw.following_id = u.id)');
  else if (f === 'ba') where.push('p.before_after');
  else if (f === 'offer') where.push("p.price_text <> ''");
  params.push(limit, offset);
  const { rows } = await db.query(
    `SELECT ${POST_COLS} ${POST_FROM} WHERE ${where.join(' AND ')}
      ORDER BY (extract(epoch FROM p.created_at) * 1000
        + CASE WHEN lower(u.city) = lower($2) AND u.state = $3 THEN 259200000 WHEN u.state = $3 THEN 86400000 ELSE 0 END
        + CASE WHEN EXISTS (SELECT 1 FROM follows fx WHERE fx.follower_id = $1 AND fx.following_id = u.id) THEN 172800000 ELSE 0 END
        + CASE WHEN p.sponsored THEN 604800000 ELSE 0 END) DESC, p.id
      LIMIT $4 OFFSET $5`, params);
  return { items: await hydrate(rows, me.id), hasMore: rows.length === limit };
});

api.get('/users/:id/posts', async (ctx) => {
  const id = L.uuid(ctx.params.id);
  const { rows } = await db.query(
    `SELECT ${POST_COLS} ${POST_FROM} WHERE p.author_id = $2 AND (NOT p.hidden OR p.author_id = $1) ORDER BY p.created_at DESC LIMIT 60`,
    [ctx.user.id, id]);
  return { items: await hydrate(rows, ctx.user.id) };
});

api.post('/posts', { limit: { key: 'post', perUser: true, max: 3, windowMs: 60e3 } }, async (ctx) => {
  if (ctx.user.role !== 'WORKER') throw new HttpError(403, 'Apenas trabalhadores publicam trabalhos.');
  const b = ctx.body;
  const text = L.str(b.text, { min: 3, max: 2000, required: true, label: 'Descrição' });
  const ids = Array.isArray(b.mediaIds) ? [...new Set(b.mediaIds)] : [];
  if (!ids.length) throw bad('Adicione pelo menos uma foto ou vídeo.');
  if (ids.length > 6) throw bad('Máximo de 6 arquivos por publicação.');
  const ba = L.bool(b.beforeAfter);
  if (ba && ids.length < 2) throw bad('Para “antes e depois” envie ao menos 2 arquivos.');
  const priceText = L.str(b.priceText, { max: 80, label: 'Preço' });
  const id = await db.tx(async (q) => {
    await claimMedia(q, ids, ctx.user.id, null);
    const r = await q(
      `INSERT INTO posts (author_id, text, price_text, before_after, show_whatsapp, show_phone) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
      [ctx.user.id, text, priceText, ba, L.bool(b.showWhatsapp, true), L.bool(b.showPhone, true)]);
    for (let i = 0; i < ids.length; i++) await q('INSERT INTO post_media (post_id, media_id, position) VALUES ($1,$2,$3)', [r.rows[0].id, ids[i], i]);
    return r.rows[0].id;
  });
  ctx.status = 201;
  return getPost(id, ctx.user);
});
api.get('/posts/:id', async (ctx) => getPost(L.uuid(ctx.params.id), ctx.user));
api.patch('/posts/:id', async (ctx) => {
  const id = L.uuid(ctx.params.id), b = ctx.body, sets = ['updated_at = now()'], vals = [id, ctx.user.id];
  const set = (c, v) => { vals.push(v); sets.push(c + '=$' + vals.length); };
  if (b.text !== undefined) set('text', L.str(b.text, { min: 3, max: 2000, required: true, label: 'Descrição' }));
  if (b.priceText !== undefined) set('price_text', L.str(b.priceText, { max: 80, label: 'Preço' }));
  if (b.showWhatsapp !== undefined) set('show_whatsapp', L.bool(b.showWhatsapp));
  if (b.showPhone !== undefined) set('show_phone', L.bool(b.showPhone));
  const r = await db.query('UPDATE posts SET ' + sets.join(', ') + ' WHERE id=$1 AND author_id=$2', vals);
  if (!r.rowCount) throw new HttpError(404, 'Publicação não encontrada.');
  return getPost(id, ctx.user);
});
api.del('/posts/:id', async (ctx) => {
  const id = L.uuid(ctx.params.id);
  const own = await db.query('SELECT 1 FROM posts WHERE id=$1 AND author_id=$2', [id, ctx.user.id]);
  if (!own.rows.length) throw new HttpError(404, 'Publicação não encontrada.');
  const m = await db.query('SELECT media_id FROM post_media WHERE post_id=$1', [id]);
  await db.query('DELETE FROM posts WHERE id=$1', [id]);
  await deleteMedia(m.rows.map((r) => r.media_id));
  return { ok: true };
});
api.post('/posts/views', async (ctx) => {
  const ids = (Array.isArray(ctx.body.ids) ? ctx.body.ids : []).filter(isUuid).slice(0, 50);
  if (ids.length) {
    await db.query(
      `WITH ins AS (INSERT INTO post_views (post_id, viewer_id) SELECT p.id, $1 FROM posts p WHERE p.id = ANY($2::uuid[]) AND p.author_id <> $1
                    ON CONFLICT DO NOTHING RETURNING post_id)
       UPDATE posts SET views = views + 1 WHERE id IN (SELECT post_id FROM ins)`, [ctx.user.id, ids]);
  }
  return { ok: true };
});

/* ───── curtidas e comentários ───── */
api.post('/posts/:id/like', { limit: { key: 'like', perUser: true, max: 120, windowMs: 60e3 } }, async (ctx) => {
  const id = L.uuid(ctx.params.id);
  const p = (await db.query("SELECT p.author_id FROM posts p JOIN users u ON u.id=p.author_id AND u.status='active' WHERE p.id=$1 AND NOT p.hidden", [id])).rows[0];
  if (!p) throw new HttpError(404, 'Publicação não encontrada.');
  const ins = await db.query('INSERT INTO likes (post_id, user_id) VALUES ($1,$2) ON CONFLICT DO NOTHING', [id, ctx.user.id]);
  let liked = true;
  if (!ins.rowCount) { await db.query('DELETE FROM likes WHERE post_id=$1 AND user_id=$2', [id, ctx.user.id]); liked = false; }
  else if (p.author_id !== ctx.user.id) await U.notify(p.author_id, ctx.user.name + ' curtiu sua publicação.', '/post/' + id);
  const n = (await db.query('SELECT count(*)::int n FROM likes WHERE post_id=$1', [id])).rows[0].n;
  return { liked, likes: n };
});
api.get('/posts/:id/comments', async (ctx) => {
  const id = L.uuid(ctx.params.id);
  const { rows } = await db.query(
    `SELECT c.id, c.body, c.created_at, c.author_id, u.name, u.avatar_media
       FROM comments c JOIN users u ON u.id = c.author_id WHERE c.post_id = $1 AND NOT c.hidden ORDER BY c.created_at LIMIT 300`, [id]);
  return { items: rows.map((r) => ({ id: r.id, text: r.body, createdAt: r.created_at, author: { id: r.author_id, name: r.name, avatarUrl: mediaUrl(r.avatar_media) } })) };
});
api.post('/posts/:id/comments', { limit: { key: 'comment', perUser: true, max: 5, windowMs: 60e3 } }, async (ctx) => {
  const id = L.uuid(ctx.params.id);
  const body = L.str(ctx.body.text, { min: 1, max: 500, required: true, label: 'Comentário' });
  const p = (await db.query("SELECT p.author_id FROM posts p JOIN users u ON u.id=p.author_id AND u.status='active' WHERE p.id=$1 AND NOT p.hidden", [id])).rows[0];
  if (!p) throw new HttpError(404, 'Publicação não encontrada.');
  const dup = await db.query("SELECT 1 FROM comments WHERE author_id=$1 AND body=$2 AND created_at > now() - interval '1 minute'", [ctx.user.id, body]);
  if (dup.rows.length) throw bad('Comentário repetido.');
  const r = await db.query('INSERT INTO comments (post_id, author_id, body) VALUES ($1,$2,$3) RETURNING id, created_at', [id, ctx.user.id, body]);
  if (p.author_id !== ctx.user.id) await U.notify(p.author_id, ctx.user.name + ' comentou na sua publicação.', '/post/' + id);
  ctx.status = 201;
  return { id: r.rows[0].id, text: body, createdAt: r.rows[0].created_at, author: { id: ctx.user.id, name: ctx.user.name } };
});
api.del('/comments/:id', async (ctx) => {
  const id = L.uuid(ctx.params.id);
  const r = await db.query(
    `DELETE FROM comments c USING posts p WHERE c.id = $1 AND p.id = c.post_id AND (c.author_id = $2 OR p.author_id = $2)`, [id, ctx.user.id]);
  if (!r.rowCount) throw new HttpError(404, 'Comentário não encontrado.');
  return { ok: true };
});

/* ───── perfis e seguidores ───── */
api.get('/users/:id', async (ctx) => {
  const id = L.uuid(ctx.params.id), me = ctx.user;
  const { rows } = await db.query(
    `SELECT u.id, u.name, u.role, u.city, u.state, u.bairro, u.avatar_media, u.phone, u.created_at,
            wp.profession, wp.specialties, wp.bio, wp.experience, wp.courses, wp.availability, wp.radius_km, wp.looking_for_job,
            wp.whatsapp, wp.show_whatsapp, wp.show_phone, wp.cover_media, wp.ver_identity, wp.ver_qualifications, wp.profile_views,
            (SELECT count(*) FROM posts p WHERE p.id IS NOT NULL AND p.author_id = u.id AND NOT p.hidden)::int posts,
            (SELECT count(*) FROM follows f WHERE f.following_id = u.id)::int followers,
            EXISTS(SELECT 1 FROM follows f WHERE f.following_id = u.id AND f.follower_id = $2) following
       FROM users u LEFT JOIN worker_profiles wp ON wp.user_id = u.id WHERE u.id = $1 AND u.status = 'active'`, [id, me.id]);
  const r = rows[0];
  if (!r) throw new HttpError(404, 'Perfil não encontrado.');
  const isMe = id === me.id;
  if (!isMe && r.role === 'WORKER') {
    const v = await db.query('INSERT INTO profile_views (target_id, viewer_id) VALUES ($1,$2) ON CONFLICT DO NOTHING', [id, me.id]);
    if (v.rowCount) await db.query('UPDATE worker_profiles SET profile_views = profile_views + 1 WHERE user_id=$1', [id]);
  }
  const w = r.role === 'WORKER';
  return {
    id: r.id, name: r.name, role: r.role, city: r.city || '', state: r.state || '', bairro: r.bairro || '',
    avatarUrl: mediaUrl(r.avatar_media), createdAt: r.created_at, isMe, following: r.following,
    counts: { posts: r.posts, followers: r.followers },
    worker: w ? {
      profession: r.profession, specialties: r.specialties, bio: r.bio, experience: r.experience, courses: r.courses,
      availability: r.availability, radiusKm: r.radius_km, lookingForJob: r.looking_for_job, coverUrl: mediaUrl(r.cover_media),
      verifiedIdentity: r.ver_identity, verifiedQualifications: r.ver_qualifications,
      profileViews: isMe ? r.profile_views : undefined,
    } : null,
    contacts: w ? {
      whatsapp: (isMe || r.show_whatsapp) ? r.whatsapp || null : null,
      phone: (isMe || r.show_phone) ? r.phone || null : null,
    } : { whatsapp: null, phone: null },
  };
});
api.post('/users/:id/follow', { limit: { key: 'follow', perUser: true, max: 60, windowMs: 60e3 } }, async (ctx) => {
  const id = L.uuid(ctx.params.id);
  if (id === ctx.user.id) throw bad('Você não pode seguir a si mesmo.');
  const t = await db.query("SELECT 1 FROM users WHERE id=$1 AND status='active'", [id]);
  if (!t.rows.length) throw new HttpError(404, 'Perfil não encontrado.');
  const ins = await db.query('INSERT INTO follows (follower_id, following_id) VALUES ($1,$2) ON CONFLICT DO NOTHING', [ctx.user.id, id]);
  let following = true;
  if (!ins.rowCount) { await db.query('DELETE FROM follows WHERE follower_id=$1 AND following_id=$2', [ctx.user.id, id]); following = false; }
  else await U.notify(id, ctx.user.name + ' começou a seguir você.', '/profile/' + ctx.user.id);
  const n = (await db.query('SELECT count(*)::int n FROM follows WHERE following_id=$1', [id])).rows[0].n;
  return { following, followers: n };
});

/* ───── Stories (24 horas) ───── */
const STORY_SQL = `SELECT s.id, s.author_id, s.text, s.location, s.show_contact, s.created_at, s.expires_at, s.media_id, md.kind,
    u.name, u.avatar_media, u.phone, wp.whatsapp, wp.show_whatsapp, wp.show_phone,
    EXISTS(SELECT 1 FROM story_views v WHERE v.story_id = s.id AND v.viewer_id = $1) seen,
    (SELECT count(*) FROM story_views v WHERE v.story_id = s.id)::int views,
    EXISTS(SELECT 1 FROM follows f WHERE f.follower_id = $1 AND f.following_id = s.author_id) following
  FROM stories s JOIN users u ON u.id = s.author_id AND u.status = 'active'
  JOIN media md ON md.id = s.media_id LEFT JOIN worker_profiles wp ON wp.user_id = u.id`;
function mapStory(r, meId) {
  const mine = r.author_id === meId, c = r.show_contact;
  return {
    id: r.id, kind: r.kind, url: mediaUrl(r.media_id), text: r.text, location: r.location, createdAt: r.created_at, expiresAt: r.expires_at,
    seen: r.seen, views: mine ? r.views : undefined,
    contacts: c ? { whatsapp: r.show_whatsapp ? r.whatsapp || null : null, phone: r.show_phone ? r.phone || null : null } : { whatsapp: null, phone: null },
  };
}
api.get('/stories', async (ctx) => {
  const me = ctx.user.id;
  const { rows } = await db.query(STORY_SQL + ' WHERE s.expires_at > now() AND (NOT s.hidden OR s.author_id = $1) ORDER BY s.created_at', [me]);
  const groups = new Map();
  for (const r of rows) {
    if (!groups.has(r.author_id)) groups.set(r.author_id, { author: { id: r.author_id, name: r.name, avatarUrl: mediaUrl(r.avatar_media) }, isMe: r.author_id === me, following: r.following, hasUnseen: false, latest: 0, stories: [] });
    const g = groups.get(r.author_id), st = mapStory(r, me);
    g.stories.push(st);
    if (!st.seen && !g.isMe) g.hasUnseen = true;
    g.latest = Math.max(g.latest, new Date(r.created_at).getTime());
  }
  const list = [...groups.values()].sort((a, b) => (b.isMe - a.isMe) || (b.following - a.following) || (b.latest - a.latest));
  return { items: list.map(({ latest, ...g }) => g) };
});
api.post('/stories', { limit: { key: 'story', perUser: true, max: 20, windowMs: 3600e3 } }, async (ctx) => {
  if (ctx.user.role !== 'WORKER') throw new HttpError(403, 'Apenas trabalhadores publicam Stories.');
  const b = ctx.body;
  const mediaId = L.uuid(b.mediaId, 'Mídia');
  const id = await db.tx(async (q) => {
    await claimMedia(q, [mediaId], ctx.user.id, null);
    const r = await q(
      `INSERT INTO stories (author_id, media_id, text, location, show_contact, expires_at) VALUES ($1,$2,$3,$4,$5, now() + interval '24 hours') RETURNING id`,
      [ctx.user.id, mediaId, L.str(b.text, { max: 200, label: 'Texto' }), L.str(b.location, { max: 80, label: 'Localização' }), L.bool(b.showContact, true)]);
    return r.rows[0].id;
  });
  const { rows } = await db.query(STORY_SQL + ' WHERE s.id = $2', [ctx.user.id, id]);
  ctx.status = 201;
  return mapStory(rows[0], ctx.user.id);
});
api.post('/stories/:id/view', async (ctx) => {
  const id = L.uuid(ctx.params.id);
  await db.query(
    `INSERT INTO story_views (story_id, viewer_id) SELECT s.id, $2 FROM stories s WHERE s.id=$1 AND s.expires_at > now() AND s.author_id <> $2 ON CONFLICT DO NOTHING`,
    [id, ctx.user.id]);
  return { ok: true };
});
api.get('/stories/:id/views', async (ctx) => {
  const id = L.uuid(ctx.params.id);
  const own = await db.query('SELECT 1 FROM stories WHERE id=$1 AND author_id=$2', [id, ctx.user.id]);
  if (!own.rows.length) throw new HttpError(404, 'Story não encontrado.');
  const { rows } = await db.query(
    'SELECT u.id, u.name, v.viewed_at FROM story_views v JOIN users u ON u.id = v.viewer_id WHERE v.story_id = $1 ORDER BY v.viewed_at DESC', [id]);
  return { items: rows.map((r) => ({ id: r.id, name: r.name, viewedAt: r.viewed_at })) };
});
api.del('/stories/:id', async (ctx) => {
  const id = L.uuid(ctx.params.id);
  const r = await db.query('DELETE FROM stories WHERE id=$1 AND author_id=$2 RETURNING media_id', [id, ctx.user.id]);
  if (!r.rowCount) throw new HttpError(404, 'Story não encontrado.');
  await deleteMedia([r.rows[0].media_id]);
  return { ok: true };
});

/* ───── denúncias e notificações ───── */
api.post('/reports', { limit: { key: 'report', perUser: true, max: 20, windowMs: 3600e3 } }, async (ctx) => {
  const type = ctx.body.targetType;
  if (!['post', 'story', 'user'].includes(type)) throw bad('Tipo de denúncia inválido.');
  const targetId = L.uuid(ctx.body.targetId, 'Item');
  const table = { post: 'posts', story: 'stories', user: 'users' }[type];
  const ex = await db.query('SELECT 1 FROM ' + table + ' WHERE id=$1', [targetId]);
  if (!ex.rows.length) throw new HttpError(404, 'Item não encontrado.');
  if (type === 'user' && targetId === ctx.user.id) throw bad('Você não pode denunciar a si mesmo.');
  const reason = L.str(ctx.body.reason, { required: true, max: 100, label: 'Motivo' });
  const ins = await db.query(
    'INSERT INTO reports (reporter_id, target_type, target_id, reason, details) VALUES ($1,$2,$3,$4,$5) ON CONFLICT DO NOTHING',
    [ctx.user.id, type, targetId, reason, L.str(ctx.body.details, { max: 500, label: 'Detalhes' })]);
  if (!ins.rowCount) throw new HttpError(409, 'Você já denunciou este item.');
  ctx.status = 201;
  return { ok: true };
});
api.get('/notifications', async (ctx) => {
  const { rows } = await db.query('SELECT id, text, link, read, created_at FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 80', [ctx.user.id]);
  const unread = (await db.query('SELECT count(*)::int n FROM notifications WHERE user_id=$1 AND NOT read', [ctx.user.id])).rows[0].n;
  return { unread, items: rows.map((r) => ({ id: r.id, text: r.text, link: r.link, read: r.read, createdAt: r.created_at })) };
});
api.post('/notifications/read', async (ctx) => {
  await db.query('UPDATE notifications SET read = true WHERE user_id=$1 AND NOT read', [ctx.user.id]);
  return { ok: true };
});
api.get('/notifications/count', async (ctx) => {
  return { unread: (await db.query('SELECT count(*)::int n FROM notifications WHERE user_id=$1 AND NOT read', [ctx.user.id])).rows[0].n };
});

module.exports = { getPost };
