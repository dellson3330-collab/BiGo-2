'use strict';
const crypto = require('crypto');
const { cfg } = require('../config');
const db = require('../db');
const { api } = require('../http');
const L = require('../lib');
const { HttpError, bad } = L;
const U = require('../users');
const { logAdmin } = require('../audit');
const mail = require('../mail');
const { claimMedia, deleteMedia } = require('./media');

const GENERIC = 'E-mail ou senha incorretos.';
const TERMS_VERSION = '2026-11-v1';

async function issueSession(user, ctx, family) {
  const accessToken = L.signJwt({ sub: user.id, typ: 'user', role: user.role }, cfg.jwtSecret, 15 * 60);
  const refreshToken = L.randomToken(48);
  await db.query(
    `INSERT INTO refresh_tokens (user_id, token_hash, family, ip, user_agent, expires_at)
     VALUES ($1,$2,$3,$4,$5, now() + interval '30 days')`,
    [user.id, L.sha256(refreshToken), family || crypto.randomUUID(), ctx.ip, String(ctx.req.headers['user-agent'] || '').slice(0, 255)]);
  return { accessToken, refreshToken };
}

/* ───── cadastro ───── */
api.post('/auth/register', { auth: 'none', limit: { key: 'register', max: 10, windowMs: 3600e3 } }, async (ctx) => {
  const b = ctx.body;
  if (b.acceptTerms !== true) throw bad('É necessário aceitar os Termos de Uso e a Política de Privacidade.');
  const role = ['CLIENT', 'WORKER', 'COMPANY'].includes(b.role) ? b.role : null;
  if (!role) throw bad('Escolha se você é cliente ou trabalhador.');
  const d = {
    role,
    email: L.email(b.email),
    password: L.password(b.password),
    name: L.str(b.name, { min: 2, max: 120, required: true, label: 'Nome' }),
    phone: L.phone(b.phone),
    city: L.str(b.city, { min: 2, max: 80, required: true, label: 'Cidade' }),
    state: L.uf(b.state),
    profession: role === 'WORKER' ? L.str(b.profession, { required: true, max: 80, label: 'Profissão' }) : null,
    consentVer: TERMS_VERSION,
    showContact: b.showContact === true, // divulgação de contato é escolha explícita do trabalhador
  };
  if (role === 'WORKER') await U.checkProfession(d.profession);
  const taken = await db.query('SELECT 1 FROM users WHERE email=$1 UNION ALL SELECT 1 FROM admin_users WHERE login=$1', [d.email]);
  if (taken.rows.length) throw new HttpError(409, 'Este e-mail já está cadastrado.');
  const id = await U.createUser(d);
  const session = await issueSession({ id, role }, ctx);
  ctx.status = 201;
  return { kind: 'user', ...session, user: await U.loadMe(id) };
});

/* ───── login único: usuários e administradores ───── */
api.post('/auth/login', { auth: 'none', limit: { key: 'login', max: 20, windowMs: 60e3 } }, async (ctx) => {
  const login = L.str(ctx.body.login !== undefined ? ctx.body.login : ctx.body.email, { required: true, max: 160, label: 'Login' }).toLowerCase();
  const pw = typeof ctx.body.password === 'string' ? ctx.body.password : '';
  if (!pw || pw.length > 256) throw bad('Informe a senha.');
  const fail = () => new HttpError(401, GENERIC);
  const locked = () => new HttpError(429, 'Muitas tentativas. Tente novamente em alguns minutos.');

  const a = (await db.query('SELECT * FROM admin_users WHERE login=$1', [login])).rows[0];
  if (a) {
    if (!a.active) { await L.dummyVerify(pw); throw fail(); }
    if (a.locked_until && new Date(a.locked_until) > new Date()) throw locked();
    if (!(await L.verifyPassword(pw, a.password_hash))) {
      await db.query(
        `UPDATE admin_users SET failed_logins = CASE WHEN failed_logins + 1 >= 5 THEN 0 ELSE failed_logins + 1 END,
                locked_until = CASE WHEN failed_logins + 1 >= 5 THEN now() + interval '15 minutes' ELSE locked_until END WHERE id=$1`, [a.id]);
      throw fail();
    }
    await db.query('UPDATE admin_users SET failed_logins=0, locked_until=NULL WHERE id=$1', [a.id]);
    await logAdmin(a, 'Login no painel', null, ctx.ip);
    return {
      kind: 'admin',
      accessToken: L.signJwt({ sub: a.id, typ: 'admin', role: a.role }, cfg.jwtSecret, 2 * 3600),
      admin: { id: a.id, login: a.login, name: a.name, role: a.role, mustChangePassword: a.must_change_password },
    };
  }

  const u = (await db.query('SELECT * FROM users WHERE email=$1', [login])).rows[0];
  if (!u) { await L.dummyVerify(pw); throw fail(); }
  if (u.locked_until && new Date(u.locked_until) > new Date()) throw locked();
  if (!(await L.verifyPassword(pw, u.password_hash))) {
    await db.query(
      `UPDATE users SET failed_logins = CASE WHEN failed_logins + 1 >= 5 THEN 0 ELSE failed_logins + 1 END,
              locked_until = CASE WHEN failed_logins + 1 >= 5 THEN now() + interval '15 minutes' ELSE locked_until END WHERE id=$1`, [u.id]);
    throw fail();
  }
  if (u.status === 'blocked') throw new HttpError(403, 'Conta bloqueada. Entre em contato com o suporte.');
  await db.query('UPDATE users SET failed_logins=0, locked_until=NULL, last_seen=now() WHERE id=$1', [u.id]);
  const session = await issueSession(u, ctx);
  return { kind: 'user', ...session, user: await U.loadMe(u.id) };
});

/* ───── renovação de sessão com rotação e detecção de reuso ───── */
api.post('/auth/refresh', { auth: 'none', limit: { key: 'refresh', max: 60, windowMs: 60e3 } }, async (ctx) => {
  const tok = typeof ctx.body.refreshToken === 'string' ? ctx.body.refreshToken : '';
  if (!tok) throw new HttpError(401, 'Sessão inválida.');
  const { rows } = await db.query(
    `SELECT t.id, t.user_id, t.family, t.revoked_at, t.expires_at, u.role, u.status
       FROM refresh_tokens t JOIN users u ON u.id = t.user_id WHERE t.token_hash = $1`, [L.sha256(tok)]);
  const t = rows[0];
  if (!t) throw new HttpError(401, 'Sessão inválida.');
  if (t.revoked_at) { // reuso de token já usado: derruba toda a família
    await db.query('UPDATE refresh_tokens SET revoked_at = now() WHERE family = $1 AND revoked_at IS NULL', [t.family]);
    throw new HttpError(401, 'Sessão inválida. Faça login novamente.');
  }
  if (new Date(t.expires_at) < new Date() || t.status !== 'active') throw new HttpError(401, 'Sessão expirada. Faça login novamente.');
  const used = await db.query('UPDATE refresh_tokens SET revoked_at = now() WHERE id = $1 AND revoked_at IS NULL', [t.id]);
  if (!used.rowCount) throw new HttpError(401, 'Sessão inválida.');
  return issueSession({ id: t.user_id, role: t.role }, ctx, t.family);
});
api.post('/auth/logout', { auth: 'none' }, async (ctx) => {
  const tok = typeof ctx.body.refreshToken === 'string' ? ctx.body.refreshToken : '';
  if (tok) await db.query('UPDATE refresh_tokens SET revoked_at = now() WHERE token_hash = $1 AND revoked_at IS NULL', [L.sha256(tok)]);
  return { ok: true };
});

/* ───── recuperação de senha por código enviado por e-mail ───── */
api.post('/auth/forgot', { auth: 'none', limit: { key: 'forgot', max: 5, windowMs: 3600e3 } }, async (ctx) => {
  const email = L.email(ctx.body.email);
  const u = (await db.query("SELECT id FROM users WHERE email=$1 AND status='active'", [email])).rows[0];
  const out = { ok: true, message: 'Se o e-mail estiver cadastrado, enviaremos um código de recuperação.' };
  if (!u) return out;
  const code = String(crypto.randomInt(100000, 1000000));
  await db.query(
    `INSERT INTO password_resets (user_id, code_hash, expires_at, attempts) VALUES ($1,$2, now() + interval '15 minutes', 0)
     ON CONFLICT (user_id) DO UPDATE SET code_hash = EXCLUDED.code_hash, expires_at = EXCLUDED.expires_at, attempts = 0`,
    [u.id, L.sha256(code + ':' + u.id)]);
  const sent = await mail.send(email, 'Código de recuperação de senha', 'Seu código de recuperação é ' + code + '. Ele vale por 15 minutos. Se você não pediu, ignore esta mensagem.');
  if (!sent) {
    if (cfg.prod) console.warn('[aviso] e-mail não configurado (RESEND_API_KEY/MAIL_FROM): código de recuperação NÃO enviado. O administrador pode redefinir a senha.');
    else out.devCode = code; // somente em demonstração
  }
  return out;
});
api.post('/auth/reset', { auth: 'none', limit: { key: 'reset', max: 10, windowMs: 3600e3 } }, async (ctx) => {
  const email = L.email(ctx.body.email);
  const code = L.str(ctx.body.code, { required: true, max: 10, label: 'Código' });
  const pw = L.password(ctx.body.password);
  const u = (await db.query('SELECT id FROM users WHERE email=$1', [email])).rows[0];
  const invalid = new HttpError(400, 'Código inválido ou expirado.');
  if (!u) throw invalid;
  const r = (await db.query('SELECT * FROM password_resets WHERE user_id=$1', [u.id])).rows[0];
  if (!r || new Date(r.expires_at) < new Date() || r.attempts >= 5) throw invalid;
  if (L.sha256(code + ':' + u.id) !== r.code_hash) {
    await db.query('UPDATE password_resets SET attempts = attempts + 1 WHERE user_id=$1', [u.id]);
    throw invalid;
  }
  const hash = await L.hashPassword(pw);
  await db.tx(async (q) => {
    await q('UPDATE users SET password_hash=$2, failed_logins=0, locked_until=NULL WHERE id=$1', [u.id, hash]);
    await q('DELETE FROM password_resets WHERE user_id=$1', [u.id]);
    await q('UPDATE refresh_tokens SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL', [u.id]);
  });
  return { ok: true };
});

/* ───── minha conta ───── */
api.get('/me', async (ctx) => U.loadMe(ctx.user.id));

api.patch('/me', async (ctx) => {
  const b = ctx.body, sets = [], vals = [ctx.user.id];
  const set = (col, v) => { vals.push(v); sets.push(col + '=$' + vals.length); };
  if (b.name !== undefined) set('name', L.str(b.name, { min: 2, max: 120, required: true, label: 'Nome' }));
  if (b.phone !== undefined) set('phone', L.phone(b.phone));
  if (b.city !== undefined) set('city', L.str(b.city, { min: 2, max: 80, required: true, label: 'Cidade' }));
  if (b.state !== undefined) set('state', L.uf(b.state));
  if (b.bairro !== undefined) set('bairro', L.str(b.bairro, { max: 80, label: 'Bairro' }));
  let oldAvatar = null;
  if (b.avatarMediaId !== undefined) {
    const cur = (await db.query('SELECT avatar_media FROM users WHERE id=$1', [ctx.user.id])).rows[0];
    oldAvatar = cur && cur.avatar_media;
    if (b.avatarMediaId === null) set('avatar_media', null);
    else { await claimMedia(db.query, [b.avatarMediaId], ctx.user.id, ['image']); set('avatar_media', b.avatarMediaId); }
  }
  if (sets.length) await db.query('UPDATE users SET ' + sets.join(', ') + ' WHERE id=$1', vals);
  if (oldAvatar && oldAvatar !== b.avatarMediaId) await deleteMedia([oldAvatar]);
  return U.loadMe(ctx.user.id);
});

api.patch('/me/worker', async (ctx) => {
  if (ctx.user.role !== 'WORKER') throw new HttpError(403, 'Apenas trabalhadores possuem perfil profissional.');
  const b = ctx.body, sets = [], vals = [ctx.user.id];
  const set = (col, v) => { vals.push(v); sets.push(col + '=$' + vals.length); };
  if (b.profession !== undefined) { const p = L.str(b.profession, { required: true, max: 80, label: 'Profissão' }); await U.checkProfession(p); set('profession', p); }
  for (const [k, col, max] of [['specialties', 'specialties', 200], ['bio', 'bio', 1500], ['experience', 'experience', 1500], ['courses', 'courses', 1000]]) {
    if (b[k] !== undefined) set(col, L.str(b[k], { max, label: k }));
  }
  if (b.availability !== undefined) { if (!U.AVAIL.includes(b.availability)) throw bad('Disponibilidade inválida.'); set('availability', b.availability); }
  if (b.radiusKm !== undefined) { const n = Math.round(Number(b.radiusKm)); if (!(n >= 1 && n <= 500)) throw bad('Região de atendimento deve ficar entre 1 e 500 km.'); set('radius_km', n); }
  if (b.lookingForJob !== undefined) set('looking_for_job', L.bool(b.lookingForJob));
  if (b.whatsapp !== undefined) set('whatsapp', L.phone(b.whatsapp, false));
  if (b.showWhatsapp !== undefined) set('show_whatsapp', L.bool(b.showWhatsapp));
  if (b.showPhone !== undefined) set('show_phone', L.bool(b.showPhone));
  let oldCover = null;
  if (b.coverMediaId !== undefined) {
    const cur = (await db.query('SELECT cover_media FROM worker_profiles WHERE user_id=$1', [ctx.user.id])).rows[0];
    oldCover = cur && cur.cover_media;
    if (b.coverMediaId === null) set('cover_media', null);
    else { await claimMedia(db.query, [b.coverMediaId], ctx.user.id, ['image']); set('cover_media', b.coverMediaId); }
  }
  if (sets.length) await db.query('UPDATE worker_profiles SET ' + sets.join(', ') + ' WHERE user_id=$1', vals);
  if (oldCover && oldCover !== b.coverMediaId) await deleteMedia([oldCover]);
  return U.loadMe(ctx.user.id);
});

api.post('/me/password', { limit: { key: 'pwchange', perUser: true, max: 5, windowMs: 3600e3 } }, async (ctx) => {
  const row = (await db.query('SELECT password_hash FROM users WHERE id=$1', [ctx.user.id])).rows[0];
  if (!(await L.verifyPassword(String(ctx.body.oldPassword || ''), row.password_hash))) throw bad('Senha atual incorreta.');
  const hash = await L.hashPassword(L.password(ctx.body.newPassword));
  await db.tx(async (q) => {
    await q('UPDATE users SET password_hash=$2 WHERE id=$1', [ctx.user.id, hash]);
    await q('UPDATE refresh_tokens SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL', [ctx.user.id]);
  });
  return { kind: 'user', ...(await issueSession(ctx.user, ctx)) };
});

/* LGPD: exportação e exclusão dos dados do titular */
api.get('/me/export', { limit: { key: 'export', perUser: true, max: 5, windowMs: 3600e3 } }, async (ctx) => {
  const id = ctx.user.id, q = (t) => db.query(t, [id]).then((r) => r.rows);
  const [posts, comments, stories, following, likes, reports] = await Promise.all([
    q('SELECT id, text, price_text, before_after, created_at FROM posts WHERE author_id=$1'),
    q('SELECT id, post_id, body, created_at FROM comments WHERE author_id=$1'),
    q('SELECT id, text, location, created_at, expires_at FROM stories WHERE author_id=$1'),
    q('SELECT following_id, created_at FROM follows WHERE follower_id=$1'),
    q('SELECT post_id, created_at FROM likes WHERE user_id=$1'),
    q('SELECT target_type, target_id, reason, created_at FROM reports WHERE reporter_id=$1'),
  ]);
  return { exportedAt: new Date().toISOString(), user: await U.loadMe(id), posts, comments, stories, following, likes, reports };
});
api.del('/me', { limit: { key: 'delacc', perUser: true, max: 5, windowMs: 3600e3 } }, async (ctx) => {
  const row = (await db.query('SELECT password_hash FROM users WHERE id=$1', [ctx.user.id])).rows[0];
  if (!(await L.verifyPassword(String(ctx.body.password || ''), row.password_hash))) throw bad('Senha incorreta.');
  await U.wipeUser(ctx.user.id);
  return { ok: true };
});
