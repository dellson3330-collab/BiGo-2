'use strict';
const db = require('./db');
const { HttpError, bad, hashPassword } = require('./lib');
const { removeFiles } = require('./routes/media');

const AVAIL = ['Disponível', 'Disponível em breve', 'Agenda cheia', 'Apenas fins de semana'];
const mediaUrl = (id) => (id ? '/media/' + id : null);

function mapMe(r) {
  const worker = r.role === 'WORKER' ? {
    profession: r.profession, specialties: r.specialties, bio: r.bio, experience: r.experience, courses: r.courses,
    availability: r.availability, radiusKm: r.radius_km, lookingForJob: r.looking_for_job, whatsapp: r.whatsapp || '',
    showWhatsapp: r.show_whatsapp, showPhone: r.show_phone, coverUrl: mediaUrl(r.cover_media),
    verifiedIdentity: r.ver_identity, verifiedQualifications: r.ver_qualifications, profileViews: r.profile_views,
  } : null;
  return {
    id: r.id, email: r.email, role: r.role, name: r.name, phone: r.phone || '', city: r.city || '', state: r.state || '',
    bairro: r.bairro || '', avatarUrl: mediaUrl(r.avatar_media), createdAt: r.created_at, worker,
    company: r.role === 'COMPANY' ? { tradeName: r.trade_name } : null,
  };
}
async function loadMe(id) {
  const { rows } = await db.query(
    `SELECT u.id, u.email, u.role, u.name, u.phone, u.city, u.state, u.bairro, u.avatar_media, u.created_at,
            wp.profession, wp.specialties, wp.bio, wp.experience, wp.courses, wp.availability, wp.radius_km,
            wp.looking_for_job, wp.whatsapp, wp.show_whatsapp, wp.show_phone, wp.cover_media,
            wp.ver_identity, wp.ver_qualifications, wp.profile_views, c.trade_name
       FROM users u LEFT JOIN worker_profiles wp ON wp.user_id = u.id LEFT JOIN companies c ON c.user_id = u.id
      WHERE u.id = $1`, [id]);
  if (!rows[0]) throw new HttpError(404, 'Usuário não encontrado.');
  return mapMe(rows[0]);
}

async function checkProfession(name) {
  const { rows } = await db.query('SELECT 1 FROM services WHERE name = $1 AND active', [name]);
  if (!rows.length) throw bad('Selecione uma profissão válida.');
}

/** Cria usuário e perfil correspondente. `d` já deve estar validado. */
async function createUser(d) {
  const passwordHash = await hashPassword(d.password);
  return db.tx(async (q) => {
    const { rows } = await q(
      `INSERT INTO users (email, password_hash, role, name, phone, city, state, consent_ver)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
      [d.email, passwordHash, d.role, d.name, d.phone, d.city, d.state, d.consentVer]);
    const id = rows[0].id;
    if (d.role === 'WORKER') await q('INSERT INTO worker_profiles (user_id, profession, whatsapp, show_whatsapp, show_phone) VALUES ($1,$2,$3,$4,$4)', [id, d.profession, d.phone, !!d.showContact]);
    else if (d.role === 'CLIENT') await q('INSERT INTO client_profiles (user_id) VALUES ($1)', [id]);
    else await q('INSERT INTO companies (user_id, trade_name) VALUES ($1,$2)', [id, d.name]);
    return id;
  });
}

/** Apaga o usuário e tudo dele (cascata no banco) e remove os arquivos de mídia. */
async function wipeUser(id) {
  const { rows } = await db.query('SELECT storage_key FROM media WHERE owner_id = $1', [id]);
  await db.query('DELETE FROM users WHERE id = $1', [id]);
  await removeFiles(rows.map((r) => r.storage_key));
}

const notify = (userId, text, link) =>
  db.query('INSERT INTO notifications (user_id, text, link) VALUES ($1,$2,$3)', [userId, text, link || null]).catch((e) => console.error('[notify]', e.message));

module.exports = { AVAIL, mediaUrl, mapMe, loadMe, checkProfession, createUser, wipeUser, notify };
