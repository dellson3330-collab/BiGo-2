'use strict';
const path = require('path');
const crypto = require('crypto');
const env = process.env;

const appEnv = (env.APP_ENV || 'production').toLowerCase(); // production | demo
const prod = appEnv === 'production';

const cfg = {
  appEnv,
  prod,
  port: Number(env.PORT) || 3000,
  databaseUrl: env.DATABASE_URL,
  databaseSsl: env.DATABASE_SSL === 'true',
  jwtSecret: env.JWT_SECRET || '',
  corsOrigins: (env.CORS_ORIGINS || '*').split(',').map((s) => s.trim()).filter(Boolean),
  trustProxy: env.TRUST_PROXY !== 'false',
  adminLogin: (env.ADMIN_LOGIN || 'admin').trim().toLowerCase(),
  adminPassword: env.ADMIN_PASSWORD || '',
  // Armazenamento de mídia: "local" (disco) ou "s3" (S3 compatível, ex.: Cloudflare R2)
  storage: (env.STORAGE_DRIVER || 'local').toLowerCase(),
  uploadDir: env.UPLOAD_DIR || path.join(__dirname, '..', 'data', 'uploads'),
  maxImageMb: Number(env.MAX_IMAGE_MB) || 15,
  maxVideoMb: Number(env.MAX_VIDEO_MB) || 100,
  s3: {
    endpoint: (env.S3_ENDPOINT || '').replace(/\/+$/, ''), // ex.: https://<conta>.r2.cloudflarestorage.com
    region: env.S3_REGION || 'auto',
    bucket: env.S3_BUCKET || '',
    accessKey: env.S3_ACCESS_KEY || '',
    secretKey: env.S3_SECRET_KEY || '',
    publicUrl: (env.S3_PUBLIC_URL || '').replace(/\/+$/, ''), // URL pública do bucket (domínio r2.dev ou próprio)
    pathStyle: env.S3_PATH_STYLE !== 'false',
  },
  // Pagamentos (Mercado Pago). Sem MP_ACCESS_TOKEN o recurso fica desligado.
  appUrl: (env.APP_URL || '').replace(/\/+$/, ''),           // endereço público do app, ex.: https://bigo.hospedeaqui.cloud
  mp: {
    token: env.MP_ACCESS_TOKEN || '',
    webhookSecret: env.MP_WEBHOOK_SECRET || '',               // "Assinatura secreta" do webhook no painel do Mercado Pago
    api: (env.MP_API_URL || 'https://api.mercadopago.com').replace(/\/+$/, ''),
  },
  resendKey: env.RESEND_API_KEY || '',
  mailFrom: env.MAIL_FROM || '',
};

function validate() {
  const errs = [];
  if (!cfg.databaseUrl) errs.push('DATABASE_URL não definida.');
  if (!cfg.jwtSecret || cfg.jwtSecret.length < 32) {
    if (prod) errs.push('JWT_SECRET precisa ter pelo menos 32 caracteres (gere com: openssl rand -base64 48).');
    else {
      cfg.jwtSecret = crypto.randomBytes(48).toString('base64');
      console.warn('[aviso] JWT_SECRET ausente: usando segredo temporário (sessões caem a cada reinício).');
    }
  }
  if (cfg.storage === 's3') {
    for (const k of ['endpoint', 'bucket', 'accessKey', 'secretKey', 'publicUrl']) {
      if (!cfg.s3[k]) errs.push('Armazenamento S3 ativo, mas falta S3_' + k.replace(/[A-Z]/g, (c) => '_' + c).toUpperCase() + '.');
    }
  } else if (cfg.storage !== 'local') errs.push('STORAGE_DRIVER deve ser "local" ou "s3".');
  if (cfg.mp.token) {
    if (!/^https:\/\//.test(cfg.appUrl) && cfg.prod) errs.push('Pagamentos ativos: defina APP_URL com o endereço https público do app.');
    if (cfg.prod && !cfg.mp.webhookSecret) console.warn('[aviso] MP_WEBHOOK_SECRET ausente: o webhook será validado só consultando o pagamento na API do Mercado Pago.');
  }
  if (errs.length) {
    console.error('Configuração inválida:\n - ' + errs.join('\n - '));
    process.exit(1);
  }
}
module.exports = { cfg, validate };
