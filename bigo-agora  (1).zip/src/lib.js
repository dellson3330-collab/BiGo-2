'use strict';
const crypto = require('crypto');

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const bad = (m) => new HttpError(400, m);

const UFS = 'AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO'.split(' ');
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const isUuid = (v) => typeof v === 'string' && UUID.test(v);
const digits = (s) => String(s == null ? '' : s).replace(/\D/g, '');
const EMAIL = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

function str(v, { min = 0, max = 500, required = false, label = 'Campo' } = {}) {
  if (v == null || v === '') {
    if (required) throw bad(label + ' é obrigatório.');
    return '';
  }
  if (typeof v !== 'string') throw bad(label + ' inválido.');
  const s = v.trim();
  if (s.length < min) throw bad(label + ' deve ter pelo menos ' + min + ' caracteres.');
  if (s.length > max) throw bad(label + ' deve ter no máximo ' + max + ' caracteres.');
  return s;
}
function email(v) {
  const s = str(v, { required: true, max: 160, label: 'E-mail' }).toLowerCase();
  if (!EMAIL.test(s)) throw bad('E-mail inválido.');
  return s;
}
function phone(v, required = true) {
  const d = digits(v);
  if (!d && !required) return '';
  if (d.length < 10 || d.length > 13) throw bad('Telefone inválido. Use DDD + número.');
  return d;
}
function uf(v, required = true) {
  const s = String(v || '').trim().toUpperCase();
  if (!s && !required) return '';
  if (!UFS.includes(s)) throw bad('UF inválida.');
  return s;
}
function password(v, min = 10) {
  if (typeof v !== 'string' || v.length < min) throw bad('A senha deve ter pelo menos ' + min + ' caracteres.');
  if (v.length > 128) throw bad('A senha é longa demais.');
  return v;
}
const bool = (v, d = false) => (v === undefined || v === null ? d : v === true || v === 'true');
function uuid(v, label = 'Identificador') {
  if (!isUuid(v)) throw bad(label + ' inválido.');
  return v;
}

/* ───── senhas (scrypt, nativo do Node) ───── */
const scrypt = (pw, salt) => new Promise((ok, no) =>
  crypto.scrypt(pw, salt, 64, { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 }, (e, k) => (e ? no(e) : ok(k))));
async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const k = await scrypt(pw, salt);
  return 'scrypt$' + salt.toString('base64') + '$' + k.toString('base64');
}
async function verifyPassword(pw, stored) {
  const [t, s, h] = String(stored || '').split('$');
  if (t !== 'scrypt' || !s || !h) return false;
  const k = await scrypt(pw, Buffer.from(s, 'base64'));
  const e = Buffer.from(h, 'base64');
  return e.length === k.length && crypto.timingSafeEqual(e, k);
}
let DUMMY = null;
async function dummyVerify(pw) { // iguala o tempo de resposta quando o usuário não existe
  if (!DUMMY) DUMMY = await hashPassword('dummy-password-for-timing');
  await verifyPassword(pw, DUMMY);
}

const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const randomToken = (n = 48) => crypto.randomBytes(n).toString('base64url');

/* ───── JWT HS256 ───── */
const b64 = (o) => Buffer.from(typeof o === 'string' ? o : JSON.stringify(o)).toString('base64url');
function signJwt(payload, secret, ttlSec) {
  const now = Math.floor(Date.now() / 1000);
  const h = b64({ alg: 'HS256', typ: 'JWT' });
  const p = b64({ ...payload, iat: now, exp: now + ttlSec });
  const s = crypto.createHmac('sha256', secret).update(h + '.' + p).digest('base64url');
  return h + '.' + p + '.' + s;
}
function verifyJwt(token, secret) {
  const parts = String(token || '').split('.');
  if (parts.length !== 3) return null;
  const exp = crypto.createHmac('sha256', secret).update(parts[0] + '.' + parts[1]).digest();
  const got = Buffer.from(parts[2], 'base64url');
  if (got.length !== exp.length || !crypto.timingSafeEqual(got, exp)) return null;
  let p;
  try { p = JSON.parse(Buffer.from(parts[1], 'base64url').toString()); } catch (_) { return null; }
  if (!p.exp || p.exp < Date.now() / 1000) return null;
  return p;
}

/* ───── limite de requisições em memória ───── */
const hits = new Map();
function rateLimit(key, max, windowMs) {
  const n = Date.now();
  const arr = (hits.get(key) || []).filter((t) => n - t < windowMs);
  if (arr.length >= max) { hits.set(key, arr); throw new HttpError(429, 'Muitas requisições. Aguarde um momento e tente novamente.'); }
  arr.push(n);
  hits.set(key, arr);
}
setInterval(() => {
  const n = Date.now();
  for (const [k, a] of hits) if (!a.length || n - a[a.length - 1] > 3600e3) hits.delete(k);
}, 600e3).unref();

module.exports = {
  HttpError, bad, UFS, isUuid, digits, str, email, phone, uf, password, bool, uuid,
  hashPassword, verifyPassword, dummyVerify, sha256, randomToken, signJwt, verifyJwt, rateLimit,
};
