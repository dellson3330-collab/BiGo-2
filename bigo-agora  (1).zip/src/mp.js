'use strict';
// Cliente mínimo da API do Mercado Pago (somente HTTPS de saída; nenhum dado de cartão passa por aqui).
const crypto = require('crypto');
const { cfg } = require('./config');
const { HttpError } = require('./lib');

const enabled = () => !!cfg.mp.token;

async function call(method, path, body, extraHeaders) {
  if (!enabled()) throw new HttpError(503, 'Pagamentos não estão ativados neste servidor.');
  let r;
  try {
    r = await fetch(cfg.mp.api + path, {
      method,
      headers: { Authorization: 'Bearer ' + cfg.mp.token, 'Content-Type': 'application/json', ...(extraHeaders || {}) },
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(15000),
    });
  } catch (e) { throw new HttpError(502, 'Não foi possível falar com o Mercado Pago. Tente novamente.'); }
  let j = null; try { j = await r.json(); } catch (_) {}
  if (!r.ok) {
    console.error('[mp]', method, path, r.status, JSON.stringify(j).slice(0, 300));
    throw new HttpError(502, 'O Mercado Pago recusou a operação (código ' + r.status + ').');
  }
  return j;
}

/** Checkout Pro: cria a preferência e devolve a URL de pagamento. Pix e cartão; boleto/caixa eletrônico ficam de fora. */
async function createPreference({ title, amountCents, externalRef, payerEmail, backBase }) {
  const body = {
    items: [{ id: externalRef, title, quantity: 1, currency_id: 'BRL', unit_price: Math.round(amountCents) / 100 }],
    external_reference: externalRef,
    payer: payerEmail ? { email: payerEmail } : undefined,
    payment_methods: { excluded_payment_types: [{ id: 'ticket' }, { id: 'atm' }], installments: 12 },
    notification_url: cfg.appUrl ? cfg.appUrl + '/api/billing/webhook' : undefined,
    back_urls: { success: backBase, pending: backBase, failure: backBase },
    auto_return: 'approved',
    statement_descriptor: 'BIGO',
    expires: true,
    expiration_date_to: new Date(Date.now() + 2 * 3600e3).toISOString(),
  };
  return call('POST', '/checkout/preferences', body, { 'X-Idempotency-Key': externalRef });
}
const getPayment = (id) => call('GET', '/v1/payments/' + encodeURIComponent(id));
async function searchByRef(ref) {
  const j = await call('GET', '/v1/payments/search?sort=date_created&criteria=desc&external_reference=' + encodeURIComponent(ref));
  return (j && j.results) || [];
}

/** Valida o cabeçalho x-signature do webhook (HMAC-SHA256), quando MP_WEBHOOK_SECRET está configurado. */
function verifySignature(headers, dataId) {
  if (!cfg.mp.webhookSecret) return true;
  const sig = String(headers['x-signature'] || ''), reqId = String(headers['x-request-id'] || '');
  const parts = Object.fromEntries(sig.split(',').map((p) => p.trim().split('=').map((x) => x.trim())).filter((p) => p.length === 2));
  if (!parts.ts || !parts.v1) return false;
  const manifest = (dataId ? `id:${String(dataId).toLowerCase()};` : '') + (reqId ? `request-id:${reqId};` : '') + `ts:${parts.ts};`;
  const mine = crypto.createHmac('sha256', cfg.mp.webhookSecret).update(manifest).digest('hex');
  const a = Buffer.from(mine), b = Buffer.from(parts.v1);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
module.exports = { enabled, createPreference, getPayment, searchByRef, verifySignature };
