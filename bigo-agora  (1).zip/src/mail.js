'use strict';
const { cfg } = require('./config');

const configured = () => !!(cfg.resendKey && cfg.mailFrom);
/** Envia e-mail pela API HTTPS do Resend (https://resend.com). Sem chave configurada, retorna false. */
async function send(to, subject, text) {
  if (!configured()) return false;
  try {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: 'Bearer ' + cfg.resendKey, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: cfg.mailFrom, to: [to], subject, text }),
    });
    if (!r.ok) { console.error('[mail] falha', r.status, await r.text().catch(() => '')); return false; }
    return true;
  } catch (e) {
    console.error('[mail] erro', e.message);
    return false;
  }
}
module.exports = { send, configured };
