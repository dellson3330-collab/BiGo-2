'use strict';
const db = require('./db');
/** Prestador VIP = tem assinatura ativa (paga) em qualquer plano do público "trabalhador". Os planos são criados pelo ADM. */
async function isVip(userId) {
  const { rows } = await db.query(
    `SELECT 1 FROM subscriptions s JOIN plans p ON p.id = s.plan_id
      WHERE s.user_id=$1 AND s.status='ACTIVE' AND s.ends_at > now() AND p.audience='WORKER' LIMIT 1`, [userId]);
  return rows.length > 0;
}
module.exports = { isVip };
