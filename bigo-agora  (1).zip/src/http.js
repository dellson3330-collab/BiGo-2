'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const { cfg } = require('./config');
const db = require('./db');
const { HttpError, verifyJwt, rateLimit } = require('./lib');

const routes = [];
function add(method, pattern, opts, handler) {
  if (typeof opts === 'function') { handler = opts; opts = {}; }
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:([a-zA-Z]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
  routes.push({ method, re, keys, opts: { auth: 'user', ...opts }, handler });
}
const api = {
  get: (p, o, h) => add('GET', p, o, h),
  post: (p, o, h) => add('POST', p, o, h),
  put: (p, o, h) => add('PUT', p, o, h),
  patch: (p, o, h) => add('PATCH', p, o, h),
  del: (p, o, h) => add('DELETE', p, o, h),
};

const SEC = {
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'X-Frame-Options': 'DENY',
};
function corsHeaders(req) {
  const origin = req.headers.origin;
  const h = {
    'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Authorization, Content-Type, X-Filename',
    'Access-Control-Max-Age': '86400',
  };
  if (cfg.corsOrigins.includes('*')) h['Access-Control-Allow-Origin'] = '*';
  else if (origin && cfg.corsOrigins.includes(origin)) { h['Access-Control-Allow-Origin'] = origin; h.Vary = 'Origin'; }
  return h;
}
function send(req, res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    ...SEC, ...corsHeaders(req),
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}
function clientIp(req) {
  if (cfg.trustProxy) {
    const x = req.headers['x-forwarded-for'];
    if (x) return String(x).split(',')[0].trim();
  }
  return req.socket.remoteAddress || '';
}
async function readJson(req, max) {
  const type = String(req.headers['content-type'] || '');
  if (!/json/i.test(type)) {
    // corpo vazio é aceito
    const len = Number(req.headers['content-length'] || 0);
    if (!len) return {};
    throw new HttpError(415, 'Envie os dados em JSON.');
  }
  const chunks = []; let size = 0;
  for await (const c of req) {
    size += c.length;
    if (size > max) throw new HttpError(413, 'Requisição grande demais.');
    chunks.push(c);
  }
  if (!size) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch (_) { throw new HttpError(400, 'JSON inválido.'); }
}
async function authenticate(ctx, opts) {
  if (opts.auth === 'none') return;
  const h = ctx.req.headers.authorization || '';
  const tok = h.startsWith('Bearer ') ? h.slice(7) : '';
  const p = tok ? verifyJwt(tok, cfg.jwtSecret) : null;
  if (!p) throw new HttpError(401, 'Sessão expirada. Faça login novamente.');
  if (opts.auth === 'admin') {
    if (p.typ !== 'admin') throw new HttpError(401, 'Sessão inválida.');
    const { rows } = await db.query('SELECT id, login, name, role, active, must_change_password FROM admin_users WHERE id=$1', [p.sub]);
    const a = rows[0];
    if (!a || !a.active) throw new HttpError(401, 'Sessão inválida.');
    if (opts.role === 'SUPER_ADMIN' && a.role !== 'SUPER_ADMIN') throw new HttpError(403, 'Sem permissão para esta ação.');
    ctx.admin = a;
    return;
  }
  if (p.typ !== 'user') throw new HttpError(401, 'Sessão inválida.');
  const { rows } = await db.query('SELECT id, email, role, status, name, phone, city, state, last_seen FROM users WHERE id=$1', [p.sub]);
  const u = rows[0];
  if (!u || u.status !== 'active') throw new HttpError(401, 'Conta indisponível.');
  ctx.user = u;
  if (!u.last_seen || Date.now() - new Date(u.last_seen).getTime() > 6 * 3600e3) {
    db.query('UPDATE users SET last_seen=now() WHERE id=$1', [u.id]).catch(() => {});
  }
}

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json', '.txt': 'text/plain; charset=utf-8',
};
const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const CSP = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https:; media-src 'self' blob: data: https:; connect-src 'self' https:; frame-ancestors 'none'; base-uri 'self'; form-action 'self'";
function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel === '/' || rel === '') rel = '/index.html';
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) return notFound(req, res);
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return notFound(req, res);
    const ext = path.extname(file).toLowerCase();
    const headers = { ...SEC, 'Content-Type': MIME[ext] || 'application/octet-stream', 'Content-Length': st.size };
    if (ext === '.html') { headers['Cache-Control'] = 'no-cache'; headers['Content-Security-Policy'] = CSP; }
    else headers['Cache-Control'] = 'public, max-age=3600';
    res.writeHead(200, headers);
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  });
}
function notFound(req, res) {
  res.writeHead(404, { ...SEC, 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('Não encontrado.');
}

async function handle(req, res) {
  const url = new URL(req.url, 'http://x');
  const pathname = url.pathname;
  const isApi = pathname.startsWith('/api/') || pathname === '/api';
  const isMedia = pathname.startsWith('/media/');
  if (req.method === 'OPTIONS') { res.writeHead(204, { ...SEC, ...corsHeaders(req) }); return res.end(); }
  if (!isApi && !isMedia) {
    if (req.method !== 'GET' && req.method !== 'HEAD') return notFound(req, res);
    return serveStatic(req, res, pathname);
  }
  const p = isApi ? pathname.slice(4) || '/' : pathname;
  let route = null, params = {};
  for (const r of routes) {
    if (r.method !== req.method) continue;
    const m = r.re.exec(p);
    if (m) { route = r; r.keys.forEach((k, i) => (params[k] = decodeURIComponent(m[i + 1]))); break; }
  }
  if (!route) return send(req, res, 404, { error: 'Rota não encontrada.' });
  const ctx = { req, res, params, query: Object.fromEntries(url.searchParams), body: {}, user: null, admin: null, ip: clientIp(req), status: 200 };
  try {
    rateLimit('ip:' + ctx.ip, 600, 60e3); // limite geral por IP
    await authenticate(ctx, route.opts);
    if (route.opts.limit) {
      const l = route.opts.limit;
      rateLimit(l.key + ':' + (l.perUser && (ctx.user || ctx.admin) ? (ctx.user || ctx.admin).id : ctx.ip), l.max, l.windowMs);
    }
    if (!route.opts.raw && ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
      ctx.body = await readJson(req, route.opts.maxBody || 256 * 1024);
    }
    const out = await route.handler(ctx);
    if (ctx.sent) return;
    send(req, res, ctx.status, out === undefined ? { ok: true } : out);
  } catch (e) {
    if (e instanceof HttpError) return send(req, res, e.status, { error: e.message });
    if (e && e.code === '23505') return send(req, res, 409, { error: 'Este registro já existe.' });
    if (e && e.code === '22P02') return send(req, res, 400, { error: 'Dados inválidos.' });
    console.error('[erro]', req.method, pathname, e && e.stack ? e.stack : e);
    if (!res.headersSent) send(req, res, 500, { error: 'Erro interno. Tente novamente em instantes.' });
    else res.end();
  }
}

function createServer() {
  const server = http.createServer((req, res) => { handle(req, res).catch((e) => { console.error('[fatal]', e); try { res.end(); } catch (_) {} }); });
  server.keepAliveTimeout = 65e3;
  server.headersTimeout = 70e3;
  return server;
}
module.exports = { api, createServer, send };
