'use strict';
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');

let pool = null;
function init(cfg) {
  pool = new Pool({
    connectionString: cfg.databaseUrl,
    max: 10,
    connectionTimeoutMillis: 15000,
    ssl: cfg.databaseSsl ? { rejectUnauthorized: false } : undefined,
  });
  pool.on && pool.on('error', (e) => console.error('[pg] erro no pool:', e.message));
  return pool;
}
const query = (text, params) => pool.query(text, params);
async function tx(fn) {
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    const r = await fn((t, p) => c.query(t, p));
    await c.query('COMMIT');
    return r;
  } catch (e) {
    try { await c.query('ROLLBACK'); } catch (_) {}
    throw e;
  } finally {
    c.release();
  }
}
async function migrate() {
  const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  await pool.query(sql);
}
const close = () => pool && pool.end();
module.exports = { init, query, tx, migrate, close };
