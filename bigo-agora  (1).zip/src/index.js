'use strict';
const { cfg, validate } = require('./config');
validate();
const db = require('./db');
const { hashPassword, randomToken } = require('./lib');
const { createServer } = require('./http');

require('./routes/media');
require('./routes/auth');
require('./routes/social');
require('./routes/admin');
require('./routes/billing');
require('./routes/orders');
require('./routes/ads');
const { removeFiles } = require('./routes/media');

const CATS = [
  ['Construção e Reformas', 'Pedreiro,Servente,Pintor,Eletricista,Encanador,Bombeiro hidráulico,Gesseiro,Azulejista,Carpinteiro,Marceneiro,Serralheiro,Montador de móveis,Técnico em edificações'],
  ['Limpeza', 'Diarista,Faxineira,Limpeza residencial,Limpeza comercial,Limpeza pós-obra,Limpeza de vidros,Jardinagem,Lavagem de estofados'],
  ['Manutenção', 'Manutenção predial,Manutenção residencial,Refrigeração,Ar-condicionado,Manutenção elétrica,Manutenção hidráulica,Manutenção de portões,Manutenção de equipamentos'],
  ['Transporte', 'Motorista,Entregador,Motoboy,Fretes,Mudanças'],
  ['Outras profissões', 'Cozinheiro,Garçom,Cuidador,Babá,Segurança,Recepcionista,Auxiliar administrativo,Serviços gerais,Trabalhador rural,Jardineiro'],
];

/** Dados de configuração (categorias/serviços de referência) e primeiro administrador. Não cria usuários de mentira. */
async function seed() {
  const { rows } = await db.query('SELECT count(*)::int n FROM categories');
  if (!rows[0].n) {
    for (let i = 0; i < CATS.length; i++) {
      const c = (await db.query('INSERT INTO categories (name, sort_order) VALUES ($1,$2) RETURNING id', [CATS[i][0], i])).rows[0];
      const items = CATS[i][1].split(',');
      for (let j = 0; j < items.length; j++) await db.query('INSERT INTO services (category_id, name, sort_order) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING', [c.id, items[j], j]);
    }
    console.log('[seed] categorias e serviços padrão criados.');
  }
  await db.query("INSERT INTO settings (key, value) VALUES ('name','\"BiGo\"') ON CONFLICT DO NOTHING");
  const a = await db.query('SELECT count(*)::int n FROM admin_users');
  if (!a.rows[0].n) {
    let pw = cfg.adminPassword, generated = false;
    if (!pw) { pw = randomToken(9).replace(/[^A-Za-z0-9]/g, 'x') + 'A9!'; generated = true; }
    await db.query(
      "INSERT INTO admin_users (login, name, password_hash, role, must_change_password) VALUES ($1,'Administrador BiGo',$2,'SUPER_ADMIN',true)",
      [cfg.adminLogin, await hashPassword(pw)]);
    if (generated) {
      console.log('==================================================================');
      console.log(' PRIMEIRO ACESSO DO ADMINISTRADOR (aparece só desta vez)');
      console.log('   login: ' + cfg.adminLogin + '   senha: ' + pw);
      console.log(' Entre pela tela de login normal e troque a senha em Admin > Acesso.');
      console.log('==================================================================');
    } else console.log('[seed] administrador "' + cfg.adminLogin + '" criado com a senha de ADMIN_PASSWORD (troca obrigatória).');
  }
}

async function cleanup() {
  try {
    const st = await db.query('DELETE FROM stories WHERE expires_at < now() - interval \'1 hour\' RETURNING media_id');
    const ids = st.rows.map((r) => r.media_id);
    const orphan = await db.query("SELECT id FROM media WHERE attached = false AND created_at < now() - interval '24 hours'");
    const all = [...new Set([...ids, ...orphan.rows.map((r) => r.id)])];
    if (all.length) {
      // mídia de story expirado só é apagada se nenhuma outra coisa a usa
      const del = await db.query(
        `DELETE FROM media m WHERE m.id = ANY($1::uuid[])
            AND NOT EXISTS (SELECT 1 FROM post_media pm WHERE pm.media_id = m.id)
            AND NOT EXISTS (SELECT 1 FROM stories s WHERE s.media_id = m.id)
         RETURNING storage_key`, [all]);
      await removeFiles(del.rows.map((r) => r.storage_key));
    }
    await db.query("UPDATE subscriptions SET status='EXPIRED' WHERE status='ACTIVE' AND ends_at < now()");
    await db.query("DELETE FROM refresh_tokens WHERE expires_at < now() - interval '1 day'");
    await db.query("DELETE FROM password_resets WHERE expires_at < now() - interval '1 day'");
  } catch (e) { console.error('[limpeza]', e.message); }
}

async function main() {
  db.init(cfg);
  try { await db.migrate(); }
  catch (e) {
    const m = String(e && (e.message || e.code) || e);
    console.error('[BiGo] Não consegui usar o banco de dados: ' + m);
    if (/ssl|tls|pg_hba|encryption/i.test(m) && !cfg.databaseSsl) {
      console.error('[BiGo] O banco parece exigir conexão segura. Tentando de novo com SSL (defina DATABASE_SSL=true para fixar).');
      cfg.databaseSsl = true; db.init(cfg);
      try { await db.migrate(); } catch (e2) { console.error('[BiGo] Falhou de novo: ' + (e2.message || e2)); process.exit(1); }
    } else {
      if (/ENOTFOUND|EAI_AGAIN/.test(m)) console.error('[BiGo] O endereço (host) da DATABASE_URL não foi encontrado. Use o host INTERNO que o painel do banco mostra.');
      if (/ECONNREFUSED|timeout/i.test(m)) console.error('[BiGo] O banco não respondeu. Confira host, porta e se app e banco estão na mesma região/rede.');
      if (/password|authentication/i.test(m)) console.error('[BiGo] Usuário ou senha do banco recusados. Confira a DATABASE_URL (caracteres especiais na senha precisam ser codificados, ex.: @ vira %40).');
      process.exit(1);
    }
  }
  await seed();
  const server = createServer();
  server.listen(cfg.port, '0.0.0.0', () => console.log(`[BiGo] ${cfg.appEnv} na porta ${cfg.port} (armazenamento: ${cfg.storage})`));
  const timer = setInterval(cleanup, 3600e3); timer.unref();
  setTimeout(cleanup, 30e3).unref();
  const stop = () => { console.log('Encerrando...'); server.close(() => db.close().then(() => process.exit(0))); setTimeout(() => process.exit(0), 8000).unref(); };
  process.on('SIGTERM', stop); process.on('SIGINT', stop);
  return server;
}
if (require.main === module) main().catch((e) => { console.error('Falha ao iniciar:', e); process.exit(1); });
module.exports = { main, seed, cleanup };
