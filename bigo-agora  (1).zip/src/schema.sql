-- BiGo: esquema do PostgreSQL. Idempotente: pode rodar a cada inicialização.

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE,
  password_hash text NOT NULL,
  role text NOT NULL CHECK (role IN ('CLIENT','WORKER','COMPANY')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','blocked')),
  name text NOT NULL,
  phone text,
  city text,
  state varchar(2),
  bairro text,
  avatar_media uuid,
  lat double precision,
  lng double precision,
  consent_at timestamptz NOT NULL DEFAULT now(),
  consent_ver text NOT NULL DEFAULT 'v1',
  failed_logins int NOT NULL DEFAULT 0,
  locked_until timestamptz,
  last_seen timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS users_role_status_idx ON users (role, status);
CREATE INDEX IF NOT EXISTS users_city_idx ON users (lower(city), state);
CREATE INDEX IF NOT EXISTS users_created_idx ON users (created_at);

CREATE TABLE IF NOT EXISTS worker_profiles (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  profession text NOT NULL,
  specialties text NOT NULL DEFAULT '',
  bio text NOT NULL DEFAULT '',
  experience text NOT NULL DEFAULT '',
  courses text NOT NULL DEFAULT '',
  availability text NOT NULL DEFAULT 'Disponível',
  radius_km int NOT NULL DEFAULT 30,
  looking_for_job boolean NOT NULL DEFAULT false,
  whatsapp text,
  show_whatsapp boolean NOT NULL DEFAULT false,
  show_phone boolean NOT NULL DEFAULT false,
  cover_media uuid,
  ver_identity boolean NOT NULL DEFAULT false,
  ver_qualifications boolean NOT NULL DEFAULT false,
  profile_views int NOT NULL DEFAULT 0,
  rating_avg real NOT NULL DEFAULT 0,
  rating_count int NOT NULL DEFAULT 0,
  featured_until timestamptz
);
CREATE INDEX IF NOT EXISTS worker_profession_idx ON worker_profiles (profession);

CREATE TABLE IF NOT EXISTS client_profiles (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  bio text NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS companies (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  trade_name text NOT NULL,
  legal_name text,
  cnpj text UNIQUE,
  about text,
  website text,
  logo_media uuid,
  verified boolean NOT NULL DEFAULT false
);

CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  sort_order int NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true
);
CREATE TABLE IF NOT EXISTS services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  name text NOT NULL UNIQUE,
  sort_order int NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true
);
CREATE INDEX IF NOT EXISTS services_category_idx ON services (category_id, sort_order);

CREATE TABLE IF NOT EXISTS media (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind text NOT NULL CHECK (kind IN ('image','video')),
  mime text NOT NULL,
  size_bytes bigint NOT NULL DEFAULT 0,
  storage_key text NOT NULL,
  ready boolean NOT NULL DEFAULT true,
  attached boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS media_owner_idx ON media (owner_id);
CREATE INDEX IF NOT EXISTS media_orphan_idx ON media (attached, created_at);

CREATE TABLE IF NOT EXISTS posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  text text NOT NULL,
  price_text text NOT NULL DEFAULT '',
  before_after boolean NOT NULL DEFAULT false,
  show_whatsapp boolean NOT NULL DEFAULT true,
  show_phone boolean NOT NULL DEFAULT true,
  sponsored boolean NOT NULL DEFAULT false,
  hidden boolean NOT NULL DEFAULT false,
  views int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS posts_created_idx ON posts (created_at DESC);
CREATE INDEX IF NOT EXISTS posts_author_idx ON posts (author_id, created_at DESC);

CREATE TABLE IF NOT EXISTS post_media (
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  media_id uuid NOT NULL REFERENCES media(id) ON DELETE CASCADE,
  position int NOT NULL DEFAULT 0,
  PRIMARY KEY (post_id, media_id)
);
CREATE INDEX IF NOT EXISTS post_media_pos_idx ON post_media (post_id, position);

CREATE TABLE IF NOT EXISTS post_views (
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  viewer_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (post_id, viewer_id)
);
CREATE TABLE IF NOT EXISTS profile_views (
  target_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  viewer_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day date NOT NULL DEFAULT current_date,
  PRIMARY KEY (target_id, viewer_id, day)
);

CREATE TABLE IF NOT EXISTS stories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  media_id uuid NOT NULL REFERENCES media(id) ON DELETE CASCADE,
  text text NOT NULL DEFAULT '',
  location text NOT NULL DEFAULT '',
  show_contact boolean NOT NULL DEFAULT true,
  hidden boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS stories_exp_idx ON stories (expires_at);
CREATE INDEX IF NOT EXISTS stories_author_idx ON stories (author_id, expires_at);
CREATE TABLE IF NOT EXISTS story_views (
  story_id uuid NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
  viewer_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  viewed_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (story_id, viewer_id)
);

CREATE TABLE IF NOT EXISTS comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  author_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  parent_id uuid REFERENCES comments(id) ON DELETE CASCADE,
  body text NOT NULL,
  hidden boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS comments_post_idx ON comments (post_id, created_at);

CREATE TABLE IF NOT EXISTS likes (
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (post_id, user_id)
);
CREATE TABLE IF NOT EXISTS follows (
  follower_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  following_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (follower_id, following_id),
  CHECK (follower_id <> following_id)
);
CREATE INDEX IF NOT EXISTS follows_following_idx ON follows (following_id);

CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  text text NOT NULL,
  link text,
  read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS notifications_user_idx ON notifications (user_id, read, created_at DESC);

CREATE TABLE IF NOT EXISTS reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  target_type text NOT NULL CHECK (target_type IN ('post','story','user','comment','job')),
  target_id uuid NOT NULL,
  reason text NOT NULL,
  details text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','RESOLVED','DISMISSED')),
  created_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz,
  UNIQUE (reporter_id, target_type, target_id)
);
CREATE INDEX IF NOT EXISTS reports_status_idx ON reports (status, created_at DESC);

CREATE TABLE IF NOT EXISTS refresh_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash text NOT NULL UNIQUE,
  family uuid NOT NULL,
  ip text,
  user_agent text,
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS refresh_user_idx ON refresh_tokens (user_id);
CREATE INDEX IF NOT EXISTS refresh_family_idx ON refresh_tokens (family);

CREATE TABLE IF NOT EXISTS password_resets (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  code_hash text NOT NULL,
  expires_at timestamptz NOT NULL,
  attempts int NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS admin_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  login text NOT NULL UNIQUE,
  name text NOT NULL,
  password_hash text NOT NULL,
  role text NOT NULL DEFAULT 'MODERATOR' CHECK (role IN ('SUPER_ADMIN','MODERATOR')),
  active boolean NOT NULL DEFAULT true,
  must_change_password boolean NOT NULL DEFAULT false,
  failed_logins int NOT NULL DEFAULT 0,
  locked_until timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS admin_logs (
  id bigserial PRIMARY KEY,
  admin_id uuid REFERENCES admin_users(id) ON DELETE SET NULL,
  admin_name text NOT NULL,
  action text NOT NULL,
  target text,
  ip text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS admin_logs_created_idx ON admin_logs (created_at DESC);

CREATE TABLE IF NOT EXISTS settings (
  key text PRIMARY KEY,
  value jsonb NOT NULL
);

-- Tabelas das próximas etapas (vagas, avaliações, mensagens, verificações, monetização).
CREATE TABLE IF NOT EXISTS jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  poster_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  company_id uuid REFERENCES companies(user_id) ON DELETE SET NULL,
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  title text NOT NULL,
  description text NOT NULL,
  city text NOT NULL,
  state varchar(2) NOT NULL,
  salary_text text,
  contract text NOT NULL CHECK (contract IN ('TEMPORARY','PERMANENT','FREELANCE','DAILY','PIECEWORK')),
  schedule text,
  requirements text,
  contact text,
  deadline date,
  status text NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','CLOSED','PAUSED')),
  priority boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS jobs_status_idx ON jobs (status, state, city);
CREATE TABLE IF NOT EXISTS applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  applicant_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  message text,
  status text NOT NULL DEFAULT 'SENT' CHECK (status IN ('SENT','VIEWED','SHORTLISTED','REJECTED','HIRED')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (job_id, applicant_id)
);
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  target_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rating int NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment text,
  hidden boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (author_id, target_id),
  CHECK (author_id <> target_id)
);
CREATE TABLE IF NOT EXISTS favorites (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  target_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, target_id)
);
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  receiver_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body text NOT NULL,
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS messages_pair_idx ON messages (sender_id, receiver_id, created_at);
CREATE INDEX IF NOT EXISTS messages_recv_idx ON messages (receiver_id, read_at);
CREATE TABLE IF NOT EXISTS verifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('PHONE','IDENTITY','QUALIFICATION')),
  status text NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','APPROVED','REJECTED')),
  document_key text, -- documentos ficam em armazenamento PRIVADO, nunca públicos
  notes text,
  reviewed_by uuid REFERENCES admin_users(id) ON DELETE SET NULL,
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  audience text NOT NULL CHECK (audience IN ('CLIENT','WORKER','COMPANY')),
  price_cents int NOT NULL DEFAULT 0,
  duration_days int NOT NULL DEFAULT 30,
  benefits jsonb NOT NULL DEFAULT '{}',
  active boolean NOT NULL DEFAULT true
);
CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan_id uuid NOT NULL REFERENCES plans(id),
  status text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','CANCELED','EXPIRED','PAST_DUE')),
  starts_at timestamptz NOT NULL,
  ends_at timestamptz NOT NULL
);
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id),
  subscription_id uuid REFERENCES subscriptions(id),
  amount_cents int NOT NULL,
  status text NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','PAID','FAILED','REFUNDED')),
  provider text,
  provider_ref text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  paid_at timestamptz
);
CREATE TABLE IF NOT EXISTS advertisements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid REFERENCES companies(user_id) ON DELETE SET NULL,
  title text NOT NULL,
  body text,
  media_url text,
  target_url text,
  state varchar(2),
  city text,
  starts_at timestamptz NOT NULL,
  ends_at timestamptz NOT NULL,
  active boolean NOT NULL DEFAULT true,
  impressions int NOT NULL DEFAULT 0,
  clicks int NOT NULL DEFAULT 0
);

-- Pagamentos (Mercado Pago)
ALTER TABLE plans ADD COLUMN IF NOT EXISTS description text NOT NULL DEFAULT '';
ALTER TABLE plans ADD COLUMN IF NOT EXISTS sort_order int NOT NULL DEFAULT 0;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS plan_id uuid REFERENCES plans(id);
ALTER TABLE payments ADD COLUMN IF NOT EXISTS mp_payment_id text;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS mp_status text;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS method text;
CREATE UNIQUE INDEX IF NOT EXISTS payments_mp_payment_id_key ON payments (mp_payment_id) WHERE mp_payment_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS payments_user_idx ON payments (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS subscriptions_user_idx ON subscriptions (user_id, ends_at DESC);
CREATE TABLE IF NOT EXISTS webhook_events (
  id bigserial PRIMARY KEY,
  provider text NOT NULL,
  ref text,
  received_at timestamptz NOT NULL DEFAULT now(),
  outcome text
);

-- Ordens de serviço (clientes pedem; prestadores da mesma cidade são avisados; contato só para prestador VIP)
CREATE TABLE IF NOT EXISTS service_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  profession text NOT NULL DEFAULT '',
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  city text NOT NULL,
  state varchar(2) NOT NULL,
  bairro text NOT NULL DEFAULT '',
  address text NOT NULL DEFAULT '',
  whatsapp text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','CLOSED')),
  hidden boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL DEFAULT now() + interval '30 days'
);
CREATE INDEX IF NOT EXISTS service_orders_loc_idx ON service_orders (state, lower(city), created_at DESC);
CREATE INDEX IF NOT EXISTS service_orders_client_idx ON service_orders (client_id, created_at DESC);

-- Anúncios pagos
CREATE TABLE IF NOT EXISTS ad_packages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL DEFAULT '',
  price_cents int NOT NULL CHECK (price_cents > 0),
  duration_days int NOT NULL DEFAULT 7,
  active boolean NOT NULL DEFAULT true,
  sort_order int NOT NULL DEFAULT 0
);
ALTER TABLE advertisements ALTER COLUMN starts_at DROP NOT NULL;
ALTER TABLE advertisements ALTER COLUMN ends_at DROP NOT NULL;
ALTER TABLE advertisements ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES users(id) ON DELETE CASCADE;
ALTER TABLE advertisements ADD COLUMN IF NOT EXISTS package_id uuid REFERENCES ad_packages(id);
ALTER TABLE advertisements ADD COLUMN IF NOT EXISTS media_id uuid REFERENCES media(id) ON DELETE SET NULL;
ALTER TABLE advertisements ADD COLUMN IF NOT EXISTS whatsapp text NOT NULL DEFAULT '';
ALTER TABLE advertisements ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'AWAITING_PAYMENT';
ALTER TABLE advertisements ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();
CREATE INDEX IF NOT EXISTS advertisements_feed_idx ON advertisements (status, ends_at);
ALTER TABLE payments ADD COLUMN IF NOT EXISTS ad_id uuid REFERENCES advertisements(id) ON DELETE SET NULL;
