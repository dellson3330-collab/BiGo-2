'use strict';
const db = require('./db');

/** Registro de atividades administrativas (admin_logs). */
function logAdmin(admin, action, target, ip) {
  return db.query('INSERT INTO admin_logs (admin_id, admin_name, action, target, ip) VALUES ($1,$2,$3,$4,$5)',
    [admin ? admin.id : null, admin ? admin.name : 'sistema', action, target ? String(target).slice(0, 300) : null, ip || null])
    .catch((e) => console.error('[audit]', e.message));
}
module.exports = { logAdmin };
